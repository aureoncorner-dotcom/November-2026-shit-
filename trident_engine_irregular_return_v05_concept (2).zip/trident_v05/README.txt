TRIDENT ENGINE — IRREGULAR RETURN (v0.5 concept)

THIS IS A NEW DESIGN STUDY. THE SOURCE TRIDENT ENGINE v0.4 IS UNCHANGED.

Files:
  trident_engine_v05_architecture.png   full system schematic
  trident_engine_v05_architecture.svg   vector version
  trident_367_rotation_test.png         360 vs 367 comparison
  trident_367_rotation_test.svg         vector comparison
  TRIDENT_ENGINE_V05_DESIGN_REVIEW.md   review spec and falsifiers
  build.py                              reproducible plotting code

Source: TRIDENT ENGINE / MUNCHING CARPET READ v0.4 (attached 17-page PDF).
The visuals are explanatory and are not physical measurements.
