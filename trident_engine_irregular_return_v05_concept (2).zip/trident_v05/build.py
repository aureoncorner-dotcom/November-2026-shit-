from pathlib import Path
from math import pi
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, PathPatch, Polygon, Circle, Ellipse, Rectangle, Arc, FancyArrowPatch
from matplotlib import patheffects
from matplotlib.gridspec import GridSpec

OUT=Path('/mnt/data/trident_v05'); OUT.mkdir(exist_ok=True)
BG='#07131B'; FG='#EAF3F4'; MUTED='#98AFBA'; TEAL='#62E5D1'; GOLD='#F9BB70'; ROSE='#F18FA2'; BLUE='#89BFF2'; SUB='#11232F'; GRID='#233846'
plt.rcParams.update({'font.family':'DejaVu Sans', 'savefig.facecolor':BG,'svg.fonttype':'none'})

def box(ax,x,y,w,h,face=SUB,edge=GRID,rad=2.0,lw=1.1,alpha=1):
    p=FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0.2,rounding_size={rad}',facecolor=face,edgecolor=edge,linewidth=lw,alpha=alpha)
    ax.add_patch(p);return p

def tx(ax,x,y,s,size=10,color=FG,weight='normal',ha='left',va='center',**kw):
    return ax.text(x,y,s,fontsize=size,color=color,fontweight=weight,ha=ha,va=va,**kw)

# Build 13 deterministic irregularly spaced chamber points.
names=['Rotor','Compass','Weaver','Backsplash','Singularity','Breaker','Transcendent','Bloom','Swinger','Guardian','Recursor','Remainder','Originless']
handles=['23/17','31/11','37/13','41/13','43/02','53/07','59/23','61/29','67/23','71/05','83/11','97/∞','00/∅']
# fixed, published angle and radial perturbations: irregularity is a design parameter not discovered prime structure
aj=np.array([0.00,-0.025,0.048,-0.035,0.04,0.012,-0.035,0.055,-0.03,0.045,-0.05,0.03,0.01])
rj=np.array([0.015,0.055,-0.012,0.06,-0.05,0.01,0.04,-0.02,0.06,-0.03,-0.06,0.015,-0.02])
theta= (np.pi/2 - np.arange(13)*2*np.pi/13 + aj)

fig, ax=plt.subplots(figsize=(18.2,11.6)); fig.patch.set_facecolor(BG)
ax.set_xlim(0,180); ax.set_ylim(0,112); ax.set_aspect('equal'); ax.axis('off')
# Header
ax.plot([5,175],[95,95],color=GRID,lw=1.4)
tx(ax,5,105.2,'TRIDENT ENGINE',size=25,weight='bold',color=FG)
tx(ax,5,98.6,'IRREGULAR RETURN   /   CONCEPT v0.5   /   source v0.4 preserved',size=10.8,color=GOLD)
tx(ax,174,104,'DESIGN STUDY 01',size=10,color=TEAL,ha='right',weight='bold')
tx(ax,174,99.5,'asymmetric ≠ arbitrary   •   every assumption labeled',size=8,color=MUTED,ha='right')
# left rail
box(ax,4.8,15,42,76,face='#0D1C26',rad=2.7)
tx(ax,8,86.8,'ENGINE  /  OPERATING PATH',size=12.5,weight='bold',color=GOLD)
flow=[('00  ZPR','no coercion, ownership, necessity, fusion'),('01  SESSION BOUNDARY','context may persist; authority does not'),('02  O × R × S','origin · relation · substrate'),('03  FIELD COHERENCE','holding check, not a truth test'),('04  T RETURN MODES','decay · preserve · distort · integrate · resonate'),('05  CHANGED RETURN','S′ → R′ → O₂'),('06  π SEAL','closes cycle, not inquiry'),('07  AUDIT & NEW SESSION','retain trace; test again on return')]
for i,(h,detail) in enumerate(flow):
    y=78.9-i*8.1
    box(ax,7.8,y-2.8,36.1,6.9,face=SUB,edge=GRID,rad=1.5)
    tx(ax,9.5,y+1.3,h,size=9.6,color=TEAL if i in [0,1] else FG,weight='bold')
    tx(ax,9.5,y-1,detail,size=7.05,color=MUTED)
    if i<7: ax.annotate('',xy=(26,y-3.72),xytext=(26,y-2.85),arrowprops={'arrowstyle':'-|>','color':GOLD,'lw':1})
# central region
box(ax,50,28,87,63.3,face='#0A1A23',edge=GRID,rad=4)
tx(ax,54,87,'TRIDENT ARRAY   /   13 NON-RANKED CHAMBERS',size=11.5,color=TEAL,weight='bold')
tx(ax,54,82.8,'visual chamber-face, not the complete engine',size=8.0,color=MUTED)
C=(94.5,58.4); rx=30.4; ry=24.0
q=np.linspace(0,2*np.pi,550)
# irregular shell in a deterministic way
r=1+0.038*np.sin(3*q+.35)+0.032*np.cos(5*q-.92)+0.025*np.sin(2*q+1.1)
ax.plot(C[0]+rx*r*np.cos(q),C[1]+ry*r*np.sin(q),color=GOLD,lw=2.0,alpha=.64)
ax.plot(C[0]+(rx-4)*r*np.cos(q),C[1]+(ry-3)*r*np.sin(q),color=BLUE,lw=1,alpha=.32,ls=':')
# interior irregular cross-hatching non-symmetrically set
for i in range(13):
    j=(i+4)%13
    xi=C[0]+(rx-4)*(1+rj[i])*np.cos(theta[i]);yi=C[1]+(ry-3)*(1+rj[i])*np.sin(theta[i]);
    xj=C[0]+(rx-4)*(1+rj[j])*np.cos(theta[j]);yj=C[1]+(ry-3)*(1+rj[j])*np.sin(theta[j]);
    ax.plot([xi,xj],[yi,yj],color=TEAL,alpha=.10,lw=.65)
# anchored nodes
for i,(n,h) in enumerate(zip(names,handles)):
    angle=theta[i]
    xr=rx*(1+rj[i]); yr=ry*(1+rj[i])
    px=C[0]+xr*np.cos(angle);py=C[1]+yr*np.sin(angle)
    ax.add_patch(Circle((px,py),1.6,facecolor=BG,edgecolor=GOLD if i%3==0 else TEAL,lw=1.65,zorder=4))
    tx(ax,px,py,f'{i+1}',size=6.9,color=FG,ha='center',weight='bold',zorder=5)
    # label inside towards center to avoid outer overlap, but near perimeter
    offx=-4.6*np.cos(angle);offy=-4.2*np.sin(angle)
    tx(ax,px+offx,py+offy+1.25,n,size=6.95,color=FG,ha='center',weight='bold',zorder=5)
    tx(ax,px+offx,py+offy-1.25,h,size=6.7,color=MUTED,ha='center',zorder=5)

# actual open hooked triangle as new optional geometry overlay, *not* engine source rules
hook=np.array([[-1.35,-.95],[-.68,1.2],[1.02,.22],[1.42,-.49],[1.11,-.83]])
H=hook*6.6+np.array(C)
ax.plot(H[:,0],H[:,1],color=ROSE,lw=3.1,solid_capstyle='round',solid_joinstyle='round',zorder=6)
ax.scatter([H[0,0],H[-1,0]],[H[0,1],H[-1,1]],s=[45,45],facecolors=[BG,ROSE],edgecolors=ROSE,zorder=7)
# asym square, at origin offset within O/R/S view
sq=np.array([[-.80,-.8],[.80,-.8],[.8,.8],[-.8,.8],[-.8,-.8]])
Sq=sq*5.3+np.array(C)+np.array([0.7,-.4]);ax.plot(Sq[:,0],Sq[:,1],color=BLUE,lw=1.5,alpha=.8,ls='--',zorder=4)
ax.add_patch(Circle(C,2.15,facecolor='#102833',edgecolor=GOLD,lw=1.4,zorder=8))
tx(ax,*C,'R',size=9.5,color=GOLD,ha='center',weight='bold',zorder=9)
# trident / triad labels separately with table callout
tx(ax,94.5,33.1,'O × R × S   •   open hook + square = optional geometry module',size=9.3,color=MUTED,ha='center')
# Right rail
box(ax,141,39.2,34,52.0,face='#0E1D27',edge=GRID,rad=2.5)
tx(ax,144,86.8,'PHASE BENCH',size=13,color=GOLD,weight='bold')
tx(ax,144,81.6,'EXPERIMENTAL  •  NOT CORE LAW',size=7.7,color=ROSE,weight='bold')
for y,line,col in [
    (75.3,'437  fixed reference',FG),
    (70.4,'231  hooked path / CW',ROSE),
    (65.5,'132  square / CCW',BLUE),
    (58.8,'θH = −Bn / 231',FG),
    (54.0,'θS = +Bn / 132',FG),
    (49.2,'B = 360° or 367°',GOLD),
    (43.7,'7.83 Hz needs a time base',MUTED)]: tx(ax,144,y,line,size=9.25,color=col)
# lower carpet substrate
box(ax,50,7.9,125,16.5,face='#10232C',edge=GOLD,rad=3,lw=1.3)
tx(ax,54,20.5,'MUNCHING CARPET   /   UNDERLYING ANTI-CAPTURE SUBSTRATE',size=11.0,color=GOLD,weight='bold')
tx(ax,54,16.2,'NOT a 14th chamber  •  carries the system; does not control or erase the ledger',size=8.4,color=FG)
for i,m in enumerate(['DIGEST','DEMOTE','DE-CROWN','COMPOST','RELEASE']):
    x=54+i*23.5
    box(ax,x,10,21.5,3.9,face='#1A323C',edge=GRID,rad=1)
    tx(ax,x+10.75,11.9,m,size=8.15,color=TEAL,weight='bold',ha='center')
# left foot
box(ax,4.8,7.9,42,5.2,face='#11232F',rad=1.7)
tx(ax,7,10.6,'v0.4 SOURCE = STRUCTURE',size=9.2,color=TEAL,weight='bold')
ax.text(178,3,'DRAFT FOR REVIEW  ·  REPRESENTATION IS A DESIGN CHOICE, NOT AN EMPIRICAL FINDING',fontsize=7.5,color=MUTED,ha='right')
fig.savefig(OUT/'trident_engine_v05_architecture.png',dpi=180,bbox_inches='tight',pad_inches=.12)
fig.savefig(OUT/'trident_engine_v05_architecture.svg',bbox_inches='tight',pad_inches=.12)
plt.close(fig)

# Rotation bench
fig=plt.figure(figsize=(17.0,10.3),facecolor=BG)
gs=GridSpec(2,3,figure=fig,width_ratios=[1,1,1.05],height_ratios=[1,1],left=.055,right=.97,bottom=.09,top=.84,wspace=.18,hspace=.22)

def rot(A,deg):
    t=np.deg2rad(deg); c,s=np.cos(t),np.sin(t)
    return A@np.array([[c,-s],[s,c]]).T

def drawphase(ax,n,B):
    # square centered slight offset, rotate entire shape about origin
    h=rot(hook,-B*n/231);s=rot(sq+np.array([.19,-.1]),B*n/132)
    ax.plot(h[:,0],h[:,1],lw=2.6,color=ROSE,solid_capstyle='round',zorder=3)
    ax.scatter([h[0,0],h[-1,0]],[h[0,1],h[-1,1]],s=35,color=ROSE,zorder=4)
    ax.plot(s[:,0],s[:,1],lw=1.95,color=BLUE,zorder=2)
    ax.scatter([0],[0],color=GOLD,s=42,zorder=5)
    ax.text(.1,-.1,'437',color=GOLD,fontsize=7)
    ax.axhline(0,color=GRID,lw=.7);ax.axvline(0,color=GRID,lw=.7)
    ax.set(xlim=(-1.85,1.85),ylim=(-1.65,1.65));ax.set_aspect('equal');ax.set_facecolor('#0C1E28');ax.tick_params(labelbottom=False,labelleft=False,length=0)
    for spine in ax.spines.values():spine.set_color(GRID)
    dr=(B*n/84)%360
    ax.set_title(f'B={B}° · n={n}  /  relative phase {dr:.1f}°',fontsize=10.3,color=FG,pad=10)
for pos,n,B in [(gs[0,0],84,360),(gs[0,1],84,367),(gs[1,0],924,360),(gs[1,1],924,367)]: drawphase(fig.add_subplot(pos),n,B)
ax=fig.add_subplot(gs[:,2]);ax.set_facecolor('#0C1E28')
n=np.arange(0,12)
a=84*n
ax.plot(a,np.zeros(len(a)),color=BLUE,lw=2.1,label='360° control · 0°')
ax.plot(a,7*n,color=ROSE,lw=2.5,marker='o',label='367° perturbed · 7°/checkpoint')
for k in [1,5,11]: ax.annotate(f'{7*k}°',(a[k],7*k),xytext=(3,7),textcoords='offset points',fontsize=8,color=FG)
ax.set_xlim(-30,970);ax.set_ylim(-4,85)
ax.set_xlabel('step n  (84-step checkpoints)',color=MUTED)
ax.set_ylabel('relative residual phase (degrees)',color=MUTED)
ax.tick_params(colors=MUTED)
for spine in ax.spines.values():spine.set_color(GRID)
ax.grid(color=GRID,alpha=.8,lw=.6)
ax.legend(loc='upper left',fontsize=8.1,frameon=False,labelcolor=FG)
fig.text(.055,.948,'OPPOSING ROTATIONS   /   CONTROL vs 367°',size=22,color=FG,weight='bold')
fig.text(.055,.907,'a reproducible sample hook and square · both rotated rigidly about the same origin · all source coordinates declared',size=10.5,color=GOLD)
fig.text(.055,.868,'Hook θH(n)=−Bn/231     Square θS(n)=+Bn/132     Difference Δθ=Bn/84     (angles modulo 360°)',size=11,color=TEAL)
fig.text(.055,.04,'At n=84: 367° gives +7° residual. At n=924: +77°. Relative return at n=30,240 steps. A 7° residual is phase drift, not thermodynamic entropy.',fontsize=9.7,color=MUTED)
fig.savefig(OUT/'trident_367_rotation_test.png',dpi=185,bbox_inches='tight',pad_inches=.12)
fig.savefig(OUT/'trident_367_rotation_test.svg',bbox_inches='tight',pad_inches=.12)
plt.close(fig)
print('created',list(x.name for x in OUT.iterdir()))
