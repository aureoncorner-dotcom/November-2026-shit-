#!/usr/bin/env python3
"""Controlled adapter demonstration: computed phase and finite witness ride in Corner Relay SEND payloads.

Both executable subsystems are imported unchanged. This is a NEW external harness;
not autonomous DECURSE execution, nor a physical coupling or proof of causation.
"""
from __future__ import annotations
import base64
import csv
import hashlib
import json
import platform
import sys
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'sources'
sys.path.insert(0, str(SOURCE / 'corner_relay'))
sys.path.insert(0, str(SOURCE))
from corner_relay import Actor, Endpoint, LambdaTransport, verify_raw_ledger
import geometry_quantum_witness as witness

BASE = 367
CHECKPOINTS = ((336, 1), (420, 3))


def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def as_fraction_string(x):
    return str(x)


def source_records():
    prime_path = SOURCE / 'prime_lattice_audit' / 'inputs' / 'prime_double_key_coordinates.csv'
    phase_path = SOURCE / 'prime_lattice_audit' / 'phases' / 'intersection_counts.csv'
    with prime_path.open(newline='', encoding='utf-8') as f:
        prime = {int(r['prime_stream_position']):r for r in csv.DictReader(f)}
    with phase_path.open(newline='', encoding='utf-8') as f:
        intersections = {(int(r['base']),int(r['step'])):r for r in csv.DictReader(f)}
    return prime, intersections


def build_payload(step: int, budget: int, prime, intersections):
    position = step + 1  # declared 83-column checkpoint mapping
    assert position in prime, f'Expected preserved double-key site {position}'
    assert (BASE, step) in intersections, f'Missing independently audited crossing record {step}'
    phase_hook = Fraction(-BASE * step, 231)
    phase_square = Fraction(BASE * step, 132)
    relative = (phase_square - phase_hook) % 360
    assert relative == Fraction(BASE * step, 84) % 360
    benchmark = witness.example('seven')
    result = witness.run(benchmark, budget=budget)
    best = result['best_within_budget']
    assert result['native_squared_loss_before']=='1/7'
    assert (budget, best['axes'], best['native_squared_loss_after']) in ((1,['Y'],'1/14'),(3,['X','Y'],'0'))
    rec = prime[position]
    ct = intersections[(BASE, step)]
    assert int(ct['unique_intersections']) == 2
    payload = {
        'schema': 'phase-relay-witness-adapter/v1',
        'selection': 'Externally selected 84-step checkpoint with double-key in supplied CSV; NOT a statistical link',
        'phase': {
            'model_B_deg': BASE, 'step_n':step,
            'hook_unwrapped_deg': as_fraction_string(phase_hook),
            'square_unwrapped_deg': as_fraction_string(phase_square),
            'relative_phase_deg_mod_360': as_fraction_string(relative),
            'intersections': int(ct['unique_intersections']),
            'endpoint_contacts': int(ct['endpoint_contacts']),
        },
        'prime_position': {
            'stream_position':position, 'digit':rec['digit'],
            'row_11': (position-1)//83+1, 'col_83':(position-1)%83+1,
            'source_coordinate_row_127': int(rec['row_127']),
            'source_coordinate_col_113': int(rec['col_113']),
        },
        'witness': {
            'fixture': 'seven-state ideal Bloch probability example',
            'externally_selected_budget': budget,
            'base_squared_loss':result['native_squared_loss_before'],
            'best_within_budget':best,
            'complete_repair_available':result['min_cost_fixed_batch'],
        },
        'scope': 'Three parallel records bound into a payload, NOT one validated physical mechanism. Relay handles opaque bytes.'
    }
    return payload


def checked(condition: bool, key: str, checks: dict):
    checks[key] = bool(condition)
    return condition


def run():
    primes, intersections = source_records()
    o,s = Endpoint(Actor.O),Endpoint(Actor.S)
    transport = LambdaTransport(o,s)
    checks={}
    snapshots=[]
    cycle_rows=[]
    first_o=first_s=None
    prior_return=None

    def capture(t, action):
        snapshots.append({
            't_index':t, 'action':action,
            'O_view_sha256':digest(canonical(o.view().to_dict())),
            'S_view_sha256':digest(canonical(s.view().to_dict())),
            'O_raw_count':len(o.raw), 'S_raw_count':len(s.raw),
            'O_view':o.view().to_dict(), 'S_view':s.view().to_dict()
        })

    capture(0,'initial')
    checked(o is not s and o.actor != s.actor and o.key_id != s.key_id, 'separate_origin_and_structure',checks)
    checked(transport.held_key_ids==(), 'lambda_has_no_key',checks)
    for c,(n,budget) in enumerate(CHECKPOINTS, 1):
        if prior_return is not None:
            checked(o.view().to_dict()==prior_return['O'] and s.view().to_dict()==prior_return['S'],
                    'cycle2_carries_prior_state',checks)
        payload=build_payload(n,budget,primes,intersections)
        payload_bytes=canonical(payload)
        sent=o.send(f'integrated-send-{c}',payload_bytes)
        checked(base64.b64decode(sent.payload_b64)==payload_bytes,'cycle%d_payload_exact'%c,checks)
        if c==2:
            checked(json.loads(o.raw[-1].before_view_record)==prior_return['O'],
                    'cycle2_send_before_equals_previous_O_return',checks)
        capture((c-1)*4+1,f'cycle {c}: SEND payload')
        transport.route(sent)
        got=transport.deliver()
        checked(got.status=='APPLIED','cycle%d_delivered'%c,checks)
        # Independent adapter reads bytes after delivery; LambdaTransport does not interpret them.
        received=json.loads(base64.b64decode(sent.payload_b64).decode('utf-8'))
        expected=build_payload(n,budget,primes,intersections)
        checked(received==expected,'cycle%d_received_payload_rechecks'%c,checks)
        checked(sent.event_id in s.view().received_send_ids, 'cycle%d_S_records_send'%c,checks)
        capture((c-1)*4+2,f'cycle {c}: SEND delivered to S')
        ack=s.acknowledge(f'integrated-ack-{c}',sent.event_id)
        checked(ack.ref_event_id==sent.event_id, 'cycle%d_ACK_corresponds_to_send'%c,checks)
        capture((c-1)*4+3,f'cycle {c}: ACK created')
        transport.route(ack)
        returned=transport.deliver()
        checked(returned.status=='APPLIED','cycle%d_returned_to_O'%c,checks)
        checked(ack.event_id in o.view().received_ack_ids,'cycle%d_O_records_ACK'%c,checks)
        capture(c*4,f'cycle {c}: ACK delivered to O (return)')
        cycle_rows.append({
            'cycle':c, 'phase_step':n, 'prime_position':n+1,
            'prime_digit':payload['prime_position']['digit'],
            'relative_phase_deg':payload['phase']['relative_phase_deg_mod_360'],
            'crossings':payload['phase']['intersections'],
            'witness_budget':budget,
            'witness_best_axes':','.join(payload['witness']['best_within_budget']['axes']),
            'witness_squared_loss':payload['witness']['best_within_budget']['native_squared_loss_after'],
            'SEND_event_sha256':sent.event_id,
            'payload_sha256':sent.payload_sha256,
            'ACK_event_sha256':ack.event_id,
            'O_raw_count':len(o.raw), 'S_raw_count':len(s.raw),
            'O_view_sha256':digest(canonical(o.view().to_dict())),
        })
        if c==1:
            first_o,first_s=o.raw,s.raw
        prior_return={'O':o.view().to_dict(),'S':s.view().to_dict()}
    checked(o.raw[:len(first_o)]==first_o and s.raw[:len(first_s)]==first_s,
            'first_cycle_raw_is_exact_prefix',checks)
    checked(len(o.raw)==len(s.raw)==4,'two_returns_four_raw_records_per_endpoint',checks)
    previous_views=(o.view().to_dict(),s.view().to_dict())
    last=o.retry('integrated-send-2')
    capture(9,'retry second SEND')
    transport.route(last)
    dup=transport.deliver()
    capture(10,'duplicate delivery at S')
    checked(dup.status=='DUPLICATE', 'retry_is_duplicate',checks)
    checked((o.view().to_dict(),s.view().to_dict())==previous_views,
            'retry_does_not_repeat_view_effect',checks)
    checked(len(o.raw)==len(s.raw)==5,'retry_adds_raw_records_only',checks)
    checked(verify_raw_ledger(o.raw)==(),'O_RAW_chain_valid',checks)
    checked(verify_raw_ledger(s.raw)==(),'S_RAW_chain_valid',checks)
    checked(transport.queued_event_ids==(),'lambda_queue_empty',checks)
    checked((cycle_rows[1]['phase_step']-cycle_rows[0]['phase_step'])==84,
            'adjacent_84_step_checkpoints',checks)
    checked((int(cycle_rows[1]['relative_phase_deg'])-int(cycle_rows[0]['relative_phase_deg']))==7,
            'seven_degree_return_difference',checks)
    trace={
        'schema':'phase-relay-witness-execution/v1',
        'scope':'NEW adapter binds independently computed prime/phase/witness records as opaque relay payloads; no autonomous or physical coupling is claimed',
        'T':'Logical t_index only; T denotes a time coordinate, not an outcome selector. No physical sampling interval.',
        'architecture':'O and S independent endpoints; lambda transport; 2 externally initiated consecutive returns using same instances',
        'checks':checks,'cycles':cycle_rows,'snapshots':snapshots,
        'final':{'O':{'RAW':[r.to_dict() for r in o.raw],'VIEW':o.view().to_dict()},
                 'S':{'RAW':[r.to_dict() for r in s.raw],'VIEW':s.view().to_dict()}},
    }
    return trace


def main():
    out=ROOT/'outputs';out.mkdir(exist_ok=True)
    a=run();b=run()
    a['checks']['deterministic_repeat']=canonical(a)==canonical(b)
    failures=[k for k,v in a['checks'].items() if not v]
    trace_path=out/'integrated_trace.json'
    trace_path.write_bytes(json.dumps(a,indent=2,ensure_ascii=False).encode('utf-8')+b'\n')
    with (out/'integrated_summary.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(a['cycles'][0]))
        writer.writeheader();writer.writerows(a['cycles'])
    names=('corner_relay/corner_relay.py','geometry_quantum_witness.py',
           'prime_lattice_audit/inputs/prime_double_key_coordinates.csv',
           'prime_lattice_audit/phases/intersection_counts.csv')
    receipt={
        'status':'PASS' if not failures else 'FAIL',
        'python':platform.python_version(),
        'check_count':len(a['checks']),
        'failures':failures,
        'cycle_count':len(a['cycles']),
        'source_sha256':{name:digest((SOURCE/name).read_bytes()) for name in names},
        'new_adapter_sha256':digest(Path(__file__).read_bytes()),
        'trace_sha256':digest(trace_path.read_bytes()),
        'trace_file':str(trace_path),
        'scope':'Finite deterministic adapter run. Original sources were not edited.',
    }
    (out/'integrated_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'receipt':receipt,'cycles':a['cycles']},indent=2))
    return int(bool(failures))

if __name__=='__main__':
    raise SystemExit(main())
