PRIME LATTICE / THREE-WORKER PYTHON AUDIT
11 November 2026

Run with Python 3.10 or newer:
    python run_all.py
No third-party Python packages are required. Each worker's script can also run
separately. Original source files are included in inputs/ and are read only.

METHOD
Three separate worker instances wrote numerical checks for different subjects.
They shared conversation context, so this is not a blinded review or a comparison
of different model providers. The deliverable is executable evidence, including
input hashes, generated results, and preserved discrepancies.

1. PRIME DATA: PASS
Fresh trial-division generation matches all 2,701 workbook cells.
Center of 73 columns x 37 rows: row19, column37 (AK19), prime11,159.
Generated 23x23 prime-value center: prime1,697.
Double keys: 529 positions ->43; 913 ->74; 14,351 ->732.
Digit counts in the largest selection: 2:105, 3:261, 5:120, 7:246.
All 5,124 coordinate CSV fields and 172,212 repeat CSV fields match.
Copied marks1,169; actual hits732; overlap104.
Negative control: an in-memory digit mutation3->9 is detected exactly once.
The repeat operation is linear repetition of a529-character mask followed by
113-column reshaping, not a two-dimensional spatial tiling operation.

2. ROTATIONS: ARITHMETIC PASSES; IMAGE/SOURCE MISMATCH RETAINED
Opposing231/132 phases give relative angle B*n/84.
For B360: relative return84 steps, joint individual return924 steps.
For B367: relative return30,240 steps, joint individual return332,640 steps.
At n924, relative residual is77 degrees.
The grid diagonal uses stream_position=1+84*k, not elapsed step84*k.
It advances along row=column for k0..82, then wraps at k83 to row85,column1.
Only k0..10 fits the displayed83-column x11-row grid.

The attached four-panel367-degree chart shows6 crossings at step0 and a4/6 curve.
The ZIP's explicit sample hook/square gives2 crossings at step0 and at every
84-step checkpoint through924. Its full B367 run0..924 has counts0,2,4,6.
Two numerical crossing methods agree, with sensitivity checked at three tolerances.
The coordinator also independently checked step0 using exact rational arithmetic:
  (99/100, 2017/8500) and (459/2450, 7/10).
Conclusion: the attached chart is not reproduced by this ZIP's sample geometry.
The chart's original vertex data/generator must be located before assigning a cause.
This does not establish that the chart is wrong for some other declared geometry.

The231-step encounter image declares additional irrational increments and belongs
to a different model. The absent23-degree invariant SVG was not reconstructed
from a PNG. Physical resonance and a7.83Hz time base were not tested.

3. WITNESS CALCULATIONS:11 CHECKS PASS; ONE WORDING ERROR
Exact Fraction calculations use pairwise variance rather than the paper's mean rule.
Two-state loss1/16, one conflicting pair; addedX repairs loss to0.
Seven-state loss1/7, ten conflicting pairs; addedY orX gives1/14; both give0.
At declared costs Y1 and X2: frontier is none,Y,XY; budget1 selectsY.
The shared-center non-descent example holds for the two retained source records.
The prime worker independently supplies their values; the witness worker treats
those values as inputs, not a second independent prime generation.

Master line131 says 'Any function of R recovers W'. That universal statement is
false: a constant function is a counterexample. The correct statement is that
there exists g such that W=g composed with the refinement map(pi,W).
The second-coordinate projection is one such g. No source document was edited.
Static recovery does not establish autonomous state updates without a declared U.

FILES
primes/: script, resultsJSON, report.
phases/: script, resultsJSON, per-step intersectionCSV, report when present.
witness/: script, resultsJSON, report.
inputs/: unmodified sources needed to reproduce this audit or inspect its claims.
SHA256SUMS.json: hashes of the packaged files before rerunning.

LIMITS
Execution success is not a blanket PASS on every supplied claim. Keep the geometry
mismatch and quantifier error above. This audit does not reproduce the original
quantum engine's complete self-test suite, prove statistical novelty, or validate
the full Trident architecture or any physical mechanism. No Site was changed.
