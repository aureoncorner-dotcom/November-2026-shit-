#!/usr/bin/env python3
"""Independent finite witness audit; stdlib only; original inputs remain unchanged.

Run: python audit_witness.py --input-dir /path/to/upload
Loss uses the pairwise variance identity, independently of the source appendix's
fiber-mean implementation. Fractions remain exact throughout.
"""
from fractions import Fraction as F
from itertools import combinations
from collections import defaultdict
from pathlib import Path
import argparse
import hashlib
import json

AXES = "XYZ"
BLOCH = {
    "|0>": (0, 0, 1), "|1>": (0, 0, -1),
    "|+>": (1, 0, 0), "|->": (-1, 0, 0),
    "|+i>": (0, 1, 0), "|-i>": (0, -1, 0),
    "I/2": (0, 0, 0),
}

def probabilities(name, axes):
    return tuple(F(1 + BLOCH[name][AXES.index(a)], 2) for a in axes)

def audit(names, retained, target):
    fibers = defaultdict(list)
    for name in names:
        fibers[probabilities(name, retained)].append(name)
    weighted_scatter = F(0)
    conflicts = []
    for signature, members in fibers.items():
        pair_scatter = F(0)
        for a, b in combinations(members, 2):
            wa, wb = probabilities(a, target), probabilities(b, target)
            pair_scatter += sum((x - y)**2 for x, y in zip(wa, wb))
            if wa != wb:
                conflicts.append({"states": [a, b], "retained_signature": list(signature),
                                  "witnesses": [list(wa), list(wb)]})
        # Sum squared distance to mean = (sum unordered pair distances squared)/m.
        weighted_scatter += pair_scatter / len(members)
    return {"retained": list(retained), "target": list(target),
            "loss": weighted_scatter / len(names), "collision_pairs": conflicts,
            "collision_count": len(conflicts)}

def options(names, retained, target, costs):
    ans = []
    candidates = sorted(set(costs) - set(retained))
    for size in range(len(candidates) + 1):
        for added in combinations(candidates, size):
            record = audit(names, retained + added, target)
            ans.append({"added": list(added), "cost": sum(costs[a] for a in added),
                        "loss": record["loss"], "collision_count": record["collision_count"]})
    for o in ans:
        o["frontier"] = not any(
            z["cost"] <= o["cost"] and z["loss"] <= o["loss"]
            and (z["cost"] < o["cost"] or z["loss"] < o["loss"])
            for z in ans)
    return sorted(ans, key=lambda o: (o["cost"], o["added"]))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", "--source-dir", dest="source_dir", type=Path,
                        default=Path(__file__).resolve().parents[1] / "inputs")
    args = parser.parse_args()
    two = audit(["|+>", "I/2"], ("Z",), ("X",))
    two_repaired = audit(["|+>", "I/2"], ("Z", "X"), ("X",))
    seven = audit(list(BLOCH), ("Z",), tuple(AXES))
    batches = options(list(BLOCH), ("Z",), tuple(AXES), {"X": 2, "Y": 1})
    best = min((o for o in batches if o["cost"] <= 1), key=lambda o: (o["loss"], o["cost"]))
    full = min((o for o in batches if o["loss"] == 0), key=lambda o: o["cost"])
    checks = {
        "two_state_loss_1_16": two["loss"] == F(1, 16),
        "two_state_one_conflict": two["collision_count"] == 1,
        "two_state_X_repair_zero": two_repaired["loss"] == 0,
        "seven_state_loss_1_7": seven["loss"] == F(1, 7),
        "seven_state_ten_conflicts": seven["collision_count"] == 10,
        "all_option_losses": [o["loss"] for o in batches] == [F(1,7), F(1,14), F(1,14), F(0)],
        "all_option_costs": [o["cost"] for o in batches] == [0,1,2,3],
        "frontier_none_Y_XY": [o["added"] for o in batches if o["frontier"]] == [[],["Y"],["X","Y"]],
        "budget_1_best_Y_partial": best["added"] == ["Y"] and best["loss"] == F(1,14),
        "minimum_full_repair_XY_cost3": full["added"] == ["X","Y"] and full["cost"] == 3,
    }
    center_records = [
        {"grid": "23x23", "coordinate": [0,0], "witness": 1697},
        {"grid": "73x37", "coordinate": [0,0], "witness": 11159},
    ]
    centers = {"input_status": "Values supplied to this witness audit; prime generation is a separate audit.",
               "records": center_records, "same_coordinate": center_records[0]["coordinate"] == center_records[1]["coordinate"],
               "different_witness": center_records[0]["witness"] != center_records[1]["witness"],
               "non_descent_locus": [[0,0]], "fiber_diameter_absolute_difference": 11159-1697,
               "repair": "Keep grid identity and fixed grid definition with coordinate; two singleton fibers.",
               "autonomy": "Not established: no update U on these records was supplied."}
    checks["two_center_exact_collision"] = centers["same_coordinate"] and centers["different_witness"]
    files = ["geometry_quantum_witness_execution_report(6).txt",
             "Geometry_Master_2.10_maximum_improved(6).md", "Geometry_Consolidated_Paper(7).pdf"]
    provenance = [{"file": n, "sha256": hashlib.sha256((args.source_dir/n).read_bytes()).hexdigest()}
                  for n in files]
    master = (args.source_dir/files[1]).read_text()
    wording = {"found": "Any function of \\(R\\) recovers \\(W\\)" in master,
               "status": "False as written; a quantifier correction is required.",
               "correct_statement": "There exists g on im(pi,W) such that W = g composed with (pi,W); second-coordinate projection is one such g.",
               "counterexample": "In the master miniature W(b)=1, but the constant-zero function on R returns 0 at b.",
               "autonomy_separate": "For a specified U:D->D, test pi(x)=pi(y) implies pi(Ux)=pi(Uy). Static witness recovery alone does not prove this."}
    assert all(checks.values()), checks
    output = {"scope": "Finite ideal probabilities, uniform state weights, squared Euclidean loss on target probability vectors; costs are declared inputs.",
              "method": "Exact Fraction arithmetic; pairwise variance identity; exhaustive candidate batch enumeration.",
              "source_provenance": provenance, "checks": checks, "two_state": two,
              "two_state_repaired": two_repaired, "two_state_added_X_cost": 1,
              "seven_state": seven, "measurement_options": batches, "best_budget_1": best,
              "minimum_cost_full_repair": full, "shared_center": centers, "wording_issue": wording,
              "not_verified": ["Original engine built-in self-test suite, invalid-input handling, and decimal parser: no full engine source in these three files.",
                               "Hardware, finite-shot accuracy, one-shot tomography, physical acquisition costs, or entire Trident dynamics."]}
    dest = Path(__file__).with_name("results.json")
    dest.write_text(json.dumps(output, indent=2, default=str) + "\n")
    print(json.dumps({"passed_checks": len(checks), "failed_checks": 0,
                      "wording_issue_found": wording["found"], "results": str(dest)}, indent=2))

if __name__ == "__main__":
    main()
