#!/usr/bin/env python3
"""Reproduce all three worker audits with Python 3.10+; no pip packages required."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
for script in ('primes/audit_primes.py', 'phases/audit_phases.py', 'witness/audit_witness.py'):
    print('\nRUNNING ' + script, flush=True)
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
print('\nAll scripts completed. Read README.txt: successful execution does not resolve the image/source mismatch.')
