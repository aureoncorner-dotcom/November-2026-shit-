# Independent phase and geometry audit

The attached v0.5 ZIP was inspected as source text. Its plotting program was not executed. A separate Python standard-library implementation extracted the two literal vertex arrays and reproduced the declared rotation model. The JSON includes SHA-256 identifiers for the ZIP, code, and design review.

## Exact arithmetic: reproduced

With Cartesian counterclockwise angles positive, the hook is `-B*n/231`, the square is `+B*n/132`, and their relative angle is `B*n/84`. The denominator follows from the exact identity `1/231 + 1/132 = 1/84`.

| Numerator B | First positive relative-phase return, integer steps | Hook orientation return | Square orientation return | Both absolute orientations return |
|---|---:|---:|---:|---:|
| 360 degrees | 84 | 231 | 132 | 924 |
| 367 degrees | 30,240 | 83,160 | 47,520 | 332,640 |

At `n=84k`, the 367-degree relative residual is `7k mod 360`. Thus `k=11`, `n=924`, gives 77 degrees. At `n=30,240` the relative residual is zero, but both individual angles are `2160/11 degrees mod 360`, not zero. Relative alignment and return to both starting orientations are different tests.

These first-return values follow from exact divisibility: for relative phase, the period is `30240/gcd(B,30240)`; individual periods are `83160/gcd(B,83160)` and `47520/gcd(B,47520)`, with the joint period their least common multiple.

## Indexing: reproduced, with scope

For 83 columns and one-based stream positions, the displayed diagonal uses `n=1+84k`, not `n=84k`:

- `row = k + floor(k/83) + 1`
- `column = (k mod 83) + 1`

For `k=0..10`, positions `1,85,169,253,337,421,505,589,673,757,841` occupy `(1,1)..(11,11)` within the 913-position grid. At `k=11`, position925 is outside that grid. On an extended grid, the first column wrap occurs at `k=83`, position6973, coordinate `(row85,column1)`. The diagonal is an indexing result, not evidence that all checkpoint sites pass the prime-digit selection rule.

## Rigid geometry: reproduced for the ZIP sample

The hook has the five explicit open-path vertices in the JSON. The square is translated by `(0.19,-0.10)` before rotation. Its four side lengths squared are exactly `64/25`, and adjacent edge dot products are exactly zero. Rotations preserve all pairwise distances analytically; across both bases and all integer steps0..924, the maximum numerical squared-distance discrepancy was approximately `4.44e-15`, below the declared `1e-12` test tolerance.

This verifies the ZIP's sample geometry. It does not verify the different 23-degree invariant PNG's unseen vector coordinates.

## Intersection-image provenance mismatch: unresolved

The supplied 367-degree audit image shows a line-segment intersection curve ranging over 4 and6, with6 shown at step0. That curve is not reproduced by the explicitly declared ZIP sample. Under distinct-point intersection counting, the ZIP sample has exactly two crossings at step0:

| Zero-based hook segment | Zero-based square segment | Exact x | Exact y |
|---:|---:|---:|---:|
| 1 | 1 | 99/100 | 2017/8500 |
| 1 | 2 | 459/2450 | 7/10 |

Across integer steps0..924 inclusive:

| Base | 0 crossings | 2 crossings | 4 crossings | 6 crossings |
|---|---:|---:|---:|---:|
| 360 | 0 | 408 | 517 | 0 |
| 367 | 4 | 435 | 479 | 7 |

All twelve 84-step checkpoints from0 through924 have two crossings in both tested models.

Conventions: segment endpoints are included; duplicate points are merged; positive-length collinear overlap is recorded separately, rather than treated as one point. The sweep contained no endpoint contacts or collinear overlaps. Results were identical with tolerances `1e-12`, `1e-10`, and `1e-8` in normalized coordinates. A second proper-crossing check using opposite-side orientation predicates agreed at every sampled step. The step0 result was also computed with exact rational arithmetic.

This establishes a mismatch between the supplied image's reported curve and this ZIP's sample, not that the image's unknown generating model is false. The next test is to obtain the actual code/vertices that generated that four-panel image and compare them without changing either source.

## Separate models and boundaries

- The 231-step encounter image advertises additional `sqrt(pi)` and `phi*(sqrt(2))**sqrt(3)` increments. Those are different rate rules from fixed `B=367`; its near-encounter markers need their own source code and threshold. They have not been certified here.
- The ZIP explicitly labels its shell and vertices as design parameters. No prime derivation is asserted for these coordinates.
- The 7.83Hz reference is not mapped to the dimensionless step index; no physical time or resonance conclusion follows.
- The v0.5 experimental module does not provide a complete operational transition map for all Trident chambers, and the packet states that v0.4 remains unchanged.

## Reproduction

From the audit package root:

```sh
python phases/audit_phases.py
```

Or pass `--input-dir PATH` and `--output-dir PATH`. Required input: `trident_engine_irregular_return_v05_concept(1).zip`. Outputs: `phase_audit.json` and `intersection_counts.csv`. No third-party Python packages are needed.
