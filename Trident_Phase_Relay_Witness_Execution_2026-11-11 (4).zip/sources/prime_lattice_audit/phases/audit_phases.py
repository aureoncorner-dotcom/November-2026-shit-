#!/usr/bin/env python3
"""Independent audit; Python standard library only. Original inputs are read-only.

Run: python audit_phases.py --input-dir ../inputs --output-dir .
Default input directory is inputs/ in the audit package root.
No source code from the ZIP is executed.
"""
import ast
import argparse
import csv
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input-dir',type=Path,default=Path(__file__).resolve().parents[1]/'inputs')
parser.add_argument('--output-dir',type=Path,default=HERE)
args=parser.parse_args()
INPUT = args.input_dir/'trident_engine_irregular_return_v05_concept(1).zip'
OUT = args.output_dir
OUT.mkdir(parents=True, exist_ok=True)

with ZipFile(INPUT) as z:
    build_bytes = z.read('trident_v05/build.py')
    review_bytes = z.read('trident_v05/TRIDENT_ENGINE_V05_DESIGN_REVIEW.md')
tree=ast.parse(build_bytes.decode())
arrays={}
for node in tree.body:
    if isinstance(node,ast.Assign) and isinstance(node.value,ast.Call):
        for target in node.targets:
            if isinstance(target,ast.Name) and target.id in ('hook','sq'):
                arrays[target.id]=ast.literal_eval(node.value.args[0])
H=[tuple(p) for p in arrays['hook']]
Q=[(x+.19,y-.10) for x,y in arrays['sq']]
assert H==[(-1.35,-.95),(-.68,1.2),(1.02,.22),(1.42,-.49),(1.11,-.83)]
assert F(1,231)+F(1,132)==F(1,84)

def exact_phase(n,B):
    h=-F(B*n,231)
    q=F(B*n,132)
    return dict(step=n,base=B,hook_unwrapped=str(h),square_unwrapped=str(q),
                hook_wrapped=str(h%360),square_wrapped=str(q%360),relative_wrapped=str((q-h)%360))

def periods(B):
    rel=30240//math.gcd(B,30240)
    hook=83160//math.gcd(B,83160)
    square=47520//math.gcd(B,47520)
    joint=math.lcm(hook,square)
    assert F(B*rel,84)%360==0
    assert F(B*joint,231)%360==F(B*joint,132)%360==0
    return dict(relative=rel,hook=hook,square=square,both_absolute=joint)

def rotate(points,deg):
    t=math.radians(deg%360)
    c,s=math.cos(t),math.sin(t)
    return [(c*x-s*y,s*x+c*y) for x,y in points]

def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def distance2(a,b):return (a[0]-b[0])**2+(a[1]-b[1])**2

def intersections(a,b,eps):
    """Return distinct crossing points, endpoint contacts, and overlap pairs.

    Segment parameter bounds inclusive within eps; denominator and collinearity
    tests use eps in normalized coordinates. Points deduplicated within eps.
    Positive-length collinear overlap is a separate event, not a finite point.
    """
    pts=[]; contacts=0; overlaps=0; near_parallel=0
    for p,p1 in zip(a,a[1:]):
        r=sub(p1,p)
        for q,q1 in zip(b,b[1:]):
            s=sub(q1,q); d=cross(r,s); qp=sub(q,p)
            if abs(d)<=eps:
                near_parallel+=1
                if abs(cross(qp,r))<=eps:
                    rr=r[0]*r[0]+r[1]*r[1]
                    t0=(qp[0]*r[0]+qp[1]*r[1])/rr
                    t1=t0+(s[0]*r[0]+s[1]*r[1])/rr
                    lo=max(0,min(t0,t1));hi=min(1,max(t0,t1))
                    if hi-lo>eps:overlaps+=1
                    elif hi>=lo-eps:
                        v=(p[0]+lo*r[0],p[1]+lo*r[1]);contacts+=1
                        if not any(distance2(v,w)<=eps*eps for w in pts):pts.append(v)
                continue
            t=cross(qp,s)/d;u=cross(qp,r)/d
            if -eps<=t<=1+eps and -eps<=u<=1+eps:
                v=(p[0]+t*r[0],p[1]+t*r[1])
                if min(abs(t),abs(t-1),abs(u),abs(u-1))<=eps:contacts+=1
                if not any(distance2(v,w)<=eps*eps for w in pts):pts.append(v)
    return len(pts),contacts,overlaps,near_parallel

max_rigid_error=0.
orientation_check_mismatches=[]
counts={};rows=[]
for B in (360,367):
    hist={}; previous=None
    for eps in (1e-12,1e-10,1e-8):
        result=[];events=Counter()
        for n in range(925):
            h=rotate(H,-B*n/231);q=rotate(Q,B*n/132)
            for raw,rot in ((H,h),(Q,q)):
                for i in range(len(raw)):
                    for j in range(i):
                        max_rigid_error=max(max_rigid_error,abs(distance2(raw[i],raw[j])-distance2(rot[i],rot[j])))
            count,contacts,overlaps,parallel=intersections(h,q,eps)
            if eps==1e-10:
                # Independent proper-crossing predicate from side-of-line signs.
                proper=sum(cross(sub(b,a),sub(c,a))*cross(sub(b,a),sub(d,a))<0
                           and cross(sub(d,c),sub(a,c))*cross(sub(d,c),sub(b,c))<0
                           for a,b in zip(h,h[1:]) for c,d in zip(q,q[1:]))
                if contacts==overlaps==0 and count!=proper:orientation_check_mismatches.append([B,n,count,proper])
            result.append(count)
            events.update(endpoint_contacts=contacts,collinear_overlaps=overlaps,parallel_segment_pairs=parallel)
            if eps==1e-10:rows.append(dict(base=B,step=n,unique_intersections=count,endpoint_contacts=contacts,collinear_overlaps=overlaps))
        hist[str(eps)]={'counts':dict(Counter(result)), 'events':dict(events), 'same_as_previous_tolerance':None if previous is None else result==previous}
        previous=result
    counts[str(B)]={'tolerances':hist,'checkpoints':[{**exact_phase(84*k,B),'crossings':previous[84*k]} for k in range(12)]}

# Exact square properties from decimal source coordinates, before rigid rotation.
Qexact=[tuple(F(str(x)) for x in p) for p in arrays['sq']]
edges=[sub(b,a) for a,b in zip(Qexact,Qexact[1:])]
side2=[e[0]**2+e[1]**2 for e in edges]
dots=[a[0]*b[0]+a[1]*b[1] for a,b in zip(edges,edges[1:]+edges[:1])]
assert side2==[F(64,25)]*4 and dots==[0]*4
Hf=[tuple(F(str(x)) for x in p) for p in H]
Qf=[(x+F(19,100),y-F(1,10)) for x,y in Qexact]
zero_crossings=[]
for i,(p,p1) in enumerate(zip(Hf,Hf[1:])):
    r=sub(p1,p)
    for j,(q,q1) in enumerate(zip(Qf,Qf[1:])):
        s=sub(q1,q);d=cross(r,s)
        if d:
            t=cross(sub(q,p),s)/d;u=cross(sub(q,p),r)/d
            if 0<t<1 and 0<u<1:zero_crossings.append({'hook_segment':i,'square_segment':j,'x':str(p[0]+t*r[0]),'y':str(p[1]+t*r[1])})
assert len(zero_crossings)==2

diagonal=[]
for k in [*range(12),81,82,83,84]:
    n=1+84*k
    diagonal.append(dict(k=k,stream_position=n,row=(n-1)//83+1,column=(n-1)%83+1,within_913=n<=913))

report={
 'source':{'zip':INPUT.name,'zip_sha256':sha256(INPUT.read_bytes()).hexdigest(),'build_sha256':sha256(build_bytes).hexdigest(),'review_sha256':sha256(review_bytes).hexdigest(),'source_code_executed':False},
 'convention':'Cartesian positive counterclockwise; hook=-Bn/231; square=+Bn/132; relative=square-hook=Bn/84',
 'periods':{str(B):periods(B) for B in (360,367)},
 'sample_phases':[exact_phase(n,B) for B in (360,367) for n in (84,924,30240,332640)],
 'grid':{'columns':83,'formula':'stream_position=1+84*k; row=k+floor(k/83)+1; column=(k mod83)+1','examples':diagonal,'first_wrap_k':83,'first_wrap_coordinate':[85,1]},
 'geometry':{'hook':H,'square_translation':[.19,-.10],'square_side_squared_exact':list(map(str,side2)),'adjacent_edge_dot_products_exact':list(map(str,dots)),'maximum_pairwise_squared_distance_rotation_error':max_rigid_error,'rigid_rotation_pass_tolerance':1e-12},
 'intersection_audit':counts,
 'independent_orientation_check_mismatches':orientation_check_mismatches,
 'exact_step_zero_crossings':zero_crossings,
 'scope':['The supplied 367-degree image advertises intersection counts 4/6. Comparison is with the explicitly declared ZIP sample, not coordinates inferred from pixels.','The supplied 231-step encounter image advertises additional sqrt(pi) and phi*(sqrt(2))**sqrt(3) increments: it is a separate angular model, not the fixed B=367 model. Exact marker threshold/source unavailable here.','The 23-degree invariant illustration is a PNG here. This audit does not reconstruct or verify its vector coordinates.','v0.5 sample vertices and chamber positions are declared design parameters; no prime-derived or physical claim is inferred.']}
assert max_rigid_error<1e-12
assert not orientation_check_mismatches
(OUT/'phase_audit.json').write_text(json.dumps(report,indent=2)+'\n')
with (OUT/'intersection_counts.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps({k:report[k] for k in ['periods','geometry']},indent=2))
print('INTERSECTION HISTOGRAMS',json.dumps({B:r['tolerances']['1e-10']['counts'] for B,r in counts.items()}))
print('CHECKPOINT CROSSINGS',json.dumps({B:[r['crossings'] for r in d['checkpoints']] for B,d in counts.items()}))
print('TOLERANCE CHECK',all(d['tolerances'][e]['same_as_previous_tolerance'] for d in counts.values() for e in ('1e-10','1e-08')))
