# Trident phase → relay → witness execution

Executed on 2026-11-11 (America/New_York) with Python 3.13.5.

## Result

- Original Corner Relay `run_with_provenance.py`: **20/20 tests passed**.
- Original `check_two_returns.py`: **22/22 checks passed**; regenerated trace matches the previously uploaded trace SHA-256 `83559f23f1f2c74d6ae52be7db1f042ffa67ce0afbd36b5a56d2e26eac792e16`.
- Original finite witness `--self-test`: **PASS**.
- Original prime/phase/witness `run_all.py`: **all 3 workers complete**, finite witness worker **11/11 passed**.
- New `integration/run_phase_relay_witness.py`: **29/29 checks passed**; two returns and a duplicate delivery using unchanged relay and unchanged witness engine.

## Two explicitly selected checkpoint payloads

| Cycle | Rotational step n | 11×83 prime-stream position n+1 | prime digit | relative phase B=367° | hook/square crossings | externally selected witness budget | best added axes | remaining squared loss |
|---|---:|---:|---:|---:|---:|---:|---|---:|
| 1 | 336 | 337 | 3 | 28° | 2 | 1 | Y | 1/14 |
| 2 | 420 | 421 | 3 | 35° | 2 | 3 | X,Y | 0 |

`n+1` is the declared 83-column checkpoint map. Selecting two prime double-key hits is an **illustrative selection**, not a statistical finding or a discovered causal relation. The witness example is an independent seven-state, ideal-probability fixture. Budgets are chosen externally to make partial versus full repair inspectable.

The relay's O and S endpoints are retained between both SEND/ACK returns. Each SEND embeds canonical JSON containing separately computed phase, prime-site, and witness-fixture records. `LambdaTransport` routes the bytes without interpreting them. The adapter decodes and recomputes the payload at the receiving side. ACK events return to O, leaving distinct identities and append-only histories. Retrying the second SEND grows RAW histories without reproducing the operational effect. `t_index` is logical order, not measured seconds. T denotes a time coordinate in the current DECURSE interpretation; the legacy relay code uses a different T notation for its transition relation.

## Files

- `integration/run_phase_relay_witness.py` — new adapter and 29-check harness.
- `outputs/integrated_receipt.json` — status, source fingerprints, new adapter hash, trace hash.
- `outputs/integrated_trace.json` — full snapshots, messages, witness records and RAW/VIEW histories.
- `outputs/integrated_summary.csv` — compact two-row result.
- `sources/corner_relay/` — run copies of supplied, unchanged implementation and original tests.
- `sources/prime_lattice_audit/` — supplied audit sources, inputs, and reproduced results.
- `sources/geometry_quantum_witness.py` — exact pinned source (SHA-256 `57cab884c7ddb457b96f6b86dba469fe5168d0dcb708e18e347d53e6bfc90d5b`).
- `original_*.log` / `integrated_execution.log` — captured run logs.
- `SHA256SUMS.json` — per-file hashes for this bundle.

## Reproduce

Use Python 3.10 or later, standard library only. From the unzipped bundle root:

```bash
python sources/corner_relay/run_with_provenance.py
python sources/corner_relay/check_two_returns.py --output-dir original_two_returns
python sources/geometry_quantum_witness.py --self-test
python sources/prime_lattice_audit/run_all.py
python integration/run_phase_relay_witness.py
```

The first and fourth commands regenerate some output files **inside the extracted copy**. They do not change the original uploaded ZIPs.

## Scope / remaining gaps

This is a new externally scheduled interface test. It does **not** establish autonomous initiation, a recursive-versus-progressive classifier, a separate evolving lambda-prime state, physical sampling time, 13-chamber operational integration, a deployed website, or a quantum hardware result. Nor does it establish prime–phase–witness causal coupling. It only proves the specified integration behavior against the test fixtures and code supplied here.
