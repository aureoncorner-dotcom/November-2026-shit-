"""Package the figure, its data, and its renderer; verify all saved bytes."""
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from PIL import Image

root=Path(__file__).resolve().parents[1]
ET.parse(root/'367_phase_prime_corrected.svg')
with Image.open(root/'367_phase_prime_corrected.png') as image:
    assert image.size==(2400,1680)
    image.verify()
files=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts)
manifest=[{'path':p.relative_to(root).as_posix(),'size_bytes':p.stat().st_size,
           'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
archive=root.parent/'367_phase_prime_corrected.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[root/'manifest.json']:
        z.write(p,'corrected_367_figure/'+p.relative_to(root).as_posix())
with ZipFile(archive) as z:
    assert z.testzip() is None
    for record in manifest:
        assert hashlib.sha256(z.read('corrected_367_figure/'+record['path'])).hexdigest()==record['sha256']
print(json.dumps({'path':str(archive),'bytes':archive.stat().st_size,'files':len(files)+1}))
