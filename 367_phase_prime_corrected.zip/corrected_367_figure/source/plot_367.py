"""Render verified numerical data to PNG and SVG. Requires Pillow only.

Rebuilds a scientific chart; does not edit any source image pixels.
Run: python source/plot_367.py
"""
import csv
import hashlib
import html
import itertools
import json
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
W,H,SCALE=2400,1680,2
BG='#07111f'; PANEL='#0e1a30'; GRID='#23334a'; BORDER='#42526a'
TEXT='#e3edf4'; MUTED='#a8b7c7'; GOLD='#ffce76'; CYAN='#72dce2'
PURPLE='#b6a4fa'; PINK='#ee8fbc'; GREEN='#79dfb6'
im=Image.new('RGB',(W*SCALE,H*SCALE),BG)
draw=ImageDraw.Draw(im)
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
     '<title>367 degree phase and prime stream: corrected crossing trace</title>',
     '<desc>Four numerical panels regenerated from verified model data. All 925 intersection samples are plotted. The 367 model has 0 crossings at 4 samples, 2 at 435, 4 at 479, and 6 at 7.</desc>',
     f'<rect width="{W}" height="{H}" fill="{BG}"/>']
font_cache={}


def font(size,bold=False):
    key=(size,bold)
    if key not in font_cache:
        choices=([Path('C:/Windows/Fonts/arialbd.ttf')] if bold else [Path('C:/Windows/Fonts/arial.ttf')])
        choices += [Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')]
        path=next((p for p in choices if p.is_file()),None)
        font_cache[key]=ImageFont.truetype(str(path),round(size*SCALE)) if path else ImageFont.truetype('DejaVuSans.ttf',round(size*SCALE))
    return font_cache[key]


def rect(box,fill,outline=None,width=1):
    x0,y0,x1,y1=box
    draw.rectangle(tuple(round(v*SCALE) for v in box),fill=fill,outline=outline,width=max(1,round(width*SCALE)))
    svg.append(f'<rect x="{x0}" y="{y0}" width="{x1-x0}" height="{y1-y0}" fill="{fill}" stroke="{outline or "none"}" stroke-width="{width}"/>')


def line(points,color,width=1.4):
    if len(points)<2:return
    draw.line([(round(x*SCALE),round(y*SCALE)) for x,y in points],fill=color,width=max(1,round(width*SCALE)),joint='curve')
    values=' '.join(f'{x:.5f},{y:.5f}' for x,y in points)
    svg.append(f'<polyline points="{values}" fill="none" stroke="{color}" stroke-width="{width}" stroke-linejoin="round" stroke-linecap="round"/>')


def circle(x,y,r,color,fill=None,width=1.7):
    draw.ellipse(tuple(round(v*SCALE) for v in (x-r,y-r,x+r,y+r)),fill=fill,outline=color,width=max(1,round(width*SCALE)))
    svg.append(f'<circle cx="{x:.5f}" cy="{y:.5f}" r="{r}" fill="{fill or "none"}" stroke="{color}" stroke-width="{width}"/>')


def text(x,y,value,size=21,color=TEXT,anchor='lm',bold=False,rotate=False):
    value=str(value)
    f=font(size,bold)
    if rotate:
        box=f.getbbox(value)
        tmp=Image.new('RGBA',(box[2]-box[0]+10*SCALE,box[3]-box[1]+10*SCALE),(0,0,0,0))
        ImageDraw.Draw(tmp).text((5*SCALE-box[0],5*SCALE-box[1]),value,font=f,fill=color)
        tmp=tmp.rotate(90,expand=True)
        im.paste(tmp,(round(x*SCALE-tmp.width/2),round(y*SCALE-tmp.height/2)),tmp)
        transform=f' transform="rotate(-90 {x} {y})"'
        svg_anchor='middle'
    else:
        draw.text((round(x*SCALE),round(y*SCALE)),value,font=f,fill=color,anchor=anchor)
        transform='';svg_anchor={'l':'start','m':'middle','r':'end'}[anchor[0]]
    svg.append(f'<text x="{x}" y="{y}" font-family="Arial, sans-serif" font-size="{size}" fill="{color}" text-anchor="{svg_anchor}" dominant-baseline="central" font-weight="{"bold" if bold else "normal"}"{transform}>{html.escape(value)}</text>')


def axes(box,xlim,ylim,xticks,yticks,xlabel,ylabel,title,inverted=False):
    x,y,w,h=box
    rect((x,y,x+w,y+h),PANEL,BORDER,1.1)
    xp=lambda v:x+(v-xlim[0])/(xlim[1]-xlim[0])*w
    yp=lambda v:y+((v-ylim[0])/(ylim[1]-ylim[0]) if inverted else 1-(v-ylim[0])/(ylim[1]-ylim[0]))*h
    for tick in xticks:
        px=xp(tick);line([(px,y),(px,y+h)],GRID,0.8)
        text(px,y+h+24,tick,18,MUTED,'mm')
    for tick in yticks:
        py=yp(tick);line([(x,py),(x+w,py)],GRID,0.8)
        text(x-14,py,tick,18,MUTED,'rm')
    text(x+w/2,y-36,title,25,TEXT,'mm')
    text(x+w/2,y+h+66,xlabel,21,MUTED,'mm')
    text(x-89,y+h/2,ylabel,21,MUTED,rotate=True)
    return xp,yp


rows=list(csv.DictReader((ROOT/'inputs/recomputed_steps.csv').open(encoding='utf-8',newline='')))
data=[r for r in rows if r['base_degrees']=='367']
assert [int(r['step']) for r in data]==list(range(925))
phase=[float(Fraction(r['relative_phase_exact'])) for r in data]
crossings=[int(r['segment_intersections']) for r in data]
assert Counter(crossings)==Counter({0:4,2:435,4:479,6:7})
assert crossings[0]==crossings[924]==2
checkpoints=list(csv.DictReader((ROOT/'inputs/checkpoints.csv').open(encoding='utf-8',newline='')))

text(W/2,66,'367° PHASE + 11 × 83 PRIME STREAM',42,GOLD,'mm',True)
text(W/2,117,'Rebuilt from verified model data  ·  corrected crossing trace  ·  revision 2',23,MUTED,'mm')

boxA=(130,225,1000,480);boxB=(1320,225,1000,480)
boxC=(130,935,1000,480);boxD=(1320,935,1000,480)
xticks=[0,200,400,600,800,924]

# A: exact per-step relative phases, plus exact 84-step checkpoints.
xp,yp=axes(boxA,(0,924),(0,370),xticks,[0,60,120,180,240,300,360],
           'Integer step n','Relative phase (degrees mod 360)','A / Relative phase and 84-step checkpoints')
line([(xp(n),yp(v)) for n,v in enumerate(phase)],PURPLE,1.55)
line([(xp(n),yp(phase[n])) for n in range(0,925,84)],GOLD,2.5)
for n in range(0,925,84):circle(xp(n),yp(phase[n]),4.8,GOLD,GOLD)
rect((149,242,443,280),PANEL,BORDER,0.8)
line([(164,261),(197,261)],GOLD,2.4);circle(181,261,4,GOLD,GOLD)
text(209,261,'84-step checkpoints',19,TEXT)
for n,label in [(84,'7°'),(420,'35°'),(924,'77°')]:
    text(xp(n)-8 if n==924 else xp(n)+10,yp(phase[n])-24,label,18,GOLD,'rm' if n==924 else 'lm')

# B: regenerate all 913 stream digits; keep every one of the 74 double-key hits.
primes=[];digits='';candidate=2
while len(digits)<913:
    if all(candidate%p for p in itertools.takewhile(lambda p:p*p<=candidate,primes)):
        primes.append(candidate);digits+=str(candidate)
    candidate+=1
is_prime=lambda p:p>=2 and all(p%d for d in range(2,math.isqrt(p)+1))
hits=[p for p in range(1,914) if is_prime(p) and digits[p-1] in '2357']
assert len(hits)==74
xp,yp=axes(boxB,(0.5,83.5),(0.5,11.5),list(range(1,82,10)),list(range(1,12)),
           'Column (83 columns)','Row (11 rows)','B / 74 double keys and the checkpoint diagonal',True)
for p in hits:
    row,col=divmod(p-1,83);px,py=xp(col+1),yp(row+1)
    rect((px-4.1,py-4.1,px+4.1,py+4.1),GOLD)
for r in checkpoints:
    px,py=xp(int(r['column_1_based'])),yp(int(r['row_1_based']))
    circle(px,py,8.0,CYAN,None,2)
    if r['double_key']=='True':text(px+12,py+3,r['stream_position'],18,TEXT)
text(boxB[0]+boxB[2]/2,boxB[1]+boxB[3]+102,'p = n + 1 = 84k + 1; 84 = 83 + 1 gives the diagonal.',20,MUTED,'mm')

# C: the five rate traces explicitly shown in the supplied figure.
xp,yp=axes(boxC,(0,924),(-2700,1700),xticks,list(range(-2500,1501,500)),
           'Integer step n','Signed clockwise angle (degrees, unwrapped)',
           'C / Five declared rates: signed angle = ±367n / p')
rates=[(231,1,GOLD,'231: CW'),(132,-1,CYAN,'132: CCW'),(913,1,PURPLE,'913: CW'),
       (1109,-1,PINK,'1109: CCW'),(4723,1,GREEN,'4723: CW')]
for p,sign,color,label in rates:
    line([(xp(n),yp(float(Fraction(sign*367*n,p)))) for n in range(925)],color,2.5)
rect((147,1303,575,1398),PANEL,BORDER,0.8)
for i,(p,sign,color,label) in enumerate(rates):
    lx=164+(i//3)*218;ly=1321+(i%3)*29
    line([(lx,ly),(lx+37,ly)],color,2.6);text(lx+49,ly,label,19,TEXT)

# D: ALL verified counts; line segments guide the eye between integer samples.
xp,yp=axes(boxD,(0,924),(-0.3,6.7),xticks,[0,2,4,6],
           'Integer step n','Distinct hook-square crossings',
           'D / Corrected intersections from v0.5 coordinates')
line([(xp(n),yp(v)) for n,v in enumerate(crossings)],CYAN,1.4)
for n in range(0,925,84):circle(xp(n),yp(crossings[n]),4.8,GOLD,GOLD)
rect((1334,944,2306,980),PANEL)
text(1820,962,'925 samples:  0 crossings × 4  ·  2 × 435  ·  4 × 479  ·  6 × 7',19,TEXT,'mm')
text(boxD[0]+boxD[2]/2,boxD[1]+boxD[3]+102,'n = 0 and n = 924 both have 2 crossings. Gold dots mark 84-step checkpoints.',19,MUTED,'mm')

text(W/2,1575,'Relative return: 30,240 integer steps   |   Both hook/square starting orientations: 332,640 steps',25,TEXT,'mm',True)
text(W/2,1623,'D uses the open hook and translated square rotated about their common origin. C explicitly defines the five plotted rates.',20,MUTED,'mm')

svg.append('</svg>')
(ROOT/'367_phase_prime_corrected.svg').write_text('\n'.join(svg)+'\n',encoding='utf-8')
im=im.resize((W,H),Image.Resampling.LANCZOS)
# Compact display palette; data coordinates and vector output are unchanged.
im=im.quantize(colors=256,method=Image.Quantize.MEDIANCUT)
im.save(ROOT/'367_phase_prime_corrected.png',optimize=True)
with (ROOT/'plotted_values.csv').open('w',encoding='utf-8',newline='') as f:
    columns=['step','relative_phase_degrees','intersection_count']+[f'CW_angle_{p}_degrees' for p,_,_,_ in rates]
    writer=csv.writer(f);writer.writerow(columns)
    for n in range(925):writer.writerow([n,str(Fraction(data[n]['relative_phase_exact'])),crossings[n]]+[str(Fraction(sign*367*n,p)) for p,sign,_,_ in rates])
metadata={'figure':'367_phase_prime_corrected','revision':2,'dimensions':[W,H],
          'audit_source_library_file_id':'libfile_c4a2f795e6188191b56c04f9131312a5',
          'method':'Deterministic chart rendering from verified numeric outputs; no generative image editing.',
          'samples_in_A_C_D':925,'double_keys_in_B':len(hits),'crossing_histogram':dict(sorted(Counter(crossings).items())),
          'n0_crossings':crossings[0],'n924_crossings':crossings[-1],
          'grid_highlights':[int(r['stream_position']) for r in checkpoints if r['double_key']=='True'],
          'all_five_rate_scope':'C explicitly defines the depicted +/-367n/p convention; it is not verification of a recovered five-layer generator.',
          'input_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'inputs').glob('*'))}}
(ROOT/'render_receipt.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
print(json.dumps(metadata,indent=2))
