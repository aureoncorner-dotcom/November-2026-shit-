367-DEGREE PHASE AND PRIME STREAM — CORRECTED FIGURE, REVISION 2

Open 367_phase_prime_corrected.png for the raster figure (2400 x 1680).
Open 367_phase_prime_corrected.svg for the scalable vector version.

This is a fresh numerical rendering of the verified data. It does not modify
the earlier images or claim to recover their original plotting program.

Panel D now uses all 925 computed intersection counts for B=367, n=0 through 924:
  0 crossings:   4 samples
  2 crossings: 435 samples
  4 crossings: 479 samples
  6 crossings:   7 samples
The counts at n=0 and n=924 are both 2. Every plotted 84-step checkpoint in this
range also has 2 crossings. Lines between integer samples only guide the eye.

Panel A uses exact rational relative phases converted to display coordinates.
Panel B retains all 74 prime-digit double-key hits, including diagonal hits at
stream positions 337, 421 and 673. The stream is the concatenation of ascending
primes, with one-based digit positions; p=n+1.

Panel C explicitly defines the five displayed signed clockwise rates:
  +367n/231, -367n/132, +367n/913, -367n/1109, +367n/4723 degrees.
The audit source defines the hook/square geometry. Panel C's extra rate traces
are an explicit plotting convention, not a recovered five-layer implementation.

The footer distinguishes the hook/square relative return at 30,240 integer
steps from return of both original orientations at 332,640 integer steps.

Source audit bundle: phase_367_audit_2026-11-11.zip
Library file ID: libfile_c4a2f795e6188191b56c04f9131312a5
The preserved inputs and their hashes are recorded in render_receipt.json.
The original supplied shape coordinates are in inputs/model.json.

Rebuild with Python 3.10+ and Pillow:
  python source/plot_367.py

plotted_values.csv contains all 925 plotted time steps, preserving rational
values rather than rounded display numbers. The reusable renderer, verified
input tables, and numerical audit receipt are included. manifest.json contains
SHA-256 hashes for every packaged file other than the manifest itself.
