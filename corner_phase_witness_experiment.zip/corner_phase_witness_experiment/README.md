# Corner Relay / 367-degree phase / witness integration experiment

This is a runnable integration experiment, with preserved source modules and
new adapter code kept separately. It carries the same Corner Relay endpoints
through two SEND/ACK returns, associates every action with an integer model
step, exact phase values, a declared time coordinate, and a geometric crossing
count, then runs the verified witness module on an explicit finite encoding.

## Run

Requires Python 3.12 or newer; no third-party packages or network are needed.
Extract the complete package and, from this directory, run:

```text
python run_experiment.py
```

On the original Windows computer, the tested Python 3.12.14 interpreter was
available through the existing Codex runtime rather than the command search
path. From this package directory, the equivalent PowerShell command is:

```powershell
& 'C:\Users\Andrew\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -B .\run_experiment.py
```

The command runs the supplied acceptance tests and new integration checks. It
returns exit code 0 only on success. Each invocation creates a new directory
under `runs/`; `latest_run.json` records RUNNING, PASS, or FAIL for the latest
invocation. To choose a new output directory:

```text
python run_experiment.py --out "my new run"
```

The output directory must not already exist. Preserved tests that write beside
their source run only in disposable copies under the new run's `scratch/`.
Source hashes are checked before and after execution. A failed run publishes a
failure receipt instead of leaving an old PASS as its current result.

## Files and evidence

- `adapter.py`: new adapter, endpoint continuity, opaque measurement payloads,
  phase/time association, and explicit witness encoding.
- `provided_tests.py`: new orchestration around unchanged supplied test files.
- `phase_checks.py`, `integration_checks.py`: new independent assertions.
- `run_experiment.py`: fresh-run lifecycle, replay, negative controls, hashes.
- `sources/`: preserved archive members and standalone supplied files. Existing
  receipts here are historical evidence, not results from this integration.
- `source_manifest.json`: SHA-256 and byte count for every preserved file.
- `acquisition_receipt.json`: exact local source paths, archive hashes and
  modification times, plus the limitation on recovering the linked chat.
- `runs/<run-id>/receipt.json`: runtime, code/source/output hashes, commands,
  fresh test summaries, original-preservation check, and final status.
- `runs/<run-id>/integration_trace.json`: complete endpoint ledgers, action
  snapshots, measurement payloads, witness inputs, and full witness outputs.
- `runs/<run-id>/phase_checks.json`, `integration_checks.json`, and
  `negative_checks.json`: assertions and finite-model findings.

The `sources/witness_audit/specimens/` directory deliberately contains faulty
test copies from the supplied audit. They are diagnostic fixtures. The adapter
loads only `sources/witness_download/geometry_quantum_witness.py`, pinned to
SHA-256 `57cab884c7ddb457b96f6b86dba469fe5168d0dcb708e18e347d53e6bfc90d5b`.

## Exactly what is associated

The default schedule has 11 observations: initial state, four actions for the
first return, four for the second return, retry, and duplicate delivery.
Observation `i` has integer step `n = 84*i`, covering 0 through 840. This
schedule is chosen by this experiment; it was not recovered from an autonomous
engine. `t_index` is action order. `model_time = n*dt`, with default `dt=1`
declared model tick per step, is a synthetic time coordinate. Native ledger
`record_no` remains a separate local counter. The relay packet's `T` means
transition relation; the adapter does not redefine it as temporal time.

For base `B=367`, the preserved phase audit recomputes:

```text
hook orientation   = (-B*n/231) mod 360
square orientation = ( B*n/132) mod 360
relative phase     = ( B*n/84)  mod 360
```

The adapter consumes that fresh table and independently verifies its exact
angles. Geometric crossing counts come from the supplied audit's rotation and
intersection code, using the supplied open hook and shifted square geometry.
They are numerical geometry results, with the audit's tolerance and independent
predicate checks, rather than exact rational intersection proofs.

SEND payloads contain their measurement and a hash of the preceding returned
endpoint views. The relay transports opaque bytes. Its ACK API has no
measurement payload parameter: the adapter records return measurements beside
the ACK event ID and preserves the ACK reference to the corresponding SEND.
The phase data does not drive a new relay control law.

## Witness interpretation

The adapter creates exact rational coordinates for each observation:

```text
X = relative_phase_degrees / 720
Y = integer_step / (2*924)
Z = crossing_count / (2*maximum_segment_pairs)
```

All coordinates have magnitude at most 1/2 on this domain, so the squared norm
is at most 3/4. The retained axis is Z and target axis X. The witness therefore
tests whether crossing count identifies the encoded phase among the supplied
records. X has offered cost 1; Y has cost 2; the budget is 1. These are declared
test costs, not empirical measurement costs. Controls retain phase or step,
and a further control offers no repair measurements.

This mapping is new adapter logic, not a native connection between the source
modules or a claim that the relay emits physical quantum states. The witness
uses `pX = 1/2 + phase/1440`, so its squared loss is in encoded probability
units, not degrees squared. It uses the representative phase in [0,360);
this loss is not a circular angular distance. A separate grouping check tests
the equal-count/different-phase relation directly, without this encoding.

## Boundary

Demonstrated: two explicitly scheduled protocol round trips with state and
ledger continuity; fresh phase/crossing measurements bound to those actions;
exact witness calculations on a finite, declared encoding; deterministic
replay; preserved-source and payload integrity checks.

Not implemented: autonomous input selection, phase-derived decision policy,
evolving lambda-prime state, 13-chamber DECURSE execution, ZPR/session/field
coherence orchestration, return-mode classification, pi sealing, Carpet
anti-capture, or the full Trident Engine. Native relay key IDs are structural
labels, not production sender authentication. Hashes establish consistency,
not independent truth or authenticated provenance. Neither the live website
nor original source files are modified.

Protocol ACK return is different from geometric phase return. The 367-degree
relative phase's first positive integer-step return is 30,240; both absolute
orientations return at 332,640. At step 30,240 both orientations are 2160/11
degrees, so even a relative phase return is not an absolute orientation return.
These period facts follow the declared model and do not prove physical timing,
prime-driven dynamics, a detector result, or an autonomous engine.
