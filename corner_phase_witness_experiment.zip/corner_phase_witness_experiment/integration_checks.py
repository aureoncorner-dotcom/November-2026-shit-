"""Independent finite integration contract for the default 11-observation run.

This checker imports neither adapter nor preserved engines. It independently
constructs the expected schedule, probabilities, full witness records, relay
views, and hash bindings. Required checks survive Python's -O option.
"""
from __future__ import annotations

import base64
import hashlib
import json
from fractions import Fraction as F


class IntegrationCheckError(AssertionError):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def sha(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def normalized(value):
    """Compare API tuples and their JSON-array representations equivalently."""
    return json.loads(json.dumps(value))


def expected_view(actor, records):
    """Direct set projection of the prescribed accepted event history."""
    events = {r['event']['event_id']: r['event'] for r in records if r['accepted']}
    own = [e for e in events.values() if e['actor'] == actor]
    remote = [e for e in events.values() if e['actor'] != actor]
    return {
        'schema': 'corner-relay-alpha/view/v1', 'actor': actor, 'active': True,
        'sent_send_ids': sorted(e['event_id'] for e in own if e['kind'] == 'SEND'),
        'received_send_ids': sorted(e['event_id'] for e in remote if e['kind'] == 'SEND'),
        'sent_ack_ids': sorted(e['event_id'] for e in own if e['kind'] == 'ACK'),
        'received_ack_ids': sorted(e['event_id'] for e in remote if e['kind'] == 'ACK'),
        'own_exit_ids': [], 'local_effect_ids': sorted(events),
        'transition_bindings': sorted([[e['transition_id'], e['event_id']] for e in own]),
    }


def expected_witness(retained, offered):
    """Hand-derived full output for this fixed equally spaced finite fixture.

    pX(i)=1/2+7i/1440, pY(i)=1/2+i/44, pZ=17/32, i=0..10.
    Uniform Var(i)=10, so count-only loss=10*(7/1440)^2.
    Either X or Y separates all 11 records; Z separates none.
    """
    labels = [f'sample-{i:02}' for i in range(11)]
    probability = {'X': [F(1, 2) + F(7*i, 1440) for i in range(11)],
                   'Y': [F(1, 2) + F(i, 44) for i in range(11)],
                   'Z': [F(17, 32)] * 11}
    unresolved = retained == ['Z']
    loss = F(49, 207360) if unresolved else F(0)
    signatures = [[str(probability[a][i]) for a in retained] for i in range(11)]
    fibers = ([{'pi': signatures[0], 'states': labels}] if unresolved else
              [{'pi': signatures[i], 'states': [labels[i]]} for i in range(11)])
    pairs = [{'states': [labels[i], labels[j]], 'pi': signatures[i],
              'W_a': [str(probability['X'][i])], 'W_b': [str(probability['X'][j])]}
             for i in range(11) for j in range(i+1, 11)] if unresolved else []
    axes = sorted(a for a in offered if a not in retained)
    batches = []
    for mask in range(1 << len(axes)):
        subset = [axis for bit, axis in enumerate(axes) if mask & (1 << bit)]
        cost = sum(offered[a] for a in subset)
        after = F(0) if (not unresolved or subset) else loss
        batches.append({'axes': subset, 'cost': str(cost),
                        'native_squared_loss_after': str(after), 'repairs_witness': after == 0})
    batches.sort(key=lambda r: (F(r['cost']), len(r['axes']), r['axes']))
    # At increasing costs retain strict record-low losses, rather than copying
    # the engine's pairwise dominance predicate.
    frontier = []
    best_loss = None
    for cost in sorted({F(r['cost']) for r in batches}):
        group = [r for r in batches if F(r['cost']) == cost]
        candidate = min(group, key=lambda r: (F(r['native_squared_loss_after']), len(r['axes']), r['axes']))
        current = F(candidate['native_squared_loss_after'])
        if best_loss is None or current < best_loss:
            frontier.append(candidate)
            best_loss = current
    repairs = [r for r in batches if r['repairs_witness']]
    repair = None if not repairs else min(repairs, key=lambda r: (F(r['cost']), len(r['axes']), r['axes']))
    minimum = None if repair is None else {k: repair[k] for k in ('axes', 'cost', 'native_squared_loss_after')}
    best = min([r for r in batches if F(r['cost']) <= 1],
               key=lambda r: (F(r['native_squared_loss_after']), F(r['cost']), len(r['axes']), r['axes']))
    return {
        'model': 'ideal single-qubit Bloch states / exact Born probabilities',
        'states': labels, 'retained_axes': retained, 'target_axes': ['X'],
        'fibers': fibers, 'non_descent': unresolved, 'conflicting_pairs': pairs,
        'native_squared_loss_before': str(loss), 'min_cost_fixed_batch': minimum,
        'unrepairable_pairs_with_available_measurements': [p['states'] for p in pairs] if repair is None else [],
        'measurement_options': batches, 'cost_loss_frontier': frontier,
        'budget': '1', 'best_within_budget': best,
        'scope': 'Finite supplied states, exact ideal probabilities, uniform weights; no one-shot reconstruction or hardware/finite-shot claims.',
    }


def check_integration(trace):
    """Return a counted PASS receipt or raise on the first violated contract."""
    passed = []

    def require(condition, name):
        if not condition:
            raise IntegrationCheckError(name)
        passed.append(name)

    require(trace['schema'] == 'corner-phase-witness-integration/v1', 'trace schema')
    require({k: trace['source_hashes'][k] for k in ('relay', 'witness')} == {
        'relay': '28ccc31b4304222d5d2429c6054a64ca366316167e8162aeb63d91bba24a4a97',
        'witness': '57cab884c7ddb457b96f6b86dba469fe5168d0dcb708e18e347d53e6bfc90d5b'}, 'pinned source identities')
    contract = trace['time_contract']
    require(contract['schedule'] == [84*i for i in range(11)], 'independent default step schedule')
    dt = F(contract['tick_duration'])
    require(dt > 0 and contract['unit'] == 'declared_model_tick', 'declared positive model clock')
    snapshots = trace['snapshots']
    require(len(snapshots) == 11, 'exactly 11 observation records')
    require(len(trace['cycles']) == 2, 'exactly two returns')
    expected_counts = {'O': [0, 1, 1, 1, 2, 3, 3, 3, 4, 5, 5],
                       'S': [0, 0, 1, 2, 2, 2, 3, 4, 4, 4, 5]}
    for index, snap in enumerate(snapshots):
        n = 84*index
        require(type(snap['t_index']) is int and snap['t_index'] == index, f'observation {index}: action order')
        require(type(snap['model_step']) is int and snap['model_step'] == n, f'observation {index}: integer step')
        require(snap['model_time'] == {'value': str(n*dt), 'unit': 'declared_model_tick'}, f'observation {index}: clock association')
        phase = {'base_degrees': 367, 'step': n,
                 'hook_orientation_exact': str(-F(367*n, 231) % 360),
                 'square_orientation_exact': str(F(367*n, 132) % 360),
                 'relative_phase_exact': str(7*index), 'segment_intersections': 2}
        require(snap['phase'] == phase, f'observation {index}: independent phase and crossing values')
        require(snap['queue'] == [], f'observation {index}: completed transport action')
        for actor in ('O', 'S'):
            raw = trace['endpoints'][actor]['RAW']
            count = expected_counts[actor][index]
            expected = expected_view(actor, raw[:count])
            endpoint = snap['endpoints'][actor]
            require(endpoint == {'view': expected, 'view_sha256': sha(expected), 'raw_count': count,
                                 'raw_head': raw[count-1]['witness_id'] if count else None},
                    f'observation {index}: {actor} state follows native history')

    for actor in ('O', 'S'):
        raw = trace['endpoints'][actor]['RAW']
        require(len(raw) == 5, f'{actor}: five native invocations')
        require(trace['first_cycle_raw'][actor] == raw[:2], f'{actor}: first return history exact prefix')
        require(trace['endpoints'][actor]['VIEW'] == expected_view(actor, raw), f'{actor}: final view reconstructed')
        require(trace['native_ledger_checks'][actor] == [], f'{actor}: reported native ledger result')
        actions = ['SEND', 'RECEIVE_ACK', 'SEND', 'RECEIVE_ACK', 'RETRY'] if actor == 'O' else ['RECEIVE_SEND', 'ACK', 'RECEIVE_SEND', 'ACK', 'RECEIVE_SEND']
        for i, record in enumerate(raw):
            prefix = f'{actor} RAW {i+1}'
            require(record['record_no'] == i+1 and type(record['record_no']) is int, prefix + ': sequential record number')
            require(record['actor'] == actor and record['key_id'] == f'corner-relay:key:{actor}', prefix + ': endpoint identity')
            require(record['action'] == actions[i], prefix + ': expected transition kind')
            require(record['accepted'] is True and record['precondition_met'] is True, prefix + ': accepted precondition')
            require(record['effect_applied'] is (i < 4) and record['duplicate'] is (i == 4), prefix + ': effect and duplicate flags')
            require(record['previous_witness_id'] == (raw[i-1]['witness_id'] if i else None), prefix + ': predecessor link')
            require(json.loads(record['before_view_record']) == expected_view(actor, raw[:i]), prefix + ': before state')
            require(json.loads(record['after_view_record']) == expected_view(actor, raw[:i+1]), prefix + ': after state')
            for field in ('input', 'before_view', 'after_view'):
                require(hashlib.sha256(record[field+'_record'].encode('utf-8')).hexdigest() == record[field+'_sha256'], prefix + ': ' + field + ' hash')
            body = {**record, 'witness_id': ''}
            require(record['witness_id'] == 'wit:' + sha(body), prefix + ': witness hash')
            event = record['event']
            event_body = {k: v for k, v in event.items() if k != 'event_id'}
            require(event['event_id'] == 'evt:' + sha(event_body), prefix + ': event hash')
            payload = base64.b64decode(event['payload_b64'], validate=True)
            require(hashlib.sha256(payload).hexdigest() == event['payload_sha256'], prefix + ': payload bytes')
            require(event['key_id'] == 'corner-relay:key:' + event['actor'], prefix + ': symbolic key label')
            require(event['actor'] != event['target'], prefix + ': distinct route endpoints')

    for cycle_index, cycle in enumerate(trace['cycles'], start=1):
        start = 4*(cycle_index-1)
        send, ack = cycle['send'], cycle['ack']
        require(cycle['cycle'] == cycle_index and cycle['returned_t_index'] == start+4, f'cycle {cycle_index}: return association')
        require(cycle['delivery_statuses'] == ['APPLIED', 'APPLIED'], f'cycle {cycle_index}: applied deliveries')
        before = {a: snapshots[start]['endpoints'][a]['view'] for a in ('O', 'S')}
        after = {a: snapshots[start+4]['endpoints'][a]['view'] for a in ('O', 'S')}
        require(cycle['start_views'] == before and cycle['returned_views'] == after, f'cycle {cycle_index}: retained state association')
        require(all(before[a] != after[a] for a in ('O', 'S')), f'cycle {cycle_index}: both endpoint views change')
        require(send['actor'] == 'O' and send['target'] == 'S' and send['kind'] == 'SEND' and send['ref_event_id'] is None,
                f'cycle {cycle_index}: SEND routing and semantics')
        require(ack['actor'] == 'S' and ack['target'] == 'O' and ack['kind'] == 'ACK' and ack['ref_event_id'] == send['event_id'],
                f'cycle {cycle_index}: ACK references SEND')
        require(ack['payload_b64'] == '' and ack['payload_sha256'] == hashlib.sha256(b'').hexdigest(), f'cycle {cycle_index}: native ACK remains empty')
        require(base64.b64decode(send['payload_b64']) == canonical(cycle['payload']), f'cycle {cycle_index}: exact payload serialization')
        require(cycle['payload']['phase_at_send'] == snapshots[start+1]['phase'], f'cycle {cycle_index}: measurement bound to SEND')
        require(cycle['payload']['cycle'] == cycle_index and cycle['payload']['prior_returned_views_sha256'] == sha(before), f'cycle {cycle_index}: prior return bound to next SEND')
        require(cycle['phase_at_return'] == snapshots[start+4]['phase'], f'cycle {cycle_index}: return phase sidecar')
        expected_events = [send, ack]
        for offset in range(4):
            expected_event = expected_events[offset//2]
            require(snapshots[start+offset+1]['event_id'] == expected_event['event_id'], f'cycle {cycle_index}: event link {offset+1}')
        raw_index = 2*(cycle_index-1)
        for actor, sequence in (('O', [send, ack]), ('S', [send, ack])):
            require([r['event'] for r in trace['endpoints'][actor]['RAW'][raw_index:raw_index+2]] == sequence,
                    f'cycle {cycle_index}: {actor} native events match cycle')
    require(trace['cycles'][1]['start_views'] == trace['cycles'][0]['returned_views'], 'cycle 2 consumes first returned state')
    require(trace['same_endpoint_instances_throughout'] is True, 'adapter reports reused endpoint instances')
    for actor in ('O', 'S'):
        require(snapshots[8]['endpoints'][actor]['view'] == snapshots[9]['endpoints'][actor]['view'] == snapshots[10]['endpoints'][actor]['view'], actor + ': retry preserves view')
        require(trace['endpoints'][actor]['RAW'][-1]['event'] == trace['cycles'][1]['send'], actor + ': retry references exact prior SEND')
    require(snapshots[0]['event_id'] is None and all(snapshots[i]['event_id'] == trace['cycles'][1]['send']['event_id'] for i in (9, 10)), 'initial and retry snapshot event bindings')

    data = trace['witness']['input']
    expected_states = [{'id': f'sample-{i:02}', 'bloch': [str(F(7*i, 720)), str(F(i, 22)), '1/16']} for i in range(11)]
    require(data == {'states': expected_states, 'retained': ['Z'], 'target': ['X'], 'available': {'X': 1, 'Y': 2}, 'budget': 1}, 'witness input exact encoding with no extra records')
    require(trace['witness']['encoding']['maximum_segment_pairs'] == 16, 'geometry segment-pair bound')
    for i, state in enumerate(data['states']):
        require(sum(F(v)**2 for v in state['bloch']) <= 1, f'witness sample {i}: exact valid Bloch norm')
    cases = [('count_only', ['Z'], {'X': 1, 'Y': 2}),
             ('phase_retained', ['Z', 'X'], {'X': 1, 'Y': 2}),
             ('time_retained', ['Z', 'Y'], {'X': 1, 'Y': 2}),
             ('no_repairs', ['Z'], {})]
    for name, retained, offered in cases:
        expected = expected_witness(retained, offered)
        actual = normalized(trace['witness'][name])
        require(set(actual) == set(expected), name + ': complete witness field set')
        for field, value in expected.items():
            require(actual[field] == value, name + ': independent full ' + field)
    require(len(trace['witness']['count_only']['conflicting_pairs']) == 55, 'all 55 phase-disagreeing pairs retained')
    require(F(trace['witness']['count_only']['native_squared_loss_before']) == F(49, 207360), 'hand-derived count-only variance')
    require(len({s['phase']['segment_intersections'] for s in snapshots}) == 1 and len({s['phase']['relative_phase_exact'] for s in snapshots}) == 11,
            'direct finite proof: one crossing count maps to 11 distinct phases')
    return {'status': 'PASS', 'check_count': len(passed), 'checks': passed,
            'scope': 'Independent contract for default 11-step fixture; no preserved engine used to compute expectations.',
            'phase_count_collision': {'crossing_count': 2, 'distinct_phases': 11, 'conflicting_pairs': 55},
            'expected_count_only_loss': '49/207360'}
