"""Independent bounded checks for freshly executed, preserved phase-audit output.

New integration code; not a recovered source module or a physical measurement.
Angles and periods are checked with exact rational arithmetic. Crossing counts
are checked against the supplied finite fixture; this checker does not provide
an independent geometric intersection algorithm.
"""

from collections import Counter, defaultdict
from fractions import Fraction
from math import lcm


class PhaseCheckError(ValueError):
    """Fresh phase output violated the integration contract."""


def check_phase(rows: list[dict], phase_result: dict) -> dict:
    """Check all 1,850 rows and report phase information lost by count alone.

    Expected rows are the fresh audit's ``recomputed_steps.csv`` records. No
    source module is imported and no file is read or written here. Checks use
    explicit exceptions so they remain active under ``python -O``.
    """
    checks = []

    def require(name, condition, detail=None):
        if not condition:
            raise PhaseCheckError(f"{name}: {detail!r}")
        checks.append(name)

    def integer(value, field):
        # Reject silent rounding of floats and booleans; permit CSV integer text.
        if type(value) is int:
            return value
        if isinstance(value, str):
            try:
                result = int(value)
            except ValueError as exc:
                raise PhaseCheckError(f"Invalid integer {field}: {value!r}") from exc
            if str(result) == value:
                return result
        raise PhaseCheckError(f"Invalid integer {field}: {value!r}")

    def rational(value, field):
        if isinstance(value, bool) or isinstance(value, float):
            raise PhaseCheckError(f"Exact rational required for {field}: {value!r}")
        try:
            return Fraction(value)
        except (ValueError, TypeError, ZeroDivisionError) as exc:
            raise PhaseCheckError(f"Invalid rational {field}: {value!r}") from exc

    require("bounded_row_count", len(rows) == 1850, len(rows))
    expected_keys = {(base, n) for base in (360, 367) for n in range(925)}
    indexed = {}
    for row in rows:
        try:
            key = (integer(row["base_degrees"], "base_degrees"),
                   integer(row["step"], "step"))
        except KeyError as exc:
            raise PhaseCheckError(f"Missing phase row field: {exc}") from exc
        if key in indexed:
            raise PhaseCheckError(f"Duplicate phase row: {key}")
        indexed[key] = row
    require("exact_base_step_domain", set(indexed) == expected_keys,
            {"missing": sorted(expected_keys - set(indexed)),
             "unexpected": sorted(set(indexed) - expected_keys)})

    relative_rate = Fraction(1, 231) + Fraction(1, 132)
    require("relative_rate_identity", relative_rate == Fraction(1, 84))
    angle_cells = 0
    histograms = {360: Counter(), 367: Counter()}
    phases_by_count = {360: defaultdict(set), 367: defaultdict(set)}
    all_phases = {360: set(), 367: set()}
    for (base, n), row in sorted(indexed.items()):
        expected = {
            "hook_orientation_exact": -Fraction(base * n, 231) % 360,
            "square_orientation_exact": Fraction(base * n, 132) % 360,
            "relative_phase_exact": base * n * relative_rate % 360,
        }
        for field, value in expected.items():
            try:
                observed = rational(row[field], field)
            except KeyError as exc:
                raise PhaseCheckError(f"Missing phase row field: {exc}") from exc
            if observed != value or not 0 <= observed < 360:
                raise PhaseCheckError(
                    f"Wrong {field} at base={base}, n={n}: "
                    f"observed={observed}, expected={value}")
            angle_cells += 1
        count = integer(row["segment_intersections"], "segment_intersections")
        if count not in (0, 2, 4, 6):
            raise PhaseCheckError(f"Unexpected fixture crossing count: {count}")
        histograms[base][count] += 1
        phase = expected["relative_phase_exact"]
        phases_by_count[base][count].add(phase)
        all_phases[base].add(phase)
    require("all_5550_exact_angle_cells", angle_cells == 5550, angle_cells)
    require("360_crossing_fixture", histograms[360] == Counter({2: 408, 4: 517}),
            dict(histograms[360]))
    require("367_crossing_fixture",
            histograms[367] == Counter({0: 4, 2: 435, 4: 479, 6: 7}),
            dict(histograms[367]))
    require("all_925_367_phases_are_distinct", len(all_phases[367]) == 925,
            len(all_phases[367]))
    require("360_control_has_84_distinct_relative_phases", len(all_phases[360]) == 84,
            len(all_phases[360]))

    derived_periods = {}
    for base in (360, 367):
        hook_period = Fraction(base, 360 * 231).denominator
        square_period = Fraction(base, 360 * 132).denominator
        relative_period = (base * relative_rate / 360).denominator
        pair_period = lcm(hook_period, square_period)
        continuous_relative = 360 / (base * relative_rate)
        continuous_pair = Fraction(360 * lcm(231, 132), base)
        expected_periods = {
            "relative_integer_step_return": relative_period,
            "hook_integer_step_return": hook_period,
            "square_integer_step_return": square_period,
            "pair_absolute_integer_step_return": pair_period,
            "first_relative_continuous_step_return": str(continuous_relative),
            "first_pair_absolute_continuous_step_return": str(continuous_pair),
        }
        try:
            actual_periods = phase_result["periods"][str(base)]
        except KeyError as exc:
            raise PhaseCheckError(f"Missing period receipt field: {exc}") from exc
        require(f"exact_period_contract_{base}", actual_periods == expected_periods,
                {"observed": actual_periods, "expected": expected_periods})
        derived_periods[str(base)] = expected_periods
    require("367_relative_period_anchor",
            derived_periods["367"]["relative_integer_step_return"] == 30240)
    require("367_absolute_pair_period_anchor",
            derived_periods["367"]["pair_absolute_integer_step_return"] == 332640)
    require("360_relative_and_absolute_period_anchors",
            derived_periods["360"]["relative_integer_step_return"] == 84
            and derived_periods["360"]["pair_absolute_integer_step_return"] == 924)

    return_step = 30240
    return_hook = -Fraction(367 * return_step, 231) % 360
    return_square = Fraction(367 * return_step, 132) % 360
    return_relative = (return_square - return_hook) % 360
    require("relative_return_is_not_absolute_return",
            return_relative == 0 and return_hook == return_square
            and return_hook == Fraction(2160, 11) and return_hook != 0)
    expected_return = {"step": return_step, "hook_ccw_mod360": str(return_hook),
                       "square_ccw_mod360": str(return_square),
                       "relative_mod360": str(return_relative)}
    require("fresh_return_receipt_matches_exact_values",
            phase_result.get("return_state_30240") == expected_return,
            phase_result.get("return_state_30240"))
    require("pair_absolute_return_restores_both_orientations",
            -Fraction(367 * 332640, 231) % 360 == 0
            and Fraction(367 * 332640, 132) % 360 == 0)

    aliases = []
    for n, phase in ((0, 0), (84, 7), (168, 14), (924, 77)):
        row = indexed[(367, n)]
        require(f"count_phase_alias_anchor_n{n}",
                integer(row["segment_intersections"], "segment_intersections") == 2
                and rational(row["relative_phase_exact"], "relative_phase_exact") == phase)
        aliases.append({"integer_step": n, "crossing_count": 2,
                        "relative_phase_degrees_exact": str(phase)})
    require("count_alone_is_noninjective_for_phase",
            len({a["crossing_count"] for a in aliases}) == 1
            and len({a["relative_phase_degrees_exact"] for a in aliases}) == 4)
    require("every_367_count_bucket_has_multiple_distinct_phases",
            all(len(values) > 1 for values in phases_by_count[367].values()))

    return {
        "status": "PASS", "check_count": len(checks), "checks": checks,
        "rows_checked": len(rows), "exact_angle_cells_checked": angle_cells,
        "sample_domain": {"base_degrees": [360, 367], "integer_step_min": 0,
                          "integer_step_max": 924, "samples_per_base": 925},
        "crossing_histograms": {
            str(base): {str(k): v for k, v in sorted(histograms[base].items())}
            for base in (360, 367)},
        "distinct_relative_phases": {
            str(base): len(all_phases[base]) for base in (360, 367)},
        "distinct_phase_count_by_crossing_count": {
            str(base): {str(k): len(v) for k, v in sorted(phases_by_count[base].items())}
            for base in (360, 367)},
        "derived_periods": derived_periods,
        "relative_return_state": expected_return,
        "count_only_loses_phase": True,
        "counterexamples": aliases,
        "interpretation": (
            "Different exact relative phases have the same crossing count. "
            "Crossing count alone therefore cannot reconstruct phase on this "
            "declared finite sample. An associated integer step and the declared "
            "rate restore phase computationally; count plus step is a different "
            "retained record from count alone."),
        "boundary": (
            "No duration per step is specified by the source. The adapter must "
            "declare any synthetic time calibration separately. Return periods "
            "are exact algebraic claims, distinct from the 0..924 crossing "
            "fixture. Count checks use supplied finite expectations, not a new "
            "geometry implementation. No hardware, noisy measurements, resonance, "
            "prime-to-phase causality, or full DECURSE/Trident execution is established."),
    }
