"""Execute preserved supplied checks in disposable copies, retaining fresh evidence.

This is new orchestration code. None of the supplied programs is patched.
The old comparison script is informational; its equality fields are explicitly
checked here because its own zero exit status is not a correctness gate.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def run_provided(package_root: Path, run_dir: Path) -> dict:
    """Run all included acceptance suites; return a JSON-serializable receipt.

    ``run_dir`` must have no existing scratch folder. A failed suite is recorded,
    subsequent independent suites still execute, and ``pass`` remains false.
    The caller must honor that gate before publishing an integration success.
    """
    package_root = Path(package_root).resolve()
    run_dir = Path(run_dir).resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    scratch = run_dir / "scratch"
    scratch.mkdir(exist_ok=False)
    logs = run_dir / "provided_logs"
    logs.mkdir(exist_ok=False)
    sources = package_root / "sources"
    commands: list[dict] = []
    source_copies: list[dict] = []
    summaries: dict[str, dict] = {}
    failures: list[str] = []

    def copy_tree(source: Path, destination: Path) -> None:
        shutil.copytree(source, destination)
        for path in source.rglob("*"):
            if path.is_file():
                copied = destination / path.relative_to(source)
                digest = _sha(path)
                if _sha(copied) != digest:
                    raise RuntimeError(f"Copy differs from preserved source: {path}")
                source_copies.append({"source": str(path), "copy": str(copied), "sha256": digest})

    def execute(name: str, cwd: Path, arguments: list[str], *, timeout: int = 180) -> dict:
        command = [sys.executable, "-B", *arguments]
        env = os.environ.copy()
        env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
        record = {
            "name": name, "command": command, "executable": sys.executable,
            "cwd": str(cwd), "started_utc": datetime.now(timezone.utc).isoformat(),
            "timeout_seconds": timeout, "pass": False,
            "environment_overrides": {key: env[key] for key in (
                "PYTHONDONTWRITEBYTECODE", "PYTHONIOENCODING", "PYTHONUTF8")},
            "script_hashes": {
                argument: _sha(cwd / argument)
                for argument in arguments if argument.endswith(".py") and (cwd / argument).is_file()
            },
        }
        started = time.monotonic()
        try:
            completed = subprocess.run(command, cwd=cwd, env=env, capture_output=True,
                                       text=True, encoding="utf-8", errors="replace", timeout=timeout)
            stdout, stderr = completed.stdout, completed.stderr
            record["returncode"] = completed.returncode
        except subprocess.TimeoutExpired as exc:
            def decoded(value):
                return value.decode("utf-8", errors="replace") if isinstance(value, bytes) else (value or "")
            stdout, stderr = decoded(exc.stdout), decoded(exc.stderr)
            record.update(returncode=None, error="subprocess timeout")
        except OSError as exc:
            stdout, stderr = "", str(exc)
            record.update(returncode=None, error=f"{type(exc).__name__}: {exc}")
        record["duration_seconds"] = round(time.monotonic() - started, 6)
        record["finished_utc"] = datetime.now(timezone.utc).isoformat()
        for stream, value in (("stdout", stdout), ("stderr", stderr)):
            path = logs / f"{name}.{stream}.txt"
            path.write_text(value, encoding="utf-8")
            record[f"{stream}_file"] = str(path)
            record[f"{stream}_sha256"] = _sha(path)
        commands.append(record)
        return record

    def validate(record: dict, check) -> None:
        errors = []
        if record["returncode"] != 0:
            errors.append(f"Process return code: {record['returncode']}")
        try:
            summary = check()
            summaries[record["name"]] = summary
        except (OSError, ValueError, KeyError, TypeError, AssertionError) as exc:
            errors.append(f"{type(exc).__name__}: {exc}")
        record["validation_errors"] = errors
        record["pass"] = not errors
        if errors:
            failures.append(record["name"])

    def require(value, message: str) -> None:
        if not value:
            raise AssertionError(message)

    relay = scratch / "relay"
    copy_tree(sources / "relay" / "corner_relay", relay)
    # Remove only copied historical outputs so a missing fresh result cannot pass.
    for name in ("reference_trace.json", "execution_provenance.json"):
        (relay / name).unlink(missing_ok=True)
    entry = execute("relay_unittest", relay, ["-m", "unittest", "-v", "test_corner_relay.py"])

    def check_unittest():
        captured = Path(entry["stdout_file"]).read_text(encoding="utf-8") + Path(entry["stderr_file"]).read_text(encoding="utf-8")
        match = re.search(r"Ran\s+(\d+)\s+tests?", captured)
        require(match is not None and int(match.group(1)) > 0, "No executed unittest count")
        require(re.search(r"^OK\s*$", captured, re.MULTILINE) is not None, "Missing unittest OK result")
        return {"tests_run": int(match.group(1))}

    validate(entry, check_unittest)
    two_return_out = run_dir / "provided_two_returns"
    entry = execute("relay_two_returns", relay, ["check_two_returns.py", "--output-dir", str(two_return_out)])

    def check_two_returns():
        receipt = _json(two_return_out / "two_return_receipt.json")
        trace_path = two_return_out / "two_return_trace.json"
        trace = _json(trace_path)
        require(receipt["status"] == "PASS" and receipt["failures"] == [], "Two-return receipt failed")
        require(receipt["trace_file_sha256"] == _sha(trace_path), "Two-return trace hash mismatch")
        require(trace["checks"] and all(value is True for value in trace["checks"].values()), "Two-return assertions failed")
        require(receipt["check_count"] == len(trace["checks"]), "Two-return check count mismatch")
        return {"check_count": receipt["check_count"], "receipt": str(two_return_out / "two_return_receipt.json")}

    validate(entry, check_two_returns)
    entry = execute("relay_provenance_wrapper", relay, ["run_with_provenance.py"])

    def check_relay_provenance():
        receipt = _json(relay / "execution_provenance.json")
        require(receipt["execution_status"] == "PASS", "Supplied wrapper reported FAIL")
        require(receipt["return_code"] == 0 and receipt["test_return_code"] == 0, "Wrapper/test nonzero return")
        require(receipt["source_binding_verification"]["status"] == "PASS", "Frozen source binding failed")
        require(receipt["tests_run"] == summaries.get("relay_unittest", {}).get("tests_run"), "Wrapper test count differs")
        require(receipt["artifact_file_sha256"]["reference_trace.json"] == _sha(relay / "reference_trace.json"), "Wrapper trace hash mismatch")
        return {"tests_run": receipt["tests_run"], "receipt": str(relay / "execution_provenance.json")}

    validate(entry, check_relay_provenance)

    phase = scratch / "phase"
    phase_source = sources / "phase" / "phase_367_audit"
    phase.mkdir()
    copy_tree(phase_source / "inputs", phase / "inputs")
    shutil.copy2(phase_source / "audit_367.py", phase / "audit_367.py")
    require(_sha(phase_source / "audit_367.py") == _sha(phase / "audit_367.py"), "Phase source copy mismatch")
    source_copies.append({"source": str(phase_source / "audit_367.py"), "copy": str(phase / "audit_367.py"), "sha256": _sha(phase / "audit_367.py")})
    entry = execute("phase_audit", phase, ["audit_367.py"])
    phase_result: dict = {}

    def check_phase():
        nonlocal phase_result
        phase_result = _json(phase / "outputs" / "results.json")
        require(phase_result["fail_count"] == 0 and phase_result["pass_count"] > 0, "Phase audit failed")
        require(all(check["status"] == "PASS" for check in phase_result["checks"]), "Phase check failure")
        require((phase / "outputs" / "recomputed_steps.csv").is_file(), "No fresh phase CSV")
        return {"pass_count": phase_result["pass_count"], "fail_count": phase_result["fail_count"],
                "receipt": str(phase / "outputs" / "results.json")}

    validate(entry, check_phase)

    witness_source = sources / "witness_audit"
    for suffix, options in (("normal", []), ("optimized", ["-O"])):
        folder = scratch / f"witness_original_{suffix}"
        copy_tree(witness_source / "originals", folder)
        (folder / "fresh_verification.json").unlink(missing_ok=True)
        entry = execute(f"witness_original_{suffix}", folder, [*options, "verify_witness.py"])

        def check_original(folder=folder):
            receipt = _json(folder / "fresh_verification.json")
            require(receipt["pass"] is True, "Original verifier did not pass")
            require(receipt["source_sha256"] == _sha(folder / "geometry_quantum_witness.py"), "Original source hash mismatch")
            require(receipt["random_cases"] == 500 and receipt["measurement_option_checks"] == 974, "Original verifier coverage changed")
            return {"random_cases": receipt["random_cases"], "returned_option_loss_checks": receipt["measurement_option_checks"],
                    "coverage_limit": "Historical verifier checks selected returned fields; full-contract checks run separately.",
                    "receipt": str(folder / "fresh_verification.json")}

        validate(entry, check_original)

    comparison = scratch / "witness_original_normal"
    (comparison / "revision_comparison.json").unlink(missing_ok=True)
    entry = execute("witness_original_revision_report", comparison, ["compare_revisions.py"])

    def check_original_comparison():
        receipt = _json(comparison / "revision_comparison.json")
        comparisons = receipt["example_comparisons"]
        require(len(comparisons) == 2 and all(item["all_older_output_fields_equal_newer"] is True for item in comparisons), "Original comparison reports changed shared fields")
        require(receipt["newer_sha256"] == _sha(comparison / "geometry_quantum_witness.py"), "Compared newer source hash mismatch")
        require(receipt["older_sha256"] == _sha(comparison / "geometry_quantum_witness_older.py"), "Compared older source hash mismatch")
        require(receipt["decimal_case"]["older_parsed_cost"] == "1/10", "Unexpected historical decimal parser value")
        require(receipt["decimal_case"]["newer_parsed_cost"] == "10000000000000000001/100000000000000000000", "Unexpected exact decimal parser value")
        return {"classification": "Informational comparison; external wrapper checked equality and known parser values.",
                "examples": len(comparisons), "receipt": str(comparison / "revision_comparison.json")}

    validate(entry, check_original_comparison)
    strong = scratch / "witness_contract"
    copy_tree(witness_source, strong)
    (strong / "revision_contract_results.json").unlink(missing_ok=True)
    for suffix, options in (("normal", []), ("optimized", ["-O"])):
        out = run_dir / f"provided_witness_contract_{suffix}"
        entry = execute(f"witness_contract_{suffix}", strong, [*options, "check_witness_contract.py", "--out", str(out)])

        def check_contract(out=out, optimized=(suffix == "optimized")):
            receipt = _json(out / "results.json")
            require(receipt["pass"] is True and receipt["status"] == "passed", "Full contract did not pass")
            require(receipt["source_sha256"] == _sha(strong / "originals" / "geometry_quantum_witness.py"), "Contract source mismatch")
            require(receipt["checker_sha256"] == _sha(strong / "check_witness_contract.py"), "Contract checker mismatch")
            require(receipt["optimized_checker"] is optimized, "Optimization mode mismatch")
            require(receipt["valid_api_cases"] == 474 and receipt["systematic_axis_combinations"] == 448, "Full-contract valid-case coverage changed")
            require(len(receipt["mutation_detection"]) == 9 and all(item["detected"] is True for item in receipt["mutation_detection"]), "Mutation control not detected")
            return {key: receipt[key] for key in (
                "valid_api_cases", "systematic_axis_combinations", "checked_measurement_options",
                "hand_anchors", "malformed_api_cases", "metamorphic_cases", "optimized_checker")
            } | {"cli_cases": len(receipt["cli_cases"]), "mutation_controls_detected": len(receipt["mutation_detection"]), "receipt": str(out / "results.json")}

        validate(entry, check_contract)
    entry = execute("witness_revision_contract", strong, ["check_revision_contract.py"])

    def check_revision_contract():
        receipt = _json(strong / "revision_contract_results.json")
        require(receipt["pass"] is True and receipt["status"] == "passed", "Revision contract failed")
        require(receipt["same_fixed_input_cases"] == 474 and len(receipt["shared_fields_checked"]) == 11, "Revision contract coverage changed")
        require(len(receipt["mutation_detection"]) == 3 and all(item["detected"] is True for item in receipt["mutation_detection"]), "Revision fault not detected")
        require(receipt["checker_sha256"] == _sha(strong / "check_revision_contract.py"), "Revision checker mismatch")
        return {"same_fixed_input_cases": receipt["same_fixed_input_cases"], "shared_fields_checked": len(receipt["shared_fields_checked"]),
                "mutation_controls_detected": len(receipt["mutation_detection"]), "receipt": str(strong / "revision_contract_results.json")}

    validate(entry, check_revision_contract)
    receipt = {
        "schema": "corner-phase-witness/provided-test-run/v1", "pass": not failures,
        "status": "FAIL" if failures else "PASS",
        "failures": failures, "commands": commands, "summaries": summaries,
        "source_copy_verifications": source_copies,
        "phase_csv": str(phase / "outputs" / "recomputed_steps.csv"), "phase_result": phase_result,
        "scope": "Supplied tests executed unchanged in copies. Imported historical receipts are not counted as fresh results.",
    }
    (run_dir / "provided_tests.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return receipt
