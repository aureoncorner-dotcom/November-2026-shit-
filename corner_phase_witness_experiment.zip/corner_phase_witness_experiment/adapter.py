"""New, isolated integration adapter. Preserved modules are never patched.

Run the complete experiment with run_experiment.py. This module is also usable
as a library with fresh rows produced by the preserved phase audit.
"""
from __future__ import annotations
import base64
import copy
import hashlib
import importlib.util
import json
import sys
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RELAY = ROOT / 'sources/relay/corner_relay/corner_relay.py'
WITNESS = ROOT / 'sources/witness_download/geometry_quantum_witness.py'
WITNESS_HASH = '57cab884c7ddb457b96f6b86dba469fe5168d0dcb708e18e347d53e6bfc90d5b'


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def load_preserved(name, path):
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def require(condition, message):
    if not condition:
        raise ValueError(message)


def build(rows, *, schedule=None, tick_duration='1'):
    """Carry two relay returns and bind fresh phase records to each action.

    schedule is exactly 11 strictly increasing integer steps in [0,924].
    tick_duration is an exact rational number of DECLARED model ticks/step;
    it is not measured wall-clock time or a physical model parameter.
    """
    schedule = list(range(0, 841, 84)) if schedule is None else list(schedule)
    require(len(schedule) == 11, 'Exactly 11 scheduled action steps are required')
    require(all(type(n) is int and 0 <= n <= 924 for n in schedule), 'Steps must be integers in [0,924]')
    require(all(a < b for a, b in zip(schedule, schedule[1:])), 'Steps must increase strictly')
    require(not isinstance(tick_duration, (bool, float)), 'Tick duration must be exact, not float/bool')
    dt = F(tick_duration)
    require(dt > 0, 'Tick duration must be positive')
    require(hashlib.sha256(WITNESS.read_bytes()).hexdigest() == WITNESS_HASH, 'Witness source hash mismatch')
    manifest = json.loads((ROOT / 'source_manifest.json').read_text(encoding='utf-8'))
    relay_hash = next(item['sha256'] for item in manifest['files'] if item['path'] == RELAY.relative_to(ROOT).as_posix())
    require(hashlib.sha256(RELAY.read_bytes()).hexdigest() == relay_hash, 'Relay source hash mismatch')
    relay = load_preserved('integration_preserved_relay', RELAY)
    witness = load_preserved('integration_preserved_witness', WITNESS)
    phase_index = {}
    for row in rows:
        key = (int(row['base_degrees']), int(row['step']))
        require(key not in phase_index, 'Duplicate phase measurement key')
        phase_index[key] = row
    model = json.loads((ROOT / 'sources/phase/phase_367_audit/inputs/model.json').read_text(encoding='utf-8'))
    geometry = model['normalized_example_geometry']
    max_crossings = (len(geometry['H']) - 1) * (len(geometry['Q_shifted']) - 1)

    def measurement(index):
        n = schedule[index]
        row = phase_index[(367, n)]
        expected = {'hook_orientation_exact': -F(367*n,231) % 360,
                    'square_orientation_exact': F(367*n,132) % 360,
                    'relative_phase_exact': F(367*n,84) % 360}
        require(all(F(row[k]) == v for k,v in expected.items()), 'Phase row does not match exact model')
        count = int(row['segment_intersections'])
        require(0 <= count <= max_crossings, 'Crossing count out of geometry bounds')
        return {'base_degrees':367, 'step':n,
                **{k:str(v) for k,v in expected.items()}, 'segment_intersections':count}

    o, s = relay.Endpoint(relay.Actor.O), relay.Endpoint(relay.Actor.S)
    endpoint_ids = (id(o), id(s))
    transport = relay.LambdaTransport(o, s)
    snapshots, cycles = [], []

    def views():
        return {e.actor.value:e.view().to_dict() for e in (o,s)}

    def snap(action, event=None):
        index = len(snapshots)
        states = {}
        for e in (o,s):
            view = e.view().to_dict()
            states[e.actor.value] = {'view':view, 'view_sha256':digest(view),
                'raw_count':len(e.raw), 'raw_head':e.raw[-1].witness_id if e.raw else None}
        snapshots.append({'t_index':index, 'action':action, 'model_step':schedule[index],
            'model_time':{'value':str(schedule[index]*dt), 'unit':'declared_model_tick'},
            'phase':measurement(index), 'event_id':event.event_id if event else None,
            'endpoints':states, 'queue':list(transport.queued_event_ids)})

    snap('initial')
    first_raw = None
    previous = views()
    for cycle in (1,2):
        start = views()
        require(start == previous, 'Returned state was not carried into next cycle')
        require((id(o), id(s)) == endpoint_ids, 'Endpoint identity changed')
        payload = {'schema':'corner-phase-payload/v1', 'cycle':cycle,
            'phase_at_send':measurement(len(snapshots)),
            'prior_returned_views_sha256':digest(previous),
            'meaning':'adapter-selected measurement; opaque bytes to the relay'}
        send = o.send(f'integration-send-{cycle}', canonical(payload))
        snap(f'cycle {cycle}: O SEND',send)
        transport.route(send)
        delivered = transport.deliver()
        require(delivered.status == 'APPLIED', 'SEND not applied')
        require(s.raw[-1].event.payload_sha256 == send.payload_sha256, 'SEND payload binding lost')
        snap(f'cycle {cycle}: deliver SEND to S',send)
        ack = s.acknowledge(f'integration-ack-{cycle}', send.event_id)
        snap(f'cycle {cycle}: S ACK',ack)
        transport.route(ack)
        returned = transport.deliver()
        require(returned.status == 'APPLIED', 'ACK not applied')
        snap(f'cycle {cycle}: deliver ACK to O',ack)
        previous = views()
        cycles.append({'cycle':cycle, 'start_views':start, 'returned_views':previous,
            'returned_t_index':len(snapshots)-1, 'send':send.to_dict(), 'ack':ack.to_dict(),
            'payload':payload, 'delivery_statuses':[delivered.status, returned.status],
            'phase_at_return':measurement(len(snapshots)-1),
            'measurement_location':'SEND payload contains send phase; return phase is adapter sidecar keyed by ACK event id'})
        if cycle == 1:
            first_raw = {e.actor.value:[r.to_dict() for r in e.raw] for e in (o,s)}

    before_retry = views()
    retry = o.retry('integration-send-2')
    snap('retry cycle 2 SEND',retry)
    transport.route(retry)
    duplicate = transport.deliver()
    snap('deliver duplicate SEND',retry)
    require(duplicate.status == 'DUPLICATE' and views() == before_retry, 'Retry changed effective state')
    require(transport.held_key_ids == () and transport.queued_event_ids == (), 'Transport contract broken')
    require(all(relay.verify_raw_ledger(e.raw) == () for e in (o,s)), 'Native RAW integrity check failed')

    states = []
    for snap_record in snapshots:
        phase = snap_record['phase']
        states.append({'id':f"sample-{snap_record['t_index']:02}", 'bloch':[
            str(F(phase['relative_phase_exact'])/720),
            str(F(snap_record['model_step'],2*924)),
            str(F(phase['segment_intersections'],2*max_crossings))]})
    data = {'states':states,'retained':['Z'],'target':['X'],'available':{'X':1,'Y':2},'budget':1}
    original_input = copy.deepcopy(data)
    count_only = witness.run(data)
    require(data == original_input, 'Witness modified caller input')
    phase_retained = witness.run({**data,'retained':['Z','X']})
    time_retained = witness.run({**data,'retained':['Z','Y']})
    no_repairs = witness.run({**data,'available':{}})
    return {'schema':'corner-phase-witness-integration/v1',
        'scope':'Externally scheduled two-return integration of preserved modules; synthetic witness encoding.',
        'time_contract':{'schedule':schedule,'tick_duration':str(dt),'unit':'declared_model_tick',
            'meaning':'t_index is action order; n is phase-model integer step; t=n*dt is a declared clock, not physical or measured elapsed time'},
        'source_hashes':{'relay':relay_hash,'witness':WITNESS_HASH,
            'phase_audit':hashlib.sha256((ROOT/'sources/phase/phase_367_audit/audit_367.py').read_bytes()).hexdigest(),
            'phase_model':hashlib.sha256((ROOT/'sources/phase/phase_367_audit/inputs/model.json').read_bytes()).hexdigest(),
            'phase_supplied_steps':hashlib.sha256((ROOT/'sources/phase/phase_367_audit/inputs/steps.csv').read_bytes()).hexdigest(),
            'fresh_phase_table_canonical':digest(rows),
            'source_manifest':hashlib.sha256((ROOT/'source_manifest.json').read_bytes()).hexdigest()},
        'snapshots':snapshots, 'cycles':cycles, 'first_cycle_raw':first_raw,
        'same_endpoint_instances_throughout':(id(o),id(s)) == endpoint_ids,
        'endpoints':{e.actor.value:{'RAW':[r.to_dict() for r in e.raw], 'VIEW':e.view().to_dict()} for e in (o,s)},
        'native_ledger_checks':{'O':list(relay.verify_raw_ledger(o.raw)), 'S':list(relay.verify_raw_ledger(s.raw))},
        'witness':{'encoding':{'X':'relative phase in [0,360) / 720','Y':'integer step / (2*924)',
            'Z':f'crossing count / (2*{max_crossings})', 'maximum_segment_pairs':max_crossings,
            'meaning':'Exact rational adapter-defined Bloch coordinates, each <=1/2 in magnitude; not physical quantum states measured from the relay',
            'loss_units':'encoded target probability squared; pX = 1/2 + phase_degrees/1440',
            'target_seam':'numeric representative [0,360); this loss is not circular angular distance'},
            'input':data, 'count_only':count_only,'phase_retained':phase_retained,
            'time_retained':time_retained,'no_repairs':no_repairs},
        'boundary':['No autonomous scheduling or input selection','No phase-to-relay control law',
            'No native ACK measurement payload (return measurements are sidecars)',
            'No evolving lambda-prime state or 13-chamber execution',
            'No full DECURSE/Trident Engine, physical detector, or quantum advantage demonstrated']}
