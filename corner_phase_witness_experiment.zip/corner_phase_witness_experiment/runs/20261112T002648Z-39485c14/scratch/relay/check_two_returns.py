#!/usr/bin/env python3
"""New review harness for the unchanged Corner Relay reference artifact.

This is an externally scheduled two-round-trip test, not an implementation of
all DECURSE stages. t_index is harness event order, not physical elapsed time.
Run: python check_two_returns.py --output-dir two_return_results
"""
from __future__ import annotations
import argparse
import hashlib
import json
import platform
from pathlib import Path
from corner_relay import Actor, Endpoint, LambdaTransport, verify_raw_ledger

ROOT = Path(__file__).resolve().parent

def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def digest(value: object) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()

def build() -> dict[str, object]:
    o, s = Endpoint(Actor.O), Endpoint(Actor.S)
    lam = LambdaTransport(o, s)
    snapshots: list[dict[str, object]] = []
    checks: dict[str, bool] = {}
    cycle_events: list[dict[str, object]] = []

    def snap(action: str) -> None:
        states = {}
        for endpoint in (o, s):
            states[endpoint.actor.value] = {
                "view": endpoint.view().to_dict(),
                "view_sha256": digest(endpoint.view().to_dict()),
                "raw_count": len(endpoint.raw),
                "raw_head": endpoint.raw[-1].witness_id if endpoint.raw else None,
            }
        snapshots.append({"t_index": len(snapshots), "action": action,
                          "endpoints": states, "queue": list(lam.queued_event_ids)})

    snap("initial")
    initial_o = o.view().to_dict()
    checks["independent_endpoints_and_distinct_key_labels"] = o is not s and o.actor != s.actor and o.key_id != s.key_id
    checks["lambda_has_no_key"] = lam.held_key_ids == ()
    previous_end = None
    first_o_raw = first_s_raw = ()
    for cycle in (1, 2):
        if previous_end is not None:
            checks["cycle_2_starts_at_cycle_1_returned_views"] = (
                o.view().to_dict() == previous_end["O"] and s.view().to_dict() == previous_end["S"]
            )
        # Explicit external inputs, using the SAME endpoint instances throughout.
        send = o.send(f"review-o-send-{cycle}", f"declared payload for cycle {cycle}".encode())
        if cycle == 2:
            checks["cycle_2_send_before_view_equals_cycle_1_O_return"] = (
                json.loads(o.raw[-1].before_view_record) == previous_end["O"]
            )
        snap(f"cycle {cycle}: O SEND")
        lam.route(send)
        delivery = lam.deliver()
        checks[f"cycle_{cycle}_send_applied"] = delivery.status == "APPLIED"
        snap(f"cycle {cycle}: lambda delivers SEND to S")
        ack = s.acknowledge(f"review-s-ack-{cycle}", send.event_id)
        checks[f"cycle_{cycle}_ack_references_received_send"] = ack.ref_event_id == send.event_id and ack.actor == Actor.S and ack.target == Actor.O
        snap(f"cycle {cycle}: S ACK")
        lam.route(ack)
        return_delivery = lam.deliver()
        checks[f"cycle_{cycle}_return_applied"] = return_delivery.status == "APPLIED"
        snap(f"cycle {cycle}: lambda delivers ACK to O")
        returned = {"O": o.view().to_dict(), "S": s.view().to_dict()}
        checks[f"cycle_{cycle}_origin_view_changed"] = returned["O"] != (initial_o if previous_end is None else previous_end["O"])
        cycle_events.append({"cycle": cycle, "send_event_id": send.event_id, "ack_event_id": ack.event_id,
                             "returned_t_index": snapshots[-1]["t_index"],
                             "O_raw_count": len(o.raw), "S_raw_count": len(s.raw),
                             "O_sent_count": len(o.view().sent_send_ids), "O_ack_received_count": len(o.view().received_ack_ids)})
        if cycle == 1:
            first_o_raw, first_s_raw = o.raw, s.raw
        previous_end = returned

    checks["first_cycle_raw_preserved_as_prefix"] = o.raw[:len(first_o_raw)] == first_o_raw and s.raw[:len(first_s_raw)] == first_s_raw
    checks["two_returns_have_four_records_per_endpoint"] = len(o.raw) == len(s.raw) == 4
    before_views = {"O": o.view().to_dict(), "S": s.view().to_dict()}
    before_counts = (len(o.raw), len(s.raw))
    retry = o.retry("review-o-send-2")
    snap("retry previous cycle-2 SEND; no new O effect")
    lam.route(retry)
    duplicate = lam.deliver()
    snap("deliver duplicate to S; retain invocation without new effect")
    checks["retry_keeps_both_views_unchanged"] = o.view().to_dict() == before_views["O"] and s.view().to_dict() == before_views["S"]
    checks["retry_extends_both_raw_histories"] = (len(o.raw), len(s.raw)) == (before_counts[0]+1, before_counts[1]+1)
    checks["duplicate_delivery_no_new_effect"] = duplicate.status == "DUPLICATE" and not o.raw[-1].effect_applied and not s.raw[-1].effect_applied
    checks["O_raw_hash_chain_valid"] = verify_raw_ledger(o.raw) == ()
    checks["S_raw_hash_chain_valid"] = verify_raw_ledger(s.raw) == ()
    checks["endpoint_roles_preserved"] = o.actor == Actor.O and s.actor == Actor.S
    checks["queue_empty"] = lam.queued_event_ids == ()
    return {
        "schema": "corner-relay-two-return-review/v1",
        "scope": "Two externally scheduled SEND/ACK round trips on unchanged endpoints; then idempotent retry. No new engine behavior is added.",
        "time_coordinate": "t_index is the new harness's logical action order; native RAW uses local record_no and predecessor links. No physical time base is introduced.",
        "notation": "The archived Corner Relay packet uses T for transition relation. This harness does not rename it or equate it with the user's temporal-axis T. O2 may denote O's changed returned state, not a new endpoint identity.",
        "not_implemented_here": ["Autonomous input selection", "367-degree phase integration", "A separate evolving lambda-prime state", "13-chamber execution", "Recursive/progressive outcome classification"],
        "checks": checks, "cycles": cycle_events, "snapshots": snapshots,
        "endpoints": {"O": {"RAW": [r.to_dict() for r in o.raw], "VIEW": o.view().to_dict()},
                      "S": {"RAW": [r.to_dict() for r in s.raw], "VIEW": s.view().to_dict()}},
    }

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT/"two_return_results")
    args = parser.parse_args()
    trace, second = build(), build()
    trace["checks"]["independent_repeat_is_byte_identical"] = canonical(trace) == canonical(second)
    # The compared bytes above are two full newly executed traces before adding this check.
    failures = [k for k,v in trace["checks"].items() if not v]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    trace_path = args.output_dir/"two_return_trace.json"
    trace_path.write_text(json.dumps(trace, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    receipt = {"status": "FAIL" if failures else "PASS", "check_count": len(trace["checks"]), "failures": failures,
               "python": platform.python_version(), "trace_file_sha256": hashlib.sha256(trace_path.read_bytes()).hexdigest(),
               "source_sha256": {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ("corner_relay.py", "check_two_returns.py")}}
    (args.output_dir/"two_return_receipt.json").write_text(json.dumps(receipt, indent=2)+"\n")
    print(json.dumps(receipt, indent=2))
    return bool(failures)

if __name__ == "__main__":
    raise SystemExit(main())
