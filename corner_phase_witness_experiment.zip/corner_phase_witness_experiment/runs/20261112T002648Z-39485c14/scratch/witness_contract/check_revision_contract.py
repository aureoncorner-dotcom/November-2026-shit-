"""Compare fixed independent inputs and check both engines against a model oracle."""
from pathlib import Path
import ast, copy, hashlib, json, sys, uuid
from check_witness_contract import (BASE, source_module, expected_output, normalized, equal_json,
                                    valid_cases, require, EXPECTED_SOURCE)

OLD_HASH='a24408394dcc7c2cd3895c09e963c6c29c26bb1bfbc5507126556c6ddad676c6'
KEYS={'model','states','retained_axes','target_axes','fibers','non_descent','conflicting_pairs',
      'native_squared_loss_before','min_cost_fixed_batch','unrepairable_pairs_with_available_measurements','scope'}
MODEL='ideal single-qubit Bloch states / exact Born probabilities'
SCOPE='Finite supplied states, exact ideal probabilities, uniform weights; no one-shot reconstruction or hardware/finite-shot claims.'
OUT=BASE/'revision_contract_results.json'
START={'pass':False,'status':'running','run_id':str(uuid.uuid4())}

def save(data):
    temp=OUT.with_suffix('.json.tmp');temp.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8');temp.replace(OUT)

def compare_case(old,new,data,budget,label):
    frozen=copy.deepcopy(data)
    expected=expected_output(frozen,budget)
    expected.update(model=MODEL,scope=SCOPE)
    left_input=copy.deepcopy(frozen);right_input=copy.deepcopy(frozen)
    before=normalized(old.run(left_input));after=normalized(new.run(right_input,budget))
    require(left_input==frozen and right_input==frozen,label+': mutated input')
    require(set(before)==KEYS,label+': changed old output schema')
    for key in KEYS:
        require(equal_json(before[key],expected[key]),label+': old differs from independent expectation for '+key)
        require(equal_json(after[key],expected[key]),label+': new differs from independent expectation for '+key)

def declarations(path):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    result={'functions':{},'classes':{},'assignments':{},'imports':[]}
    for node in tree.body:
        dump=ast.dump(node,include_attributes=False)
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):result['functions'][node.name]=dump
        elif isinstance(node,ast.ClassDef):result['classes'][node.name]=dump
        elif isinstance(node,(ast.Assign,ast.AnnAssign)):
            targets=node.targets if isinstance(node,ast.Assign) else [node.target]
            result['assignments'][','.join(ast.unparse(t) for t in targets)]=dump
        elif isinstance(node,(ast.Import,ast.ImportFrom)):result['imports'].append(dump)
    return result

def main():
    save(START)
    oldpath=BASE/'originals/geometry_quantum_witness_older.py';newpath=BASE/'originals/geometry_quantum_witness.py'
    require(hashlib.sha256(oldpath.read_bytes()).hexdigest()==OLD_HASH,'Old source identity')
    require(hashlib.sha256(newpath.read_bytes()).hexdigest()==EXPECTED_SOURCE,'New source identity')
    old=source_module(oldpath,'contract_old');new=source_module(newpath,'contract_new')
    cases=valid_cases()
    for label,data,budget in cases:compare_case(old,new,data,budget,label)
    a,b=declarations(oldpath),declarations(newpath);changes={}
    for kind in ['functions','classes','assignments']:
        changes[kind]={'identical':[k for k in a[kind] if k in b[kind] and a[kind][k]==b[kind][k]],
                       'changed':[k for k in a[kind] if k in b[kind] and a[kind][k]!=b[kind][k]],
                       'added':sorted(set(b[kind])-set(a[kind])),'removed':sorted(set(a[kind])-set(b[kind]))}
    changes['imports_equal']=a['imports']==b['imports']
    # All comparison faults are assessed against external fixed data and expectations.
    detections=[]
    for label in ['comparison_difference','comparison_shared_error','comparison_changed_global']:
        folder=BASE/'specimens'/label
        m_old=source_module(folder/'geometry_quantum_witness_older.py',label+'_old')
        m_new=source_module(folder/'geometry_quantum_witness.py',label+'_new')
        case=next(c for c in cases if c[0]=='two-budget-0')
        reason=None
        try:compare_case(m_old,m_new,case[1],case[2],label)
        except AssertionError as error:reason=str(error)
        require(reason is not None,'Missed '+label)
        detections.append({'name':label,'detected':True,'reason':reason})
    result={**START,'pass':True,'status':'passed','older_sha256':OLD_HASH,'newer_sha256':EXPECTED_SOURCE,
            'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'oracle_sha256':hashlib.sha256((BASE/'check_witness_contract.py').read_bytes()).hexdigest(),
            'same_fixed_input_cases':len(cases),'shared_fields_checked':sorted(KEYS),'module_declaration_comparison':changes,
            'mutation_detection':detections,
            'scope':'Checks shared valid-input behavior against independent expectations. Expanded-only budget/frontier behavior is checked by check_witness_contract.py. The historical decimal-parser difference remains intentional and separately documented.'}
    save(result);print(json.dumps(result,indent=2))

if __name__=='__main__':
    try:main()
    except BaseException as error:
        save({**START,'pass':False,'status':'failed','error_type':type(error).__name__,'error':str(error)})
        raise
