"""Check whether failed runs can leave successful-looking historical receipts."""
from pathlib import Path
import hashlib, json, subprocess, sys
from audit_existing_verifiers import BASE, specimen, execute, sha, write_json

new=(BASE/'originals/geometry_quantum_witness.py').read_text(encoding='utf-8')
folder=specimen('receipt_lifecycle')
passed=execute(folder,'verify_witness.py')
if passed['returncode']!=0:raise RuntimeError('Baseline failed')
before=(folder/'fresh_verification.json').read_bytes()
mutated=new.replace('return loss / N','return loss / (N + 1)')
(folder/'geometry_quantum_witness.py').write_text(mutated,encoding='utf-8')
failed=execute(folder,'verify_witness.py')
after=(folder/'fresh_verification.json').read_bytes()
receipt=json.loads(after)
legacy={'passing_exit':passed['returncode'],'failing_exit':failed['returncode'],
        'old_receipt_unchanged':before==after,'old_receipt_still_says_pass':receipt['pass'],
        'receipt_source_matches_failed_source':receipt['source_sha256']==sha((folder/'geometry_quantum_witness.py').read_bytes())}
if not (legacy['failing_exit']!=0 and legacy['old_receipt_unchanged'] and legacy['old_receipt_still_says_pass']):
    raise RuntimeError('Unexpected legacy lifecycle result')

modern_folder=BASE/'lifecycle_new_checker';modern_folder.mkdir(exist_ok=True)
(modern_folder/'results.json').write_text('{"pass":true,"status":"passed","historical_stub":true}',encoding='utf-8')
command=[sys.executable,'-B',str(BASE/'check_witness_contract.py'),'--source',str(folder/'geometry_quantum_witness.py'),'--out',str(modern_folder)]
p=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',timeout=15)
modern=json.loads((modern_folder/'results.json').read_text())
if not (p.returncode!=0 and modern['status']=='failed' and modern['pass'] is False):
    raise RuntimeError('New checker did not replace stale success on source mismatch')
report={'original_verifier':legacy,'new_checker':{'exit':p.returncode,'receipt':modern},
        'scope':'The original failed command exits nonzero; its earlier JSON receipt alone is stale. Source-hash comparison exposes the mismatch.'}
write_json(BASE/'receipt_lifecycle_results.json',report)
print(json.dumps(report,indent=2))
