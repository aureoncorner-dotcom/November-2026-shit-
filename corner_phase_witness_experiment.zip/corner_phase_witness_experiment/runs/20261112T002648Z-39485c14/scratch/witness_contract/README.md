# Witness verifier audit package

Read REPORT.md for the findings and the website acceptance boundary. AUDIT_RECEIPT.json contains the concise result and preservation checks.

Recommended application source: originals/geometry_quantum_witness.py, SHA-256 57cab884c7ddb457b96f6b86dba469fe5168d0dcb708e18e347d53e6bfc90d5b. The supplied older source, verification programs, reports, and text outputs are preserved under originals/. Do not modify those snapshots when running the audit.

The specimens/ directory contains DELIBERATELY BROKEN COPIES for diagnostic testing. Do not ship a source file from specimens/ as the application engine.

The new companion checks use the Python standard library. Python 3.12.14 was tested. From this extracted folder:

    python check_witness_contract.py --out rerun_contract
    python -O check_witness_contract.py --out rerun_contract_optimized
    python check_revision_contract.py

The full-output checker reads the pinned source under originals/ and the included deliberate faults under specimens/. It writes receipts/input fixtures only under its output folder. Revision checks read the same preserved inputs and write revision_contract_results.json. Make a working copy first if you want to retain all packaged receipts unchanged. Required checks remain active under optimization. An unexpected source hash or result fails; a previous success is replaced by an explicit running/failure state.

The audit_existing_verifiers.py and audit_receipt_lifecycle.py programs preserve the investigation workflow and its workspace-relative input location. They are historical experiment runners, not the required standalone acceptance commands above. Their original workspace has the supplied files at ../witness_review/. Their fault results and specimens are already included here.

The mathematical oracle is independent of the engine functions. It checks exact probabilities and all output records, not just the scalar losses. The revision checker uses the same external fixtures for both engines and compares their common fields to that independent oracle. Deliberately shared errors are rejected.

This package certifies only the recorded finite checks. Website frontend/backend integration, arbitrary input sizes, noisy measurements, and physical claims are outside the test scope.

HASHES.json lists every packaged file except itself. Original file hashes and review-time source paths are preserved in original_manifest.json. Absolute paths in receipts record where the work was executed; they are not required by the two standalone checkers.
