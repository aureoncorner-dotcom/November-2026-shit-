"""Independent pairwise-variance and exhaustive-choice audit of a source copy."""
from pathlib import Path
import hashlib, importlib.util, itertools, json, random, subprocess, sys
from fractions import Fraction as F

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'geometry_quantum_witness.py'
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('checked_witness', SOURCE)
engine = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = engine
spec.loader.exec_module(engine)

def require(value, label):
    if not value:
        raise AssertionError(label)

def loss(data, retained):
    buckets = {}
    for state in data['states']:
        xyz = [F(x) for x in state['bloch']]
        key = tuple(xyz['XYZ'.index(a)] for a in retained)
        target = tuple((1 + xyz['XYZ'.index(a)]) / 2 for a in data['target'])
        buckets.setdefault(key, []).append(target)
    total = F(0)
    for group in buckets.values():
        total += sum((sum((a-b)**2 for a,b in zip(x,y)) for x,y in itertools.combinations(group,2)),F(0)) / len(group)
    return total / len(data['states'])

def independent(data, budget):
    available = sorted(set(data['available']) - set(data['retained']))
    options = []
    for size in range(len(available)+1):
        for axes in itertools.combinations(available,size):
            options.append((loss(data,data['retained'] + list(axes)),sum((F(data['available'][a]) for a in axes),F(0)),axes))
    full = sorted((o for o in options if o[0] == 0),key=lambda o:(o[1],len(o[2]),o[2]))
    best = min((o for o in options if o[1] <= budget),key=lambda o:(o[0],o[1],len(o[2]),o[2]))
    frontier = {(o[1],o[0]) for o in options if not any(z[1] <= o[1] and z[0] <= o[0] and (z[1],z[0]) != (o[1],o[0]) for z in options)}
    return options, full[0] if full else None, best, frontier

rng = random.Random(20261111)
vectors = [tuple(F(n,4) for n in xyz) for xyz in itertools.product(range(-4,5),repeat=3) if sum(n*n for n in xyz) <= 16]
case_count = 500
option_checks = 0
for case in range(case_count):
    data = {'states':[{'id':str(i),'bloch':list(rng.choice(vectors))} for i in range(rng.randint(1,15))],
            'retained':[a for a in 'XYZ' if rng.randrange(2)],
            'target':rng.sample(list('XYZ'),rng.randint(1,3)),
            'available':{a:F(rng.randrange(7),2) for a in 'XYZ' if rng.randrange(2)}}
    budget=F(rng.randrange(9),2)
    actual=engine.run(data,budget)
    options,full,best,frontier=independent(data,budget)
    require(F(actual['native_squared_loss_before']) == loss(data,data['retained']),f'base loss {case}')
    for option in actual['measurement_options']:
        require(F(option['native_squared_loss_after']) == loss(data,data['retained']+option['axes']),f'option loss {case}')
        option_checks += 1
    got=actual['min_cost_fixed_batch']
    require((got is None) == (full is None),f'repair existence {case}')
    if full:
        require(tuple(got['axes']) == full[2] and F(got['cost']) == full[1],f'full repair {case}')
    got=actual['best_within_budget']
    require(tuple(got['axes']) == best[2] and F(got['cost']) == best[1] and F(got['native_squared_loss_after']) == best[0],f'budget {case}')
    require({(F(o['cost']),F(o['native_squared_loss_after'])) for o in actual['cost_loss_frontier']} == frontier,f'frontier {case}')

cli_runs=[]
for label,args in [('self_test',['--self-test']),('self_test_optimized',['-O','--self-test']),('two',['--json']),('seven',['--example','seven','--budget','1','--json'])]:
    cmd = [sys.executable]
    if args[0] == '-O':
        cmd += [args.pop(0)]
    cmd += [str(SOURCE),*args]
    result=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8')
    require(result.returncode == 0,f'CLI {label}: {result.stderr}')
    (ROOT / f'{label}.txt').write_text(result.stdout,encoding='utf-8')
    cli_runs.append({'name':label,'returncode':result.returncode})

result={'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'python':sys.version,'random_seed':20261111,'random_cases':case_count,'measurement_option_checks':option_checks,'independent_loss_method':'Exact pairwise squared-distance identity, compared against original per-fiber mean implementation','cli_runs':cli_runs,'pass':True}
(ROOT/'fresh_verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
