from pathlib import Path
import ast, hashlib, importlib.util, json, sys
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module
old=load('old_witness',ROOT/'geometry_quantum_witness_older.py')
new=load('new_witness',ROOT/'geometry_quantum_witness.py')
def funcs(path):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef)}
a,b=funcs(ROOT/'geometry_quantum_witness_older.py'),funcs(ROOT/'geometry_quantum_witness.py')
same=[k for k in a if k in b and a[k]==b[k]]
common_results=[]
for example in ['two','seven']:
    before=old.run(old.example(example))
    after=new.run(new.example(example))
    common_results.append({'example':example,'all_older_output_fields_equal_newer':all(after[k]==v for k,v in before.items()),'new_fields':sorted(set(after)-set(before))})
payload='{"states":[{"id":"s","bloch":[0,0,0]}],"retained":[],"target":["X"],"available":{"X":0.10000000000000000001}}'
cost_old=old.read_input(json.loads(payload))[3]['X']
cost_new=new.read_input(new.load_json(payload))[3]['X']
report={'older_sha256':hashlib.sha256((ROOT/'geometry_quantum_witness_older.py').read_bytes()).hexdigest(),'newer_sha256':hashlib.sha256((ROOT/'geometry_quantum_witness.py').read_bytes()).hexdigest(),'identical_function_ASTs':same,'changed_functions':[k for k in a if k in b and a[k]!=b[k]],'added_functions':sorted(set(b)-set(a)),'example_comparisons':common_results,'decimal_case':{'literal':'0.10000000000000000001','older_parsed_cost':str(cost_old),'newer_parsed_cost':str(cost_new)},'older_self_test_assert_nodes':sum(isinstance(n,ast.Assert) for n in ast.walk(ast.parse((ROOT/'geometry_quantum_witness_older.py').read_text(encoding='utf-8'))))}
(ROOT/'revision_comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
