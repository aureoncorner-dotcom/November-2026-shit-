"""Independent full-output checks for the finite witness model.

Run only against reviewed code: importing a source executes its module body.
This is an audit harness, not an HTTP endpoint or a quantum experiment.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import argparse, copy, hashlib, importlib.util, itertools, json, os, subprocess, sys, uuid

BASE=Path(__file__).resolve().parent
EXPECTED_SOURCE='57cab884c7ddb457b96f6b86dba469fe5168d0dcb708e18e347d53e6bfc90d5b'
sys.dont_write_bytecode=True
RECEIPT_PATH=None
RECEIPT_START=None

def save_receipt(value):
    temporary=RECEIPT_PATH.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
    temporary.replace(RECEIPT_PATH)

def require(ok, message):
    if not ok: raise AssertionError(message)

def source_module(path, name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
    return mod

def fraction(v):
    return F(v) if isinstance(v,(int,F)) else F(str(v))

def two():
    return {'states':[{'id':'plus','bloch':[1,0,0]},{'id':'mixed','bloch':[0,0,0]}],
            'retained':['Z'],'target':['X'],'available':{'X':1,'Y':2}}

def seven():
    return {'states':[{'id':name,'bloch':xyz} for name,xyz in [
       ('z+',[0,0,1]),('z-',[0,0,-1]),('x+',[1,0,0]),('x-',[-1,0,0]),
       ('y+',[0,1,0]),('y-',[0,-1,0]),('mixed',[0,0,0])]],
       'retained':['Z'],'target':['X','Y','Z'],'available':{'X':2,'Y':1}}

def expected_output(data, override=None):
    """Raw-coordinate grouping and moment identity; no engine calls.

    In each group: sum probability squared errors =
    1/4 * sum_j (sum_i r_ij^2 - (sum_i r_ij)^2/group_size).
    This follows from completing the square, and avoids both other implementations.
    """
    pos={'X':0,'Y':1,'Z':2}
    rows=[(s['id'],tuple(fraction(v) for v in s['bloch'])) for s in data['states']]
    retained=list(data['retained']);target=list(data['target'])
    costs={a:fraction(v) for a,v in data.get('available',{}).items() if a not in retained}
    budget=fraction(override) if override is not None else fraction(data['budget']) if 'budget' in data else None
    def buckets(axes):
        result={}
        for i,(_,r) in enumerate(rows): result.setdefault(tuple(r[pos[a]] for a in axes),[]).append(i)
        return list(result.items())
    def probabilities(index,axes):
        return [str(F(1,2)+rows[index][1][pos[a]]/2) for a in axes]
    def loss(axes):
        result=F(0)
        for _,indices in buckets(axes):
            for a in target:
                coords=[rows[i][1][pos[a]] for i in indices]
                result+=(sum((v*v for v in coords),F(0))-sum(coords,F(0))**2/len(coords))/4
        return result/len(rows)
    conflicts=[];unrepairable=[]
    for _,indices in buckets(retained):
        for left in range(len(indices)):
            for right in range(left+1,len(indices)):
                i,j=indices[left],indices[right]
                if all(rows[i][1][pos[a]]==rows[j][1][pos[a]] for a in target): continue
                conflicts.append({'states':[rows[i][0],rows[j][0]],'pi':probabilities(i,retained),
                                  'W_a':probabilities(i,target),'W_b':probabilities(j,target)})
                if all(rows[i][1][pos[a]]==rows[j][1][pos[a]] for a in costs):
                    unrepairable.append([rows[i][0],rows[j][0]])
    axes=sorted(costs);options=[]
    for bits in range(1<<len(axes)):
        added=tuple(a for i,a in enumerate(axes) if (bits>>i)&1)
        options.append((sum((costs[a] for a in added),F(0)),loss(retained+list(added)),added))
    options.sort(key=lambda o:(o[0],len(o[2]),o[2]))
    def output(o):
        return {'axes':list(o[2]),'cost':str(o[0]),'native_squared_loss_after':str(o[1]),'repairs_witness':o[1]==0}
    # For each cost, choose its smallest loss. Keep strict record lows as cost increases.
    cost_groups={}
    for o in options: cost_groups.setdefault(o[0],[]).append(o)
    frontier=[];lowest=None
    for cost in sorted(cost_groups):
        candidate=min(cost_groups[cost],key=lambda o:(o[1],len(o[2]),o[2]))
        if lowest is None or candidate[1]<lowest:
            frontier.append(candidate);lowest=candidate[1]
    repairs=[o for o in options if o[1]==0]
    repair=None if not repairs else output(min(repairs,key=lambda o:(o[0],len(o[2]),o[2])))
    if repair is not None: del repair['repairs_witness']
    best=None if budget is None else output(min((o for o in options if o[0]<=budget),key=lambda o:(o[1],o[0],len(o[2]),o[2])))
    return {'states':[name for name,_ in rows],'retained_axes':retained,'target_axes':target,
            'fibers':[{'pi':[str(F(1,2)+v/2) for v in key],'states':[rows[i][0] for i in indices]} for key,indices in buckets(retained)],
            'non_descent':bool(conflicts),'conflicting_pairs':conflicts,'native_squared_loss_before':str(loss(retained)),
            'min_cost_fixed_batch':repair,'unrepairable_pairs_with_available_measurements':unrepairable,
            'measurement_options':[output(o) for o in options],'cost_loss_frontier':[output(o) for o in frontier],
            'budget':None if budget is None else str(budget),'best_within_budget':best}

def normalized(value):
    # Standardize API tuples to the JSON arrays used by the public CLI.
    return json.loads(json.dumps(value))

def equal_json(actual, expected):
    # JSON distinguishes true from 1 and 1 from 1.0; Python value equality does not.
    options={'sort_keys':True,'allow_nan':False,'separators':(',',':')}
    return json.dumps(normalized(actual),**options)==json.dumps(expected,**options)

def compare(actual,expected,label):
    require(isinstance(actual,dict),label+': response must be an object')
    for key,value in expected.items():
        require(key in actual,label+': missing field '+key)
        require(equal_json(actual[key],value),label+': incorrect '+key)
    require(actual.get('model')=='ideal single-qubit Bloch states / exact Born probabilities',label+': model label')
    require(actual.get('scope')=='Finite supplied states, exact ideal probabilities, uniform weights; no one-shot reconstruction or hardware/finite-shot claims.',label+': scope label')
    require(set(actual)==set(expected)|{'model','scope'},label+': response schema changed')

def check_api(engine,data,budget=None,label='case'):
    before=copy.deepcopy(data)
    expected=expected_output(before,budget)  # Freeze before the engine receives any input.
    supplied=copy.deepcopy(before)
    actual=engine.run(supplied,budget)
    require(supplied==before,label+': engine mutated caller input')
    compare(actual,expected,label)
    return actual

def subsets():
    return [[a for i,a in enumerate('XYZ') if (bits>>i)&1] for bits in range(8)]

def valid_cases():
    cases=[]
    for r in subsets():
        for t in subsets()[1:]:
            for av in subsets():
                d=seven();d['retained']=r[::-1];d['target']=t[::-1]
                d['available']={a:{'X':'4/3','Y':'2/3','Z':'5/3'}[a] for a in av}
                mode=len(cases)%3
                if mode==1:d['budget']='2/3'
                cases.append((f'axis-combination-{len(cases)}',d,'4/3' if mode==2 else None))
    for maker in [two,seven]:
        for budget in ['0','1/1000000000000','1','2','3','300']:
            cases.append((maker.__name__+'-budget-'+budget,maker(),budget))
    d=two();d['available']={};cases.append(('no-repair-available',d,None))
    d=two();d['retained']=['X'];d['available']={};cases.append(('target-already-retained',d,'0'))
    d=seven();d['available']={'Z':123,'X':0,'Y':0};cases.append(('free-batches-retained-cost-ignored',d,'0'))
    d=two();d['available']={'X':'1/3','Y':'1/3'};cases.append(('fractional-budget-exactly-affordable',d,'1/3'))
    cases.append(('fractional-budget-just-below',copy.deepcopy(d),'333333333333333333/1000000000000000000'))
    d=seven();d['budget']=999;cases.append(('explicit-zero-overrides-input-budget',d,0))
    d=seven();d['budget']='invalid';cases.append(('explicit-budget-overrides-unused-input-budget',d,'1'))
    d={'states':[{'id':'a','bloch':['3/5',0,'4/5']},{'id':'b','bloch':['-3/5',0,'-4/5']}],
       'retained':[],'target':['Z','X'],'available':{'Z':'1/7','X':'1/7'}}
    cases.append(('equal-cost-equal-loss-axis-tie',d,'1/7'))
    d=copy.deepcopy(d);d['available']={'Z':0,'X':0};cases.append(('tie-prefers-one-axis-then-alphabetical',d,'0'))
    d={'states':[{'id':'a','bloch':['5/13','12/13',0]},{'id':'b','bloch':['-5/13','-12/13',0]},
                 {'id':'c','bloch':['1/3','1/7','1/11']}],
       'retained':[],'target':['Z','Y','X'],'available':{'X':'2/7','Y':'1/7','Z':'3/7'}}
    cases.append(('non-dyadic-rationals-and-unit-boundary',d,'1/7'))
    d={'states':[{'id':'a','bloch':[0,0,0]},{'id':'b','bloch':['1/1000000000000',0,0]}],
       'retained':['X'],'target':['X'],'available':{}}
    cases.append(('tiny-exact-signature-separation',d,None))
    d=two();d['states'].append({'id':'mixed-copy','bloch':[0,0,0]});cases.append(('duplicate-state-record-weights',d,None))
    d=two();d['states']=[d['states'][0]];cases.append(('singleton',d,None))
    d=two();d['available']={'X':10**50,'Y':'1/100000000000000000000000000000000000000000000000000'}
    cases.append(('large-exact-costs',d,10**50))
    return cases

def malformed_cases():
    cases=[('top-null',None),('top-list',[]),('top-bool',True)]
    def changed(label,key,value):
        d=two();d[key]=value;cases.append((label,d))
    for label,value in [('empty-states',[]),('states-not-array',{}),('state-not-object',[1])]:changed(label,'states',value)
    for label,state in [('missing-id',{'bloch':[0,0,0]}),('blank-id',{'id':'  ','bloch':[0,0,0]}),
       ('numeric-id',{'id':1,'bloch':[0,0,0]}),('missing-bloch',{'id':'a'}),
       ('short-bloch',{'id':'a','bloch':[0,0]}),('tuple-bloch',{'id':'a','bloch':(0,0,0)}),
       ('outside-ball',{'id':'a','bloch':[1,1,0]}),('barely-outside-ball',{'id':'a','bloch':[1,'1/1000000000000',0]})]:
        changed(label,'states',[state])
    d=two();d['states'][1]['id']=d['states'][0]['id'];cases.append(('duplicate-id',d))
    for value in [True,None,[],{},'1/0','NaN','Infinity',float('inf')]:
        d=two();d['states'][0]['bloch'][0]=value;cases.append(('invalid-coordinate-'+repr(value),d))
    for key in ['retained','target']:
        for value in ['X',None,['x'],['X','X'],[[]],[True]]:changed(key+'-'+repr(value),key,value)
    changed('empty-target','target',[])
    for value in [[],None,{'Q':1},{'X':-1},{'X':True},{'X':'NaN'},{'X':'1/0'},{'X':None},{'Z':-1}]:changed('available-'+repr(value),'available',value)
    for value in [None,True,-1,'NaN','Infinity','1/0',[],{}]:changed('budget-'+repr(value),'budget',value)
    return cases

def cli(source,args,folder):
    env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
    return subprocess.run([sys.executable,'-B',str(source),*args],cwd=folder,capture_output=True,text=True,
                          encoding='utf-8',env=env,timeout=15)

def check_cli(source,folder):
    folder.mkdir(parents=True,exist_ok=True);results=[]
    def valid(label,text,data,args=(),override=None):
        p=folder/(label+'.json');p.write_text(text,encoding='utf-8')
        result=cli(source,['--input',str(p),'--json',*args],folder)
        require(result.returncode==0,label+': CLI exit '+result.stderr)
        require(not result.stderr,label+': unexpected stderr')
        try:actual=json.loads(result.stdout)
        except ValueError as exc:raise AssertionError(label+': invalid JSON output') from exc
        compare(actual,expected_output(data,override),label)
        results.append({'name':label,'expected_exit':0,'actual_exit':result.returncode})
    for maker in [two,seven]:valid(maker.__name__,json.dumps(maker()),maker())
    d=seven();d['budget']='1';valid('budget-in-file',json.dumps(d),d)
    valid('budget-override',json.dumps(d),d,('--budget','3'),'3')
    d=two();d['available']['X']='0.10000000000000000001'
    text=json.dumps(d).replace('"0.10000000000000000001"','0.10000000000000000001')
    valid('exact-json-decimal',text,d)
    d=two();d['states'][0]['id']='\u03b1';valid('utf8-bom','\ufeff'+json.dumps(d,ensure_ascii=False),d)
    d=two();d['states'][0]['bloch'][0]='1/3';valid('fraction-coordinate',json.dumps(d),d)
    d=two();d['available']['X']='1/100000000000000000000';valid('json-exponent',json.dumps(d).replace('"1/100000000000000000000"','1e-20'),d)
    invalid=[('truncated','{"states":'),('duplicate-top-key','{"states":[],"states":[]}'),
       ('duplicate-nested-key','{"available":{"X":1,"X":2}}'),('nonfinite','{"x":NaN}'),
       ('infinite','{"x":Infinity}'),('null','null'),('empty-state-list',json.dumps(dict(two(),states=[]))),
       ('invalid-bloch',json.dumps(dict(two(),states=[{'id':'x','bloch':[1,1,0]}])))]
    for label,text in invalid:
        p=folder/(label+'.json');p.write_text(text,encoding='utf-8')
        result=cli(source,['--input',str(p),'--json'],folder)
        require(result.returncode==2,label+': expected controlled exit 2')
        require(result.stdout=='',label+': success output on invalid input')
        error=json.loads(result.stderr)
        require(isinstance(error.get('error'),str) and error['error'],label+': missing error message')
        results.append({'name':label,'expected_exit':2,'actual_exit':result.returncode})
    for label,args in [('missing-file',['--input',str(folder/'does-not-exist.json'),'--json']),
                       ('invalid-budget',['--budget','-1','--json'])]:
        result=cli(source,args,folder)
        require(result.returncode==2 and not result.stdout,label+': error contract')
        require(bool(json.loads(result.stderr).get('error')),label+': structured error')
        results.append({'name':label,'expected_exit':2,'actual_exit':result.returncode})
    return results

def main():
    global RECEIPT_PATH, RECEIPT_START
    parser=argparse.ArgumentParser()
    parser.add_argument('--source',type=Path,default=BASE/'originals/geometry_quantum_witness.py')
    parser.add_argument('--out',type=Path,default=BASE/'contract_results')
    args=parser.parse_args();source=args.source.resolve();folder=args.out.resolve();folder.mkdir(parents=True,exist_ok=True)
    RECEIPT_PATH=folder/'results.json'
    RECEIPT_START={'pass':False,'status':'running','run_id':str(uuid.uuid4()),'source':str(source),
                   'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    save_receipt(RECEIPT_START)
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    require(digest==EXPECTED_SOURCE,'Source does not match the reviewed expanded witness')
    engine=source_module(source,'contract_engine')
    cases=valid_cases();option_count=0
    # Hand-derived anchors do not come from engine.example or another engine revision.
    anchors=[('two',two(),None,'1/16'),('seven',seven(),None,'1/7')]
    for name,data,budget,loss in anchors:
        actual=check_api(engine,data,budget,name)
        require(actual['native_squared_loss_before']==loss,name+': hand-derived loss')
    partial=check_api(engine,seven(),'1','seven-partial')
    require(partial['best_within_budget']=={'axes':['Y'],'cost':'1','native_squared_loss_after':'1/14','repairs_witness':False},'hand-derived partial choice')
    altered=two();altered['states'].append({'id':'another-mixed','bloch':[0,0,0]})
    require(check_api(engine,altered)['native_squared_loss_before']=='1/18','record-weight hand calculation')
    for label,data,budget in cases:
        actual=check_api(engine,data,budget,label);option_count+=len(actual['measurement_options'])
    invalid=malformed_cases()
    for label,data in invalid:
        try:engine.run(copy.deepcopy(data))
        except ValueError:pass
        except Exception as exc:raise AssertionError(label+': uncontrolled error '+repr(exc)) from exc
        else:raise AssertionError(label+': invalid data accepted')
    # Label and record-order permutations, complete replication, and axis relabeling.
    metamorphic=[]
    for i,permutation in enumerate(itertools.permutations('XYZ')):
        data=seven();rename=dict(zip('XYZ',permutation))
        for state in data['states']:
            before=state['bloch'];after=[None]*3
            for j,a in enumerate('XYZ'):after['XYZ'.index(rename[a])]=before[j]
            state['bloch']=after
        data['retained']=[rename[a] for a in data['retained']]
        data['target']=[rename[a] for a in data['target']]
        data['available']={rename[a]:v for a,v in data['available'].items()}
        actual=check_api(engine,data,'1',f'axis-permutation-{i}')
        require(actual['native_squared_loss_before']=='1/7','permutation loss')
        require(actual['best_within_budget']['native_squared_loss_after']=='1/14','permutation partial loss')
        metamorphic.append('axis-permutation-'+str(i))
    for copies in [1,2,3]:
        data=seven();data['states']=[dict(s,id=f'{s["id"]}-{j}') for j in range(copies) for s in data['states'][::-1]]
        actual=check_api(engine,data,'1',f'reversed-replicated-{copies}')
        require(actual['native_squared_loss_before']=='1/7','replicated loss');metamorphic.append('reversed-replicated-'+str(copies))
    cli_results=check_cli(source,folder/'cli')
    # Recheck altered specimens only to measure whether these new checks cover the identified gaps.
    mutation_receipt=[]
    for item in json.loads((BASE/'existing_verifier_audit.json').read_text())['verifier_fault_injections']:
        path=BASE/'specimens'/item['name']/'geometry_quantum_witness.py'
        mutant=source_module(path,'mutant_'+item['name']);detected=None
        try:
            check_api(mutant,two(),None,item['name'])
            result=cli(path,['--json'],folder)
            require(result.returncode==0,item['name']+': CLI failed')
            try:parsed=json.loads(result.stdout)
            except ValueError as exc:raise AssertionError('invalid CLI JSON') from exc
            # Built-in IDs are separately fixed here, not read from mutant.example().
            built_in=two();built_in['states'][0]['id']='|+>';built_in['states'][1]['id']='I/2'
            compare(parsed,expected_output(built_in),item['name']+'-cli')
        except AssertionError as exc:detected=str(exc)
        require(detected is not None,'New checks missed '+item['name'])
        mutation_receipt.append({'name':item['name'],'detected':True,'reason':detected})
    require(hashlib.sha256(source.read_bytes()).hexdigest()==digest,'Source changed during verification')
    result={**RECEIPT_START,'pass':True,'status':'passed','source_sha256':digest,'python':sys.version,'optimized_checker':not __debug__,
            'systematic_axis_combinations':448,'valid_api_cases':len(cases),'checked_measurement_options':option_count,
            'hand_anchors':4,'malformed_api_cases':len(invalid),'metamorphic_cases':len(metamorphic),
            'cli_cases':cli_results,'mutation_detection':mutation_receipt,
            'oracle':'Raw-coordinate groups, exact second moments, bitmask batch enumeration, cost-group record-low frontier. Inputs frozen before calling engine.',
            'limits':['Finite checks, not proof over every input.','No hardware, finite-shot, web interface, deployment, or large-input performance validation.']}
    save_receipt(result)
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    try:main()
    except BaseException as error:
        if RECEIPT_PATH is not None:
            save_receipt({**RECEIPT_START,'pass':False,'status':'failed','error_type':type(error).__name__,'error':str(error)})
        raise
