#!/usr/bin/env python3
"""Geometry Engine prototype: exact finite qubit witness and repair audit.

Models an ideal single-qubit state by a Bloch vector (x,y,z) and a
measurement by the probability of its +1 outcome along X, Y, or Z.

Given a retained measurement signature pi and a required target signature W,
finds distinct states with pi(s)=pi(t) but W(s)!=W(t). It reports the exact
uniform-population squared-loss floor and the least-cost fixed batch of
additional available basis measurements that repairs the witness for the
supplied finite state set.

This is a deterministic ideal-probability audit, NOT a one-shot quantum-state
reconstruction, hardware experiment, or finite-sample statistical guarantee.
Repeated independently prepared specimens would be required to estimate the
probabilities used here.

Usage:
    python geometry_quantum_witness.py
    python geometry_quantum_witness.py --example seven
    python geometry_quantum_witness.py --input experiment.json --json
    python geometry_quantum_witness.py --self-test

Input example:
{
  "states": [
    {"id":"plus", "bloch":[1,0,0]},
    {"id":"mixed", "bloch":[0,0,0]}
  ],
  "retained": ["Z"],
  "target": ["X"],
  "available": {"X":1,"Y":2}
}
"""

import argparse
import itertools
import json
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

AXES = {"X": 0, "Y": 1, "Z": 2}


@dataclass(frozen=True)
class State:
    label: str
    bloch: tuple


def frac(v):
    if isinstance(v, bool):
        raise ValueError('Boolean is not a numerical state coordinate')
    return Fraction(str(v))


def read_input(data):
    if not isinstance(data, dict):
        raise ValueError('Top-level input must be a JSON object')
    raw = data.get('states')
    if not isinstance(raw, list) or not raw:
        raise ValueError('states must be a nonempty list')
    states = []
    seen = set()
    for s in raw:
        label = s['id']
        if not isinstance(label, str) or not label or label in seen:
            raise ValueError('Every state must have a unique nonempty string id')
        seen.add(label)
        values = s['bloch']
        if len(values) != 3:
            raise ValueError('bloch must have exactly three coordinates')
        vector = tuple(frac(v) for v in values)
        if sum(x*x for x in vector) > 1:
            raise ValueError(f'Invalid Bloch state {label}: ||r||² > 1')
        states.append(State(label, vector))
    retained, target = data.get('retained'), data.get('target')
    if not isinstance(retained, list) or not isinstance(target, list) or not target:
        raise ValueError('retained and nonempty target must be arrays of axis labels')
    for axes in (retained, target):
        if any(a not in AXES for a in axes) or len(set(axes)) != len(axes):
            raise ValueError('Axes must be unique labels from X, Y, Z')
    available = data.get('available', {})
    if not isinstance(available, dict):
        raise ValueError('available must map axis labels to nonnegative measurement costs')
    costs = {}
    for axis, cost in available.items():
        if axis not in AXES:
            raise ValueError(f'Unknown axis {axis}')
        c = frac(cost)
        if c < 0:
            raise ValueError('Measurement costs must be nonnegative')
        if axis not in retained:
            costs[axis] = c
    return states, retained, target, costs


def signature(state, axes):
    return tuple((Fraction(2) + state.bloch[AXES[a]]) / 2 for a in axes)


def groups(states, axes):
    out = {}
    for state in states:
        out.setdefault(signature(state, axes), []).append(state)
    return out


def bad_pairs(states, retained, target):
    pairs = []
    for same_pi in groups(states, retained).values():
        for a, b in itertools.combinations(same_pi, 2):
            if signature(a, target) != signature(b, target):
                pairs.append((a, b))
    return pairs


def native_loss(states, retained, target):
    """Uniform over the supplied states; squared Euclidean target probability loss."""
    N = len(states)
    loss = Fraction(0)
    for group in groups(states, retained).values():
        values = [signature(s, target) for s in group]
        means = [sum(v[j] for v in values) / len(values) for j in range(len(target))]
        loss += sum(sum((v[j] - means[j])**2 for j in range(len(target))) for v in values)
    return loss / N


def repair(states, retained, target, costs):
    pairs = bad_pairs(states, retained, target)
    if not pairs:
        return (), Fraction(0), []
    options = sorted(costs)
    unresolved = [(a.label, b.label) for a, b in pairs
                  if not any(signature(a, [c]) != signature(b, [c]) for c in options)]
    if unresolved:
        return None, None, unresolved
    solution = None
    for k in range(len(options) + 1):
        for subset in itertools.combinations(options, k):
            if all(any(signature(a, [c]) != signature(b, [c]) for c in subset)
                   for a, b in pairs):
                cost = sum((costs[c] for c in subset), Fraction(0))
                candidate = (cost, len(subset), subset)
                if solution is None or candidate < solution:
                    solution = candidate
    return solution[2], solution[0], []


def rational(f):
    return str(f.numerator) if f.denominator == 1 else f'{f.numerator}/{f.denominator}'


def run(data):
    states, retained, target, costs = read_input(data)
    conflicts = bad_pairs(states, retained, target)
    subset, cost, unresolved = repair(states, retained, target, costs)
    output = {
        'model': 'ideal single-qubit Bloch states / exact Born probabilities',
        'states': [s.label for s in states],
        'retained_axes': retained,
        'target_axes': target,
        'fibers': [
            {'pi': [rational(a) for a in key], 'states': [s.label for s in members]}
            for key, members in groups(states, retained).items()
        ],
        'non_descent': bool(conflicts),
        'conflicting_pairs': [
            {'states': [a.label, b.label],
             'pi': [rational(v) for v in signature(a, retained)],
             'W_a': [rational(v) for v in signature(a, target)],
             'W_b': [rational(v) for v in signature(b, target)]}
            for a, b in conflicts
        ],
        'native_squared_loss_before': rational(native_loss(states, retained, target)),
        'min_cost_fixed_batch': None if subset is None else {
            'axes': list(subset), 'cost': rational(cost),
            'native_squared_loss_after': rational(native_loss(states, retained + list(subset), target))
        },
        'unrepairable_pairs_with_available_measurements': unresolved,
        'scope': 'Finite supplied states, exact ideal probabilities, uniform weights; '
                 'no one-shot reconstruction or hardware/finite-shot claims.'
    }
    return output


def example(which):
    if which == 'two':
        return {
            'states': [{'id': '|+>', 'bloch': [1,0,0]},
                       {'id': 'I/2', 'bloch': [0,0,0]}],
            'retained': ['Z'], 'target': ['X'], 'available': {'X': 1, 'Y': 2}
        }
    return {
        'states': [
            {'id':'|0>', 'bloch':[0,0,1]}, {'id':'|1>', 'bloch':[0,0,-1]},
            {'id':'|+>', 'bloch':[1,0,0]}, {'id':'|->', 'bloch':[-1,0,0]},
            {'id':'|+i>', 'bloch':[0,1,0]}, {'id':'|-i>', 'bloch':[0,-1,0]},
            {'id':'I/2', 'bloch':[0,0,0]},
        ], 'retained':['Z'], 'target':['X','Y','Z'],
        'available':{'X': 2, 'Y': 1}
    }


def self_test():
    t = run(example('two'))
    assert t['non_descent'] and t['native_squared_loss_before'] == '1/16'
    assert t['min_cost_fixed_batch'] == {'axes': ['X'], 'cost': '1', 'native_squared_loss_after': '0'}
    s = run(example('seven'))
    assert s['non_descent'] and s['native_squared_loss_before'] == '1/7'
    assert s['min_cost_fixed_batch'] == {'axes': ['X','Y'], 'cost': '3', 'native_squared_loss_after': '0'}
    # A physically identical retained signature can hide X or Y coherence.
    no_repair = example('two'); no_repair['available'] = {'Y':1}
    assert run(no_repair)['min_cost_fixed_batch'] is None
    # Exact retained observations already sufficient for a target.
    resolved = example('two'); resolved['retained'] = ['X']; resolved['available'] = {}
    assert not run(resolved)['non_descent']
    print('PASS: four built-in exact finite-state tests')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--input', type=Path, help='Custom experiment JSON; see docstring for schema')
    ap.add_argument('--example', choices=['two','seven'], default='two')
    ap.add_argument('--json', action='store_true', help='Write machine-readable result')
    ap.add_argument('--self-test', action='store_true')
    args = ap.parse_args()
    if args.self_test:
        return self_test()
    data = json.loads(args.input.read_text(encoding='utf-8')) if args.input else example(args.example)
    output = run(data)
    if args.json:
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print('GEOMETRY ENGINE — QUANTUM WITNESS TEST')
        print('States:', ', '.join(output['states']))
        print('Retained basis:', ', '.join(output['retained_axes']))
        print('Required witness:', ', '.join(output['target_axes']))
        print('Non-descent:', 'YES' if output['non_descent'] else 'NO')
        print('Conflicting state pairs:', len(output['conflicting_pairs']))
        for pair in output['conflicting_pairs'][:5]:
            print('  ', ' vs '.join(pair['states']),
                  'same retained signature', pair['pi'],
                  'different targets', pair['W_a'], pair['W_b'])
        if len(output['conflicting_pairs']) > 5:
            print('  ...', len(output['conflicting_pairs'])-5, 'more pairs (use --json)')
        print('Minimum squared-error floor before repair:', output['native_squared_loss_before'])
        r = output['min_cost_fixed_batch']
        if r is None:
            print('REPAIR: IMPOSSIBLE using offered measurements')
            print('Unrepairable pairs:', output['unrepairable_pairs_with_available_measurements'])
        else:
            print('MINIMUM-COST REPAIR:', ', '.join(r['axes']) or '(no extra measurement needed)')
            print('Declared acquisition cost:', r['cost'])
            print('Minimum squared-error floor after repair:', r['native_squared_loss_after'])
        print('SCOPE:', output['scope'])


if __name__ == '__main__':
    main()
