"""Audit the original verification programs using isolated, deliberate faults.

No supplied file is edited. Mutants are test specimens, never release sources.
"""
from pathlib import Path
import ast, hashlib, json, os, subprocess, sys

BASE = Path(__file__).resolve().parent
ORIGINAL = BASE.parent / 'witness_review'
NAMES = ['two.txt','verify_witness.py','compare_revisions.py','fresh_verification.json',
         'geometry_quantum_witness.py','geometry_quantum_witness_older.py',
         'revision_comparison.json','self_test.txt','self_test_optimized.txt','seven.txt']
SCRIPTS = ['geometry_quantum_witness.py','geometry_quantum_witness_older.py',
           'verify_witness.py','compare_revisions.py']
sha = lambda b: hashlib.sha256(b).hexdigest()
def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2)+'\n', encoding='utf-8')

def preserve():
    rows=[]
    for name in NAMES:
        path=ORIGINAL/name; data=path.read_bytes()
        rows.append({'name':name,'original_path':str(path),'bytes':len(data),
                     'sha256':sha(data),'mtime_ns':path.stat().st_mtime_ns})
    manifest=BASE/'original_manifest.json'
    if manifest.exists():
        old=json.loads(manifest.read_text())
        if rows != old: raise RuntimeError('An original has changed since this audit began')
    else:
        (BASE/'originals').mkdir(exist_ok=True)
        for row in rows:
            (BASE/'originals'/row['name']).write_bytes((ORIGINAL/row['name']).read_bytes())
        write_json(manifest,rows)
    return rows

def specimen(name, newer=None, older=None):
    folder=BASE/'specimens'/name; folder.mkdir(parents=True,exist_ok=True)
    for script in SCRIPTS:
        data=(BASE/'originals'/script).read_bytes()
        if script=='geometry_quantum_witness.py' and newer is not None: data=newer.encode('utf-8')
        if script=='geometry_quantum_witness_older.py' and older is not None: data=older.encode('utf-8')
        (folder/script).write_bytes(data)
    return folder

def execute(folder, script, optimized=False):
    command=[sys.executable,'-B']+(['-O'] if optimized else [])+[str(folder/script)]
    env=dict(os.environ, PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1')
    p=subprocess.run(command,cwd=folder,capture_output=True,text=True,encoding='utf-8',env=env,timeout=60)
    (folder/(script+'.stdout.txt')).write_text(p.stdout,encoding='utf-8')
    (folder/(script+'.stderr.txt')).write_text(p.stderr,encoding='utf-8')
    return {'returncode':p.returncode,'stderr_tail':p.stderr[-1200:]}

def wrapper(source, body):
    marker="if __name__ == '__main__':"
    extra="_original_run_for_fault_test = run\ndef run(data, budget=None):\n    out = _original_run_for_fault_test(data, budget)\n"
    extra+=''.join('    '+line+'\n' for line in body.splitlines())+'    return out\n\n'
    if source.count(marker)!=1: raise RuntimeError('Unexpected source guard')
    return source.replace(marker,extra+marker)

def coverage_of_original_generator():
    # Read just the definitions and its loop; replace the check body with counters.
    import itertools, random
    from fractions import Fraction as F
    rng=random.Random(20261111)
    vectors=[tuple(F(n,4) for n in xyz) for xyz in itertools.product(range(-4,5),repeat=3) if sum(n*n for n in xyz)<=16]
    hist={'distinct_available_counts':{},'retained_orderings':set(),'targets':set(),'budgets':set(),
          'singleton':0,'duplicate_vectors':0,'no_available':0,'zero_cost':0,'zero_budget':0,
          'rational_coordinate_denominators':set()}
    for _ in range(500):
        states=[rng.choice(vectors) for i in range(rng.randint(1,15))]
        retained=[a for a in 'XYZ' if rng.randrange(2)]
        target=rng.sample(list('XYZ'),rng.randint(1,3))
        available={a:F(rng.randrange(7),2) for a in 'XYZ' if rng.randrange(2)}
        budget=F(rng.randrange(9),2)
        count=len(set(available)-set(retained))
        hist['distinct_available_counts'][count]=hist['distinct_available_counts'].get(count,0)+1
        hist['retained_orderings'].add(''.join(retained));hist['targets'].add(''.join(target));hist['budgets'].add(str(budget))
        hist['singleton']+=len(states)==1;hist['duplicate_vectors']+=len(set(states))<len(states)
        hist['no_available']+=count==0;hist['zero_cost']+=any(v==0 for k,v in available.items() if k not in retained)
        hist['zero_budget']+=budget==0
        hist['rational_coordinate_denominators'].update(v.denominator for state in states for v in state)
    return {k:sorted(v) if isinstance(v,set) else v for k,v in hist.items()}

def main():
    originals=preserve()
    new=(BASE/'originals/geometry_quantum_witness.py').read_text(encoding='utf-8')
    old=(BASE/'originals/geometry_quantum_witness_older.py').read_text(encoding='utf-8')
    baseline=[]
    for optimized in [False,True]:
        folder=specimen('baseline_optimized' if optimized else 'baseline')
        result=execute(folder,'verify_witness.py',optimized)
        if result['returncode']!=0: raise RuntimeError('Unmodified verifier failed: '+str(result))
        result['report']=json.loads((folder/'fresh_verification.json').read_text())
        result['optimized_verifier']=optimized;baseline.append(result)
    folder=BASE/'specimens/baseline'
    baseline_compare=execute(folder,'compare_revisions.py')
    baseline_compare['report']=json.loads((folder/'revision_comparison.json').read_text())

    changes=[
      ('empty_measurement_options','Deletes every option from the returned options list.',wrapper(new,"out['measurement_options'] = []")),
      ('duplicate_measurement_options','Duplicates every returned option.',wrapper(new,"out['measurement_options'] = out['measurement_options'] * 2")),
      ('wrong_option_costs_and_flags','Changes only displayed option costs and repair flags.',wrapper(new,"for option in out['measurement_options']:\n    option['cost'] = '999'\n    option['repairs_witness'] = not option['repairs_witness']")),
      ('wrong_frontier_axes','Preserves cost/loss points but replaces frontier recommendations.',wrapper(new,"for option in out['cost_loss_frontier']:\n    option['axes'] = ['INVALID']\n    option['repairs_witness'] = not option['repairs_witness']")),
      ('empty_evidence_arrays','Removes returned fibers, conflicts, and unrepairable-pair explanations.',wrapper(new,"out['fibers'] = []\nout['conflicting_pairs'] = []\nout['unrepairable_pairs_with_available_measurements'] = []")),
      ('probability_offset','Changes positive-outcome probability from (1+r)/2 to (2+r)/2.',new.replace('(Fraction(1) + state.bloch[AXES[a]]) / 2','(Fraction(2) + state.bloch[AXES[a]]) / 2')),
      ('invalid_cli_json','Writes non-JSON on the --json success path.',new.replace("print(json.dumps(output, ensure_ascii=False, indent=2))","print('THIS IS NOT JSON')")),
      ('wrong_budget_echo','Returns a false negative budget while retaining the computed choice.',wrapper(new,"out['budget'] = '-999'")),
      ('wrong_loss_normalization','Positive control: wrong population normalization.',new.replace('return loss / N','return loss / (N + 1)')),
    ]
    mutations=[]
    for name,description,changed in changes:
        if changed==new: raise RuntimeError('Mutation did not apply: '+name)
        folder=specimen(name,changed)
        result=execute(folder,'verify_witness.py')
        result.update(name=name,description=description,mutated_source_sha256=sha(changed.encode()),
                      undetected_by_original_verifier=result['returncode']==0)
        if result['returncode']==0:
            receipt=json.loads((folder/'fresh_verification.json').read_text())
            result.update(reported_pass=receipt['pass'],reported_option_checks=receipt['measurement_option_checks'])
        mutations.append(result)

    comparator_cases=[]
    cases=[
      ('comparison_difference',wrapper(new,"out['native_squared_loss_before'] = '999'"),old,
       'Changed new result; should not be treated as an automated pass.'),
      ('comparison_shared_error',new.replace('(Fraction(1) + state.bloch[AXES[a]]) / 2','(Fraction(2) + state.bloch[AXES[a]]) / 2'),
       old.replace('(Fraction(1) + state.bloch[AXES[a]]) / 2','(Fraction(2) + state.bloch[AXES[a]]) / 2'),
       'Same probability error in both revisions retains matching functions and common results.'),
      ('comparison_changed_global',new.replace('AXES = {"X": 0, "Y": 1, "Z": 2}','AXES = {"X": 1, "Y": 0, "Z": 2}'),old,
       'Change a module-level axis mapping without changing any function AST.'),
    ]
    for name,n,o,description in cases:
        folder=specimen(name,n,o);result=execute(folder,'compare_revisions.py')
        result.update(name=name,description=description)
        if (folder/'revision_comparison.json').exists(): result['report']=json.loads((folder/'revision_comparison.json').read_text())
        comparator_cases.append(result)

    preservation=[]
    for row in originals:
        p=Path(row['original_path'])
        preservation.append({'name':row['name'],'same_bytes':sha(p.read_bytes())==row['sha256'],
                             'same_mtime':p.stat().st_mtime_ns==row['mtime_ns']})
    if not all(r['same_bytes'] and r['same_mtime'] for r in preservation): raise RuntimeError('Originals changed')
    results={'baseline':baseline,'baseline_comparison':baseline_compare,
             'original_generator_coverage':coverage_of_original_generator(),
             'verifier_fault_injections':mutations,'comparator_fault_injections':comparator_cases,
             'preservation':preservation,
             'interpretation':'Fault injections demonstrate gaps in the checkers. They are not defects found in the unmodified engine.'}
    write_json(BASE/'existing_verifier_audit.json',results)
    print(json.dumps({'baseline_pass':True,'verifier_mutations':[{k:r[k] for k in ['name','returncode','undetected_by_original_verifier']} for r in mutations],
                      'comparison_mutations':[{k:r[k] for k in ['name','returncode']} for r in comparator_cases],
                      'originals_unchanged':True},indent=2))

if __name__=='__main__': main()
