# Corner Relay, 367-degree phase, and witness integration result

**PASS — executed November 11, 2026, with Python 3.12.14.**

The isolated adapter carried the same two Corner Relay endpoints through two
SEND/ACK round trips, retained the first return's native state into the second,
associated integer step and declared time with fresh phase measurements, and
executed the pinned witness module. Crossing count alone loses phase
information in the supplied model. This is a finite integration demonstration;
it is not the full DECURSE/Trident Engine.

Recorded release run: `20261112T002648Z-39485c14`. The full receipt is
`runs/20261112T002648Z-39485c14/receipt.json`, and the complete data trace is
`runs/20261112T002648Z-39485c14/integration_trace.json`.

## Observed two-return behavior

| Observation | Action index | Integer model step | Relative phase | Crossings | RAW records at O / S |
|---|---:|---:|---:|---:|---:|
| Initial | 0 | 0 | 0 degrees | 2 | 0 / 0 |
| First ACK returned | 4 | 336 | 28 degrees | 2 | 2 / 2 |
| Second ACK returned | 8 | 672 | 56 degrees | 2 | 4 / 4 |
| Retry and duplicate delivery completed | 10 | 840 | 70 degrees | 2 | 5 / 5 |

The second cycle's starting views equal the first cycle's returned views. The
first cycle's RAW entries remain exact prefixes. The second SEND payload binds
the preceding returned views by hash. The retry adds invocation history while
leaving both effective views unchanged. Every native RAW chain and event/payload
hash passes validation.

The 11 observations use the adapter-selected schedule `n=84*i`, `i=0..10`.
Default model time is `t=n` declared ticks; changing the calibration to `t=n/3`
preserved phase and relay state in a separate check. Neither coordinate is a
physical elapsed-time measurement. Native local record numbers remain separate.

SEND payloads contain send-time phase records; the relay transports them as
opaque bytes. ACK payloads are empty in the preserved API. Return-time records
are new adapter sidecars associated with ACK IDs and their referenced SEND IDs.

## Does crossing count lose phase information?

Yes. At steps 0 and 84, both crossing counts are 2, while exact relative phases
are respectively 0 and 7 degrees. No function of that count alone can recover
both phases. All 11 integrated observations have count 2 but different phases
0, 7, ..., 70 degrees, producing all **55 pairwise phase conflicts**.

Over the full freshly recomputed 367-degree sample, steps 0..924 contain **925
distinct relative phases** but only four crossing counts. Counts 0, 2, 4, and 6
group respectively **4, 435, 479, and 7** distinct phases. This is direct
finite-table evidence independent of the witness encoding.

The preserved phase audit uses exact rational angles and floating-point planar
geometry. Its original checks reproduce all 1,850 rows for both bases, compare
two intersection predicates, and check stability at tolerances 1e-12, 1e-10,
and 1e-8. This is robust evidence for the supplied sample, not an exact geometry
proof over every possible input.

## Witness result and meaning

The adapter explicitly encodes `X=phase/720`, `Y=step/1848`, `Z=count/32`.
These exact coordinates meet the witness model's Bloch norm bound. Retaining Z
means retaining crossing count; the target X means the encoded phase. The source
engine receives these records unchanged through its existing `run` API.

The count-only output reports **non-descent, 55 conflicts, and exact loss
49/207360**. The independent derivation is `pX(i)=1/2+7*i/1440`, uniform
`Var(i)=10`, giving `10*(7/1440)^2 = 49/207360`.

| Added retained information | Declared cost | Remaining encoded loss |
|---|---:|---:|
| None | 0 | 49/207360 |
| Phase, X | 1 | 0 |
| Step, Y | 2 | 0 |
| Phase and step | 3 | 0 |

With budget 1, the witness recommends phase/X at cost 1. With no offered repair
axes, it retains the positive loss and all 55 unresolved pairs. The phase-retained
and step-retained controls both return zero loss.

This is an adapter-defined mathematical embedding, not evidence of physical
quantum coupling. Costs are declared fixture values. Loss is squared encoded
probability error, not degrees squared or circular angular distance. The
objective weights the 11 supplied observation records uniformly. Step repairs
this finite fixture because the step-to-phase rule and origin are known.

## Executed checks

| Suite | Fresh outcome |
|---|---|
| Supplied relay unit tests | 20 passed |
| Supplied two-return harness | 22 checks passed |
| Supplied relay provenance wrapper | 20 tests passed again; source binding verified |
| Supplied phase audit | 13 checks passed |
| Original witness verifier, normal and optimized | Each passed 500 cases and 974 returned-option loss checks |
| Original revision comparison | Both example equality flags and expected decimal parser values verified externally |
| Strong witness contract, normal and optimized | Each passed 474 valid cases, including all 448 axis combinations; 974 full option records; 4 anchors; 53 invalid inputs; 9 transformations; 18 CLI cases; all 9 fault controls detected |
| Strong revision contract | 474 same-input cases, 11 shared fields; all 3 fault controls detected |
| New independent phase checker | 22 checks; 1,850 rows and 5,550 exact angle values |
| New independent integration checker | 372 checks, including complete outputs for all four witness scenarios |
| New targeted negative controls | 9 expected rejections |
| Deterministic replay and changed time units | Passed |
| Relocated package | Complete run passed and canonical trace matched |
| Source mismatch / stale receipt control | Altered copy rejected; prior PASS replaced by fresh FAIL |

Counts from repeated runs describe the same suite, not additional independent
scientific evidence. The old verifier's narrow coverage is not treated as the
sole acceptance test. Historical mutation-runner scripts are preserved but are
not the standalone acceptance commands; their reusable fault fixtures are
exercised by the stronger supplied checks. Figure rendering is preserved source
material and was not needed for this integration run.

The 9 new rejection checks cover state reset, collapsed phase, omitted conflicts,
broken payload binding, fractional/repeated/out-of-range steps, nonpositive time
calibration, and a corrupted phase table. They are targeted diagnostics, not a
statistical estimate of all possible bugs.

## Source preservation and provenance

All **260 preserved files** matched their byte hashes before and after the final
run. All **8 original input files/archives** matched their initial content hashes
and modification times. The executed phase audit's model JSON and the corrected
figure's model JSON are byte-identical. The website was not edited or deployed.

| Runtime source | SHA-256 |
|---|---|
| Corner Relay | `28ccc31b4304222d5d2429c6054a64ca366316167e8162aeb63d91bba24a4a97` |
| Phase audit | `50a54629083c0c7e327d0b3932e536ccbcfcdaf419cef235ce6b5af822e0204a` |
| Expanded witness | `57cab884c7ddb457b96f6b86dba469fe5168d0dcb708e18e347d53e6bfc90d5b` |

`acquisition_receipt.json` maps exact local archive paths to their hashes;
`source_manifest.json` maps every extracted file. The linked chat reader was not
available, so this run used the named local packages and attached audit report;
it does not claim complete recovery of the referenced conversation. Prior
witness audit materials came from the existing local evidence archive. Sources
were copied byte-for-byte, and executable tests ran in disposable copies.

Receipts contain run IDs, Python identity, commands, code/source/output hashes,
and separate fresh stdout/stderr. Some recorded paths are absolute historical
execution paths; the runnable code resolves its inputs relative to its new
location. `validation/distribution_checks.json` records relocation and failure
lifecycle checks. The deliberately broken source copy exists only in internal
validation work; the shipped source trees remain intact. Supplied
`sources/witness_audit/specimens/` files are explicitly labeled diagnostic faults,
and are never loaded as the adapter's engine.

## Demonstration boundary

The integration adds an external schedule, observation association, opaque SEND
payload construction, return sidecars, and a finite witness encoding. It does
not add autonomous scheduling, a phase-driven relay policy, an evolving
lambda-prime state, 13-chamber DECURSE execution, ZPR/session/field-coherence
orchestration, return-mode classification, pi sealing, Carpet anti-capture, or a
complete Trident Engine. Native key identifiers are structural labels rather
than production authentication; hashes verify consistency, not external truth.

A protocol ACK return is not a geometric return. Under the declared 367-degree
model, relative phase first returns at positive integer step 30,240; both
absolute orientations return at 332,640. At 30,240, both orientations are
2160/11 degrees. No physical detector result, noisy measurement validation,
prime-to-phase causality, quantum advantage, or empirical time model is claimed.

See `README.md` for portable and tested local run commands.
