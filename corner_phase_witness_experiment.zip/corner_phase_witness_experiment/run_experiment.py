#!/usr/bin/env python3
"""Run preserved tests and the isolated integration; publish fresh receipts.

Python 3.12+, standard library only. python run_experiment.py
An explicit --out must be a new directory; sources are always read-only inputs.
"""
from __future__ import annotations
import argparse
import copy
import csv
import hashlib
import json
import os
import platform
import sys
import traceback
import uuid
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    temp.replace(path)


def source_check():
    manifest = json.loads((ROOT/'source_manifest.json').read_text(encoding='utf-8'))
    issues = []
    for item in manifest['files']:
        path = ROOT/item['path']
        if not path.is_file() or sha(path) != item['sha256'] or path.stat().st_size != item['bytes']:
            issues.append(item['path'])
    expected = {item['path'] for item in manifest['files']}
    actual = {p.relative_to(ROOT).as_posix() for p in (ROOT/'sources').rglob('*') if p.is_file()}
    return {'status':'PASS' if not issues and expected == actual else 'FAIL',
            'files_checked':len(expected), 'changed_or_missing':issues, 'unexpected_files':sorted(actual-expected),
            'manifest_sha256':sha(ROOT/'source_manifest.json')}


def check_originals():
    acquisition = json.loads((ROOT/'acquisition_receipt.json').read_text(encoding='utf-8'))
    results=[]
    for record in acquisition['originals']:
        path=Path(record['original_path'])
        if not path.exists():
            results.append({'label':record['label'],'status':'UNAVAILABLE_ON_THIS_HOST'})
        else:
            same=sha(path)==record['sha256'] and path.stat().st_mtime_ns==record['mtime_ns']
            results.append({'label':record['label'],'status':'PASS' if same else 'FAIL',
                            'sha256':sha(path),'mtime_ns':path.stat().st_mtime_ns})
    return results


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def negative_checks(trace, rows, check_integration, check_phase, phase_result, build):
    checks=[]
    def rejects(name, call):
        try:
            call()
        except (ValueError, RuntimeError, AssertionError, KeyError, TypeError) as exc:
            checks.append({'name':name,'status':'PASS','rejected_with':type(exc).__name__})
        else:
            raise RuntimeError('Negative control escaped: '+name)
    altered=copy.deepcopy(trace)
    altered['cycles'][1]['start_views']=altered['snapshots'][0]['endpoints']['O']['view']
    rejects('reset state at second return',lambda:check_integration(altered))
    altered2=copy.deepcopy(trace)
    altered2['snapshots'][1]['phase']['relative_phase_exact']='0'
    rejects('collapse phase to constant crossing count',lambda:check_integration(altered2))
    altered3=copy.deepcopy(trace)
    altered3['witness']['count_only']['conflicting_pairs']=[]
    rejects('remove witness conflicts',lambda:check_integration(altered3))
    altered4=copy.deepcopy(trace)
    altered4['cycles'][0]['send']['payload_sha256']='0'*64
    rejects('break SEND payload binding',lambda:check_integration(altered4))
    for name, schedule in [('fractional step',[0.5]+list(range(84,841,84))),
                           ('repeated step',[0]*11),('out of range',[n*100 for n in range(11)])]:
        rejects(name,lambda schedule=schedule:build(rows,schedule=schedule))
    rejects('nonpositive tick duration',lambda:build(rows,tick_duration='0'))
    changed_rows=copy.deepcopy(rows)
    changed_rows[0]['relative_phase_exact']='1'
    rejects('corrupted phase audit table',lambda:check_phase(changed_rows,phase_result))
    return {'status':'PASS','check_count':len(checks),'checks':checks,
            'scope':'Targeted controls against new adapter/checkers; not a statistical mutation score.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,help='New directory for this run (must not exist)')
    args=parser.parse_args()
    run_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
    out=(args.out or ROOT/'runs'/run_id).resolve()
    # Prevent writing a receipt into the source tree, even with a mistaken flag.
    if out.is_relative_to((ROOT/'sources').resolve()) or out.exists():
        parser.error('--out must be a new directory outside preserved sources')
    out.mkdir(parents=True)
    latest=ROOT/'latest_run.json'
    receipt={'schema':'corner-phase-witness-run/v1','run_id':run_id,'status':'RUNNING',
        'started_utc':datetime.now(timezone.utc).isoformat(),'output_directory':str(out),
        'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
        'code_sha256':{p.name:sha(p) for p in sorted(ROOT.glob('*.py'))},
        'acquisition_receipt_sha256':sha(ROOT/'acquisition_receipt.json')}
    write_json(out/'receipt.json',receipt)
    write_json(latest,receipt)
    code=1
    try:
        receipt['source_check_before']=source_check()
        require(receipt['source_check_before']['status']=='PASS','Preserved source verification failed')
        from provided_tests import run_provided
        from phase_checks import check_phase
        from adapter import build, canonical
        from integration_checks import check_integration
        print('Running preserved source tests...',flush=True)
        provided=run_provided(ROOT,out)
        receipt['provided_tests']=provided
        write_json(out/'provided_tests.json',provided)
        require(provided['status']=='PASS','Provided tests failed; see child logs')
        phase_result=provided['phase_result']
        with Path(provided['phase_csv']).open(encoding='utf-8',newline='') as stream:
            rows=list(csv.DictReader(stream))
        write_json(out/'phase_checks.json',check_phase(rows,phase_result))
        print('Running two-return integration and independent assertions...',flush=True)
        trace=build(rows)
        second=build(rows)
        require(canonical(trace)==canonical(second),'Independent integration replay differed')
        write_json(out/'integration_trace.json',trace)
        checks=check_integration(trace)
        checks['independent_repeat_byte_identical']=True
        write_json(out/'integration_checks.json',checks)
        receipt['integration_checks']=checks
        # Logical time is a separate clock coordinate, not a rewritten phase.
        alternate_time=build(rows,tick_duration='1/3')
        require(all(a['phase']==b['phase'] and a['endpoints']==b['endpoints']
                    and b['model_time']['value']==str(__import__('fractions').Fraction(a['model_step'],3))
                    for a,b in zip(trace['snapshots'],alternate_time['snapshots'])),
                'Changing time units changed phase or relay state')
        receipt['time_scaling_check']='PASS (1/3 declared tick per step)'
        negative=negative_checks(trace,rows,check_integration,check_phase,phase_result,build)
        write_json(out/'negative_checks.json',negative)
        receipt['negative_checks']=negative
        receipt['source_check_after']=source_check()
        require(receipt['source_check_after']['status']=='PASS','Preserved sources changed during execution')
        receipt['original_preservation']=check_originals()
        require(all(x['status']!='FAIL' for x in receipt['original_preservation']), 'An original file changed since acquisition')
        receipt['conclusion']={'two_returns':'PASS','crossing_count_loses_phase':True,
            'example':{'steps':[0,84],'counts':[2,2],'relative_phases_degrees':['0','7']},
            'integrated_samples':11, 'witness_conflicting_pairs':len(trace['witness']['count_only']['conflicting_pairs']),
            'witness_loss':trace['witness']['count_only']['native_squared_loss_before'],
            'full_engine_demonstrated':False}
        receipt['status']='PASS'
        code=0
    except Exception as exc:
        receipt['status']='FAIL'
        receipt['error']={'type':type(exc).__name__,'message':str(exc)}
        (out/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8')
    finally:
        receipt['finished_utc']=datetime.now(timezone.utc).isoformat()
        receipt['artifact_sha256']={p.relative_to(out).as_posix():sha(p)
            for p in sorted(out.rglob('*')) if p.is_file() and p.name!='receipt.json'}
        write_json(out/'receipt.json',receipt)
        write_json(latest,receipt)
        print(json.dumps({'status':receipt['status'],'receipt':str(out/'receipt.json'),
                          'error':receipt.get('error')},indent=2),flush=True)
    return code


if __name__=='__main__':
    raise SystemExit(main())
