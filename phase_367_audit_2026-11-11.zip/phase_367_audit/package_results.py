"""Build one reproducible audit bundle with a file-hash manifest."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json

root=Path(__file__).resolve().parent
files=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='manifest.json'
             and '__pycache__' not in p.parts)
manifest=[{'path':p.relative_to(root).as_posix(),'size_bytes':p.stat().st_size,
           'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
destination=root.parent/'phase_367_audit_2026-11-11.zip'
with ZipFile(destination,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[root/'manifest.json']:
        z.write(p,'phase_367_audit/'+p.relative_to(root).as_posix())
with ZipFile(destination) as z:
    if z.testzip() is not None:
        raise RuntimeError('ZIP integrity failure')
    for entry in manifest:
        if hashlib.sha256(z.read('phase_367_audit/'+entry['path'])).hexdigest()!=entry['sha256']:
            raise RuntimeError('ZIP member hash mismatch')
print(json.dumps({'archive':str(destination),'size_bytes':destination.stat().st_size,'files':len(files)+1}))
