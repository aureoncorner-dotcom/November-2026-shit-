"""Independent check of the supplied 360/367 model, integer steps, and polylines.

Standard library only. Angles/periods use Fraction; geometry uses binary floats
with two segment predicates and three declared tolerances. No Shapely required.
"""
import csv
import hashlib
import itertools
import json
import math
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction as F
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs'
OUT.mkdir(exist_ok=True)
model=json.loads((ROOT/'inputs/model.json').read_text(encoding='utf-8'))
rows=list(csv.DictReader((ROOT/'inputs/steps.csv').open(encoding='utf-8',newline='')))
H=model['normalized_example_geometry']['H']
Q=model['normalized_example_geometry']['Q_shifted']


def cross(a,b):
    return a[0]*b[1]-a[1]*b[0]


def sub(a,b):
    return (a[0]-b[0],a[1]-b[1])


def rotate(path,degrees):
    radians=math.radians(float(degrees))
    c,s=math.cos(radians),math.sin(radians)
    return [(c*x-s*y,s*x+c*y) for x,y in path]


def intersections(h,q,eps):
    points=[]
    margins=[]
    degeneracies=[]
    orientation_count=0
    for i,(a,b) in enumerate(zip(h,h[1:])):
        for j,(c,d) in enumerate(zip(q,q[1:])):
            r,s=sub(b,a),sub(d,c)
            ca=sub(c,a)
            det=cross(r,s)
            side1,side2=cross(r,ca),cross(r,sub(d,a))
            side3,side4=cross(s,sub(a,c)),cross(s,sub(b,c))
            if side1*side2<0 and side3*side4<0:
                orientation_count+=1
            if abs(det)<=eps:
                if abs(cross(ca,r))<=eps:
                    degeneracies.append({'hook_segment':i,'square_segment':j,'type':'collinear supporting lines'})
                continue
            t,u=cross(ca,s)/det,cross(ca,r)/det
            if -eps<=t<=1+eps and -eps<=u<=1+eps:
                p=(a[0]+t*r[0],a[1]+t*r[1])
                margins.append(min(t,1-t,u,1-u))
                if not any(math.dist(p,old)<=eps for old in points):
                    points.append(p)
                if min(t,1-t,u,1-u)<=eps:
                    degeneracies.append({'hook_segment':i,'square_segment':j,'type':'endpoint or near endpoint'})
    return {'count':len(points),'points':points,'orientation_count':orientation_count,
            'minimum_segment_parameter_margin':min(margins) if margins else None,
            'degeneracies':degeneracies}


checks=[]
def check(name,ok,details=None):
    checks.append({'check':name,'status':'PASS' if ok else 'FAIL','details':details})


check('Rows cover both bases at steps 0 through 924',
      len(rows)==1850 and Counter((int(r['base_degrees']),int(r['step'])) for r in rows)
      ==Counter(itertools.product([360,367],range(925))))
angle_errors=[]
count_errors=[]
predicate_errors=[]
epsilon_errors=[]
degeneracies=[]
recomputed=[]
histograms={360:Counter(),367:Counter()}
minimum_margin=1.0
step_zero_points=None
for row in rows:
    B,n=int(row['base_degrees']),int(row['step'])
    angle_h=(-F(B*n,231))%360
    angle_q=F(B*n,132)%360
    relative=F(B*n,84)%360
    for field,expected in [('hook_orientation_deg',angle_h),('square_orientation_deg',angle_q),('relative_phase_deg',relative)]:
        if abs(F(row[field])-expected)>F(501,10**13):
            angle_errors.append({'base':B,'step':n,'field':field,'actual':row[field],'expected':str(expected)})
    hp,qp=rotate(H,angle_h),rotate(Q,angle_q)
    results=[intersections(hp,qp,eps) for eps in [1e-12,1e-10,1e-8]]
    actual=results[1]
    if actual['count']!=int(row['segment_intersections']):
        count_errors.append({'base':B,'step':n,'csv':int(row['segment_intersections']),'computed':actual['count']})
    if actual['count']!=actual['orientation_count']:
        predicate_errors.append({'base':B,'step':n})
    if len({r['count'] for r in results})!=1:
        epsilon_errors.append({'base':B,'step':n,'counts':[r['count'] for r in results]})
    if any(r['degeneracies'] for r in results):
        degeneracies.append({'base':B,'step':n,'details':results[-1]['degeneracies']})
    if actual['minimum_segment_parameter_margin'] is not None:
        minimum_margin=min(minimum_margin,actual['minimum_segment_parameter_margin'])
    histograms[B][actual['count']]+=1
    recomputed.append({'base_degrees':B,'step':n,'hook_orientation_exact':str(angle_h),
                       'square_orientation_exact':str(angle_q),'relative_phase_exact':str(relative),
                       'segment_intersections':actual['count']})
    if n==0 and B==367:
        step_zero_points=actual['points']

check('All 5550 CSV angle cells match exact formulas within decimal rounding',not angle_errors,{'errors':len(angle_errors),'tolerance_degrees':'5.01e-11'})
check('All 1850 CSV intersection counts reproduced',not count_errors,{'errors':len(count_errors)})
check('Independent segment predicates agree',not predicate_errors,{'errors':len(predicate_errors)})
check('Counts stable at tolerances 1e-12, 1e-10, 1e-8',not epsilon_errors,{'errors':len(epsilon_errors)})
check('No endpoint/collinear ambiguities at sampled steps',not degeneracies,
      {'cases':len(degeneracies),'minimum_segment_parameter_margin':minimum_margin})
for B,hist in histograms.items():
    expected=Counter({int(k):v for k,v in model['intersection_samples_step_0_to_924'][str(B)].items() if v})
    check(f'Intersection histogram matches JSON, B={B}',hist==expected,dict(sorted(hist.items())))

periods={}
for B in [360,367]:
    relative_period=F(B,360*84).denominator
    hook_period=F(B,360*231).denominator
    square_period=F(B,360*132).denominator
    pair_period=math.lcm(hook_period,square_period)
    periods[str(B)]={'relative_integer_step_return':relative_period,
                     'hook_integer_step_return':hook_period,'square_integer_step_return':square_period,
                     'pair_absolute_integer_step_return':pair_period,
                     'first_relative_continuous_step_return':str(F(360*84,B)),
                     'first_pair_absolute_continuous_step_return':str(F(360*924,B))}
    check(f'Period claims match exact reduced fractions, B={B}',
          relative_period==model['relative_return_steps'][str(B)] and
          pair_period==model['full_shape_orientation_return_steps'][str(B)],periods[str(B)])
phase84=[int(F(367*84*k,84)%360) for k in range(361)]
check('84-step checkpoint walk visits all 360 integer-degree residues',
      len(set(phase84[:360]))==360 and phase84[0]==phase84[360]==0 and phase84[11]==77)

# Rebuild the digit stream independently; first 913 digits are sufficient.
primes=[]
digits=''
candidate=2
while len(digits)<913:
    if all(candidate%p for p in itertools.takewhile(lambda p:p*p<=candidate,primes)):
        primes.append(candidate)
        digits+=str(candidate)
    candidate+=1
def is_prime(n):
    return n>=2 and all(n%d for d in range(2,math.isqrt(n)+1))
hits={p for p in range(1,914) if is_prime(p) and digits[p-1] in '2357'}
checkpoints=[]
for k in range(11):
    step=84*k
    p=step+1
    row,col=divmod(p-1,83)
    checkpoints.append({'checkpoint_k':k,'step_n':step,'stream_position':p,
                        'row_1_based':row+1,'column_1_based':col+1,
                        'digit':digits[p-1],'double_key':p in hits,
                        'relative_phase_367':phase84[k]})
checkpoint_hits=[r['stream_position'] for r in checkpoints if r['double_key']]
check('11 x 83 stream has 74 double keys',len(hits)==74)
check('Checkpoint diagonal and three highlighted hits reproduced',
      all(r['row_1_based']==r['column_1_based']==r['checkpoint_k']+1 for r in checkpoints)
      and checkpoint_hits==[337,421,673],checkpoint_hits)

return_state={'step':30240,'hook_ccw_mod360':str(-F(367*30240,231)%360),
              'square_ccw_mod360':str(F(367*30240,132)%360),
              'relative_mod360':str(F(367*30240,84)%360)}
five_rates=[231,132,913,1109,4723]
five_absolute={str(B):math.lcm(*(F(B,360*p).denominator for p in five_rates)) for B in [360,367]}
image_finding={'status':'MISMATCH_WITH_SUPPLIED_MODEL','panel':'D',
               'image_step_0_crossings':6,'recomputed_step_0_crossings':2,
               'image_step_924_crossings':6,
               'recomputed_367_step_924_crossings':next(r['segment_intersections'] for r in recomputed if r['base_degrees']==367 and r['step']==924),
               'actual_step_zero_crossing_coordinates':step_zero_points,
               'conclusion':'Panel D depicts different geometry/results from the supplied v0.5 coordinates, JSON, and CSV. Regenerate it from these inputs or identify its separate model.'}
result={'timestamp_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,
        'pass_count':sum(r['status']=='PASS' for r in checks),'fail_count':sum(r['status']=='FAIL' for r in checks),
        'image_finding':image_finding,'periods':periods,'return_state_30240':return_state,
        'intersection_histograms':{str(B):dict(sorted(h.items())) for B,h in histograms.items()},
        'checkpoint_hits':checkpoint_hits,
        'conditional_all_five_absolute_integer_returns':five_absolute,
        'all_five_condition':'Only if the three additional layers follow the depicted rates +/-B*n/p at zero initial phase. The design document defines only the hook/square bench; no five-layer generator was recovered.',
        'angle_errors':angle_errors,'intersection_errors':count_errors,
        'predicate_disagreements':predicate_errors,'tolerance_disagreements':epsilon_errors,
        'geometry_degeneracies':degeneracies,
        'scope':'Exact rational angle/period arithmetic. Float trigonometric coordinates; robust agreement on these 1850 samples is not an exact-arithmetic geometry proof.'}
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for name,values in [('recomputed_steps.csv',recomputed),('checkpoints.csv',checkpoints)]:
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(values[0]));writer.writeheader();writer.writerows(values)
print(json.dumps(result,indent=2))
raise SystemExit(1 if result['fail_count'] else 0)
