ICE ICM 2022 procurement evidence packet — 17 October 2026

The controlling analysis and updated evidence register are in HUMAN POLITICS — Working Master:
https://docs.google.com/document/d/1PSA-627l2hhyuSt-OFtEWF-Dj1WFSskMrJi5F3AlgTc/edit

REGISTER_UPDATE.txt contains the reconstruction added to the existing register. The complete government transaction export is USAspending_70CTD022FR0000170.zip; its unmodified extracted files are also included in usaspending_export/. The 17 action rows are the base award and P00001–P00016, not 333 contract modifications (the download job also counted funding/dictionary/subaward material).

Original SAM attachment filenames and bytes are preserved. Receipts record download URL, UTC retrieval time, HTTP status, final public bucket path, size and SHA-256. The source register supplies official publication times and notice/resource identifiers. Metadata JSON and the government-generated CSV export are government records, not executed contract instruments. Derived text extraction is incomplete for image-only pages and must not replace visual review of the original PDFs.

SHA256SUMS.txt covers included evidence files. manifest.json separates attachments, government metadata/data and derived analysis. The original 2022 LSJ, May 2022 notice, 2021 RFI and Q&A, and two 2025 modification LSJs are newly recovered here. The two previously authenticated 2026 PDFs were carried forward by hash and existing register findings, not downloaded again or duplicated in this packet.

Authentication is limited to government-publication provenance and byte integrity; it does not independently verify every agency representation or authenticate redacted signers. Full solicitation/PWS, evaluation/selection and price files, signed order/modifications, implementation of the planned competition, and the separate 2022 study named by DHS remain open. No FOIA requests or messages were sent.
