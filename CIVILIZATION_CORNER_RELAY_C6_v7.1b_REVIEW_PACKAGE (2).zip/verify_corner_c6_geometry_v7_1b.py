#!/usr/bin/env python3
"""Independent bounded check of the supplied Corner Relay alpha C6 artifact.

Does not modify the source archive. This is not a cryptographic security audit.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ARCHIVE_ROOT = "Corner_Relay_Alpha_C6_Reference_v0.1"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def replay(archive: Path) -> dict:
    with tempfile.TemporaryDirectory(prefix="c6_independent_") as t:
        root = Path(t)
        with zipfile.ZipFile(archive) as z:
            for info in z.infolist():
                path = Path(info.filename)
                if path.is_absolute() or ".." in path.parts or not path.parts or path.parts[0] != ARCHIVE_ROOT:
                    raise ValueError(f"Unsafe or foreign archive entry {info.filename!r}")
                if info.is_dir():
                    continue
                dest = root.joinpath(*path.parts[1:])
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(z.read(info))

        provenance = json.loads((root / "execution_provenance.json").read_text())
        binding = json.loads((root / "source_binding.json").read_text())
        file_hash_checks = {
            fname: sha((root / fname).read_bytes()) == expected
            for fname, expected in provenance["artifact_file_sha256"].items()
        }
        frozen_packet_bound = (
            sha((root / "FROZEN_PACKET.txt").read_bytes()) == binding["frozen_packet_sha256"]
        )
        env = {**os.environ, "PYTHONNOUSERSITE": "1", "PYTHONDONTWRITEBYTECODE": "1"}
        tests = subprocess.run(
            [sys.executable, "-m", "unittest", "-v", "test_corner_relay.py"],
            cwd=root, text=True, capture_output=True, check=False, timeout=60, env=env,
        )
        trace = subprocess.run(
            [sys.executable, "reference_trace.py"],
            cwd=root, text=True, capture_output=True, check=False, timeout=60, env=env,
        )
        trace_hash = sha((root / "reference_trace.json").read_bytes())

        sys.path.insert(0, str(root))
        try:
            from corner_relay import (
                Actor, Endpoint, Event, EventKind, LambdaTransport, verify_raw_ledger,
            )
            views, orders, raw_final_hashes = set(), set(), set()
            for perm in itertools.permutations(range(3)):
                o, s = Endpoint(Actor.O), Endpoint(Actor.S)
                lam = LambdaTransport(o, s)
                events = [o.send(f"o-send-{i}", f"payload-{i}".encode()) for i in range(3)]
                for event in events:
                    lam.route(event)
                for k in perm:
                    if lam.deliver_event(events[k].event_id).status != "APPLIED":
                        raise AssertionError("Unexpected status for a tested independent delivery")
                views.add(json.dumps(s.view().to_dict(), sort_keys=True))
                orders.add(tuple(rec.event.event_id for rec in s.raw if rec.event))
                raw_final_hashes.add(s.raw[-1].witness_id)
                if verify_raw_ledger(s.raw):
                    raise AssertionError("Received raw ledger verification failed")
            o, s = Endpoint(Actor.O), Endpoint(Actor.S)
            lam = LambdaTransport(o, s)
            original = o.send("o-original-send", b"request")
            # No SEND is delivered to S, and S creates no local event.
            constructed_ack = Event.build(
                transition_id="s-unissued-ack", kind=EventKind.ACK,
                actor=Actor.S, target=Actor.O, ref_event_id=original.event_id,
            )
            lam.route(constructed_ack)
            result = lam.deliver()
            gap = {
                "probe": "unsigned_self_consistent_ack_without_s_origin",
                "s_local_raw_records": len(s.raw),
                "o_accepts_ack": result.status == "APPLIED",
                "o_received_ack_view": constructed_ack.event_id in o.view().received_ack_ids,
                "o_raw_verifier_reports_errors": list(verify_raw_ledger(o.raw)),
                "interpretation": "The API verifies labels and hashes, not an authenticated origin or peer's local ACK creation.",
            }
        finally:
            sys.path.remove(str(root))

        pass_count = sum(" ... ok" in line for line in (tests.stdout + tests.stderr).splitlines())
        return {
            "artifact": "Corner Relay alpha C6 reference v0.1",
            "check": "independent_bounded_review_v7.1b",
            "zip_sha256": sha(archive.read_bytes()),
            "packaged_provenance_execution_status": provenance["execution_status"],
            "source_hashes": {"matched": sum(file_hash_checks.values()), "total": len(file_hash_checks), "all_match": all(file_hash_checks.values()), "per_file": file_hash_checks},
            "frozen_packet_sha256_bound": frozen_packet_bound,
            "fresh_unittest": {"return_code": tests.returncode, "passes": pass_count, "output_tail": (tests.stdout + tests.stderr)[-480:]},
            "fresh_trace": {"return_code": trace.returncode, "sha256": trace_hash, "matches_packaged_trace": trace_hash == provenance["artifact_file_sha256"]["reference_trace.json"]},
            "raw_view_collision": {"independent_delivery_orders": len(orders), "distinct_derived_views": len(views), "distinct_last_raw_witness_hashes": len(raw_final_hashes), "observation": "Same derived VIEW; six different ordered RAW histories. Formal non-descent for RAW-order witness through VIEW on these admissible histories."},
            "unsigned_origin_boundary_probe": gap,
            "limits": [
                "Behavior of this deterministic code in a sandbox, not deployment authorization.",
                "Two structural key IDs are not signatures or cryptographic evidence of sender ownership.",
                "A passing RAW hash-chain check is not externally anchored immutable storage.",
                "No independent evidence of real-world decentralization, governance outcomes, or transport fairness.",
                "Not an identified cross-model or hidden actor mechanism.",
            ],
        }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("archive", type=Path)
    p.add_argument("--output", type=Path, default=Path("CORNER_RELAY_C6_INDEPENDENT_VERIFICATION.json"))
    args = p.parse_args()
    report = replay(args.archive)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: report[k] for k in ["source_hashes", "fresh_unittest", "fresh_trace", "raw_view_collision", "unsigned_origin_boundary_probe"]}, indent=2))
    if (
        not report["source_hashes"]["all_match"] or not report["frozen_packet_sha256_bound"]
        or report["fresh_unittest"]["return_code"] != 0 or report["fresh_unittest"]["passes"] != 20
        or report["fresh_trace"]["return_code"] != 0 or not report["fresh_trace"]["matches_packaged_trace"]
    ):
        raise SystemExit(1)

if __name__ == "__main__":
    main()
