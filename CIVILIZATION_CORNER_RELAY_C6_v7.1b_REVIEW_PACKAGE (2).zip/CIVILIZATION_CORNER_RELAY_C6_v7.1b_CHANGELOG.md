# Civilization / Abundance v7.1b — Corner Relay C6 change log

**19 October 2026 · REVIEW ADDENDUM, not canonical promotion**

- Preserved v7.1a architecture, CTA-TG-X773 files and Civilizational Open-Field source/result sets without rewriting earlier tests or versions.
- Added III.20 and Appendix G: a deterministic Corner Relay reference case with two modelled endpoints, role-limited keyless transport, local exit, retries, partitions, and separate RAW/VIEW information.
- Independently replayed the original 20 tests, matched nine source-file SHA-256 hashes, and regenerated the reference trace byte-identically.
- Verified the frozen packet's source wording and exact C6 prompt against the two Google Drive records named by `source_binding.json`.
- Exhibited the six-delivery-order/one-VIEW information-loss collision as a specific constructive instance of non-descent.
- Disclosed a self-consistent unauthenticated ACK accepted without sender-side state; structural labels do not enforce origin authentication.
- Maintained separate status for protocol correctness under intended API calls, adversarial origin verification, infrastructure replaceability, and field-scale independence.
- Did not overwrite Drive documents, rerun the v0.5 civilization simulation, or promote C6 into production.
