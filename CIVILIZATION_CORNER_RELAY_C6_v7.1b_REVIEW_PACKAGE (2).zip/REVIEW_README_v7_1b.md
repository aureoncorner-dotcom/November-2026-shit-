# Civilization / Abundance v7.1b Corner Relay C6 review package

Read `CORNER_RELAY_C6_CIVILIZATION_INTEGRATION_NOTE_v0.1.md` first for the scoped result and its limitations. The long `THE_ABUNDANCE_ENGINE_v7.1b_CORNER_RELAY_C6_REVIEW_SUPPLEMENT.md` preserves the v7.1a full reference text with III.20 and Appendix G added. Neither text is a claim of production deployment.

Reproduction:

```bash
python3 verify_corner_c6_geometry_v7_1b.py Corner_Relay_Alpha_C6_Reference_v0.1.zip --output /tmp/c6_fresh_verification.json
```

The independent checker runs the frozen original suite in an extracted temporary directory, validates packaged source hashes and trace output, checks six independent delivery permutations, and demonstrates the unsigned origin-authentication gap without modifying the original ZIP. Original source provenance and prior v7.1a review package are bundled unchanged. No personal account information or private logs are embedded in the new notes.
