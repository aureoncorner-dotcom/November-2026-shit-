**Audit evidence release 1.0 — 11 November 2026**

- Inventoried and checksum-checked all nine supplied archives, with original ZIPs preserved unchanged.
- Replayed the finite prime, phase, witness, relay, and repaired integration checks; recorded success and failure separately.
- Added independent reconstruction of prime CSV fields, workbook cells, geometric samples, render coordinates, and exact plotted values.
- Compared A04's extracted tables and documents with the newly available original inputs.
- Confirmed A09 as a reproducible replacement chart while retaining the unexplained original-chart mismatch.
- Reproduced the original Windows decoding bug, the research I/O override failure, and the historical optimized-assertion/stale-receipt defects.
- Added three receiver-contract probes showing acceptance of an unknown schema, an empty transition ID, and conflicting peer transition reuse.
- Distinguished JSON-value reproduction from cross-platform serialized-file hashes for the relay traces.
- Recorded duplicate source lineage, missing dependencies, renderer limitations, the absent historical 474-case suite, and untested physical/full-engine hypotheses.
- Added a replay script and package validation. This is an audit release, not a corrected-source release; earlier fixed-mask protocols and their testing ledger are unchanged.
- Validated the complete replay at a long Windows path after adding extended-path handling to the new replay helper; original archived code was unchanged.
