**Nine-archive audit evidence — 11 November 2026**

Start with REPORT.md. results.json separates reproduced finite checks, original program failures, new receiver-validation probes, and untested hypotheses. file_inventory.csv lists all 200 supplied outer members. inputs/ contains all nine original ZIPs unchanged. evidence/ preserves the observed execution logs, selected fresh outputs, environment information, source hashes, and line-ending comparisons. The two small image previews are inspection aids; original images remain in their original ZIPs.

To replay, run `python code/reproduce_nine_audit.py` after extracting this bundle. Python 3.10+ and Pillow are needed for the complete recorded workflow; the independent arithmetic and geometry checks use only the standard library. The recipe does not install software, use a network service, or execute the two Matplotlib drawing programs. It creates a new audit_replay directory. Use `--work path/to/a/new/directory` for another replay; existing work is never overwritten. All original ZIPs are verified against the recorded SHA-256 values before execution.

Windows-specific encoding and CRLF observations can differ on other platforms. A successfully completed recipe is not a blanket PASS for the archived code. Read the individual execution records and relay_contract_probes. Two intentionally reproduced program failures and the missing standalone A08 dependency are retained as findings. The research normal-I/O follow-up succeeds.

The A08 successful run reconstructs its missing historical combined-run layout from A05's preserved unpatched adapter and outputs, with the identical relay/witness sources. This is not a claim to possess the missing original combined ZIP.

No new prime holdout or statistical test was introduced. prior_context/ is a preserved earlier result for context and was not rerun or modified by this audit. No original source was repaired. The manifest verifies package bytes; it does not independently authenticate historical authorship. PACKAGE_VALIDATION.json records the fresh replay and final source-preservation checks.
