# Larger fixed-mask continuation with repeated-testing control

**Confirmed computation:** positions 28,174–166,393, 138,220 new positions; 467 overlaps, 5,736 true hits, 11,242 mask marks, 12,132 prime-index slots and 1,015 marked eligible slots.

**Decision:** No conditional model is rejected at the predeclared within-look Holm threshold 0.00625. This is a model-conditional result, not a general prime-law or physical validation.

| Fixed conditional model | Expected overlap | Null 95% range | Upper tail | Two-sided p | Within-look Holm p | Forward-adjusted p |
|---|---:|---|---:|---:|---:|---:|
| block_prime_digit_shuffle | 478.667207 | 456–502 | 0.849398 | 0.342667 | 1 | 1 |
| global_prime_digit_shuffle | 479.891197 | 450–510 | 0.810399 | 0.415857 | 1 | 1 |
| block_prime_digit_rotation | 478.667207 | 455–502 | 0.841581 | 0.358242 | 1 | 1 |

## What was fixed beforehand

The range is ten times the prior 13,822-position holdout. The original 529-position mask, its 43 marked local positions, and its absolute phase are unchanged. Copy 54 contributes its final 393 positions, copies 55–314 are full, and copy 315 contributes its first 287. No old/new pooling or outcome-driven phase or endpoint choice is used.

Protocol SHA-256: `1cd16c3485c4b929742e61344cdc5578cb9fbafb43c65b48f37586fb6c66e795`. The implementation/dependency seal was recorded at 2026-11-11 20:17:49 UTC, SHA-256 `0bfd76747e82fca94b622d148ca112ae87e720a9dfaab95620b141ece3f033f3`. These are local prospective records, not externally registered or independently timestamped commitments.

## Repeated testing: forward control and historical limits

The two historical windows each used within-window Holm at 0.05. Their decisions remain unchanged in testing_ledger.csv. Non-rejection returns no alpha, and the new plan cannot retroactively create a 5% error guarantee for all previous testing.

A new, explicitly forward-only family begins here with total budget B=1/80=0.0125. Its look j receives alpha_j=B/2^j. This is look 1, so its three-model Holm threshold is 1/160=0.00625. The next look receives 1/320=0.003125; all future looks together retain 0.00625. Future continuations must advance this same ledger, not restart the budget.

The forward-adjusted column is min(1,2^j times the within-look Holm value), compared with B=0.0125. It is equivalent to the allocated within-look decision and is not an additional rejection route. Inclusive upper/lower tails are used; two-sided p is twice the smaller tail capped at one.

A union bound over the Holm families bounds the probability of any false rejection in this forward family by 0.0125, provided the model p-values remain valid conditional on prior information and design choices. It does not require independence between looks, but it does require those validity assumptions. The deterministic prime stream does not itself establish exchangeability or circular-shift invariance.

Method background: [Tian and Ramdas, Online control of the familywise error rate, section 2](https://arxiv.org/html/1910.04900v2). The specific budget and its application to these three-model windows are this audit’s design choices.

## Diagnostics and unresolved claims

The fixed 9,999-draw diagnostic with seed 20261111 gives 8,502 scores at least the observed value, plus-one tail 0.850300. Exact distributions govern decisions. All 529 template phases are descriptive: 259 reach the observed overlap, with mask exposure 11228–11243. No best phase is selected.

Null reference ranges are not effect-size confidence intervals. The continuation is not an independent random sample; repeated execution reproduces one fixed evaluation. General prime laws, physical resonance, prime/geometry coupling, and complete engine behavior remain untested. The chart/sample mismatch remains unresolved. Original inputs and earlier result sets are preserved.
