"""Read-only archive inventory; never execute supplied code."""
from collections import Counter
import hashlib
import json, os, argparse
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

NAMES=[
 'Corner_Relay_Two_Return_Verification.zip',
 'phase_367_audit_2026-11-11 (1).zip',
 'prime_lattice_independent_python_audit (1).zip',
 'research_run_2026-11-11.zip',
 'Trident_Acceptance_Repaired_2026-11-11 (6).zip',
 'Trident_Array_Render_Source.zip',
 'trident_engine_irregular_return_v05_concept.zip',
 'Trident_Witness_Acceptance_Addendum_2026-11-11 (1).zip',
 '367_phase_prime_corrected.zip',
]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input-dir',type=Path,default=Path('C:/Users/Andrew/Downloads'))
args=parser.parse_args()
destination=Path(os.environ.get('NINE_AUDIT_BASE',str(Path(__file__).resolve().parent/'nine_archive_audit')))
destination.mkdir(parents=True,exist_ok=True)
inventory=[]
for i,name in enumerate(NAMES,1):
 p=args.input_dir/name
 record={'id':f'A{i:02d}','filename':name,'path':str(p),'exists':p.is_file()}
 if p.is_file():
  record.update(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
  with ZipFile(p) as z:
   infos=z.infolist()
   record['files']=[{'name':x.filename,'bytes':x.file_size,'compressed_bytes':x.compress_size,
                     'crc32':f'{x.CRC:08x}','encrypted':bool(x.flag_bits&1)} for x in infos if not x.is_dir()]
   record['total_uncompressed_bytes']=sum(x.file_size for x in infos)
   record['duplicate_member_names']=[n for n,c in Counter(x.filename for x in infos).items() if c>1]
   record['unsafe_paths']=[x.filename for x in infos if PurePosixPath(x.filename).is_absolute() or '..' in PurePosixPath(x.filename).parts or '\\' in x.filename]
   record['extensions']=dict(Counter(Path(x.filename).suffix.lower() for x in infos if not x.is_dir()))
 inventory.append(record)
(destination/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n',encoding='utf-8')
for r in inventory:
 print(json.dumps({k:v for k,v in r.items() if k!='files'},ensure_ascii=True))
 print('\n'.join('  '+f['name']+' ('+str(f['bytes'])+' bytes)' for f in r.get('files',[])))
