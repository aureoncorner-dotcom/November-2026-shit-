import hashlib,json,os
from pathlib import Path
base=Path(os.environ.get('NINE_AUDIT_BASE',str(Path(__file__).resolve().parent/'nine_archive_audit')))
roots={'A01':'','A02':'phase_367_audit','A03':'prime_lattice_audit','A04':'research_run',
       'A05':'trident_acceptance_repaired_2026-11-11','A06':'','A07':'trident_v05',
       'A08':'Trident_Witness_Acceptance_Review','A09':'corrected_367_figure'}
results=[]
for key,sub in roots.items():
 root=base/key/sub
 manifest=next((root/n for n in ('SHA256SUMS.json','manifest.json') if (root/n).exists()),None)
 result={'archive':key,'root':str(root),'manifest':str(manifest) if manifest else None}
 if manifest:
  data=json.loads(manifest.read_text(encoding='utf-8'))
  if isinstance(data,dict) and 'files' in data:data=data['files']
  entries=[(x['path'],x) for x in data] if isinstance(data,list) else list(data.items())
  failures=[]
  for name,expected in entries:
   p=root/name
   wanted=expected if isinstance(expected,str) else expected['sha256']
   if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=wanted:failures.append(name)
  members={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
  extra=members-{name for name,_ in entries}-{manifest.name}
  result.update(listed_files=len(entries),mismatches=failures,unlisted=sorted(extra))
 results.append(result)
(base/'manifest_checks.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results,indent=2))
