"""Run inspected supplied entrypoints only in disposable workspace copies."""
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
base=Path(os.environ.get('NINE_AUDIT_BASE',str(Path(__file__).resolve().parent/'nine_archive_audit')))
runs=base/'runs';runs.mkdir(exist_ok=True)
logs=base/'logs';logs.mkdir(exist_ok=True)
tmp=base/'tmp';tmp.mkdir(exist_ok=True)
env=dict(os.environ,PYTHONUTF8='0',PYTHONIOENCODING='cp1252',PYTHONDONTWRITEBYTECODE='1',
         TEMP=str(tmp),TMP=str(tmp),MPLCONFIGDIR=str(tmp/'mpl'))
env.pop('PYTHONPATH',None)
records=[]
def copy(key):
 dest=runs/key
 if dest.exists():raise RuntimeError('Existing run copy: '+str(dest))
 shutil.copytree(base/key,dest)
 return dest
def run(name,cwd,args,extra=None,timeout=180):
 start=time.perf_counter()
 p=subprocess.run([sys.executable,'-B',*args],cwd=cwd,env=dict(env,**(extra or {})),
                   capture_output=True,timeout=timeout)
 (logs/(name+'.stdout.txt')).write_bytes(p.stdout)
 (logs/(name+'.stderr.txt')).write_bytes(p.stderr)
 record={'name':name,'cwd':str(cwd),'arguments':args,
         'base_environment':{'PYTHONUTF8':'0','PYTHONIOENCODING':'cp1252','PYTHONDONTWRITEBYTECODE':'1'},
         'environment_overrides':extra or {},
         'returncode':p.returncode,'seconds':round(time.perf_counter()-start,3),
         'stdout_log':name+'.stdout.txt','stderr_log':name+'.stderr.txt'}
 records.append(record)
 (base/'execution_records.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(record),flush=True)
 return p

a1=copy('A01')/'corner_relay'
run('A01_provenance',a1,['run_with_provenance.py'])
run('A01_two_returns',a1,['check_two_returns.py'])
run('A01_tests_optimized',a1,['-O','-m','unittest','-v','test_corner_relay.py'])
a2=copy('A02')/'phase_367_audit'
run('A02_phase',a2,['audit_367.py'])
a3=copy('A03')/'prime_lattice_audit'
run('A03_original_cp1252',a3,['run_all.py'])
run('A03_original_utf8',a3,['run_all.py'],{'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8'})
a4=copy('A04')/'research_run'
run('A04_research',a4,['source/run_research_audit.py'],timeout=300)
a5=copy('A05')/'trident_acceptance_repaired_2026-11-11'
run('A05_integration_normal',a5,['integration/run_phase_relay_witness.py'])
run('A05_contract_normal',a5,['acceptance/check_witness_and_trace.py'])
run('A05_integration_optimized',a5,['-O','integration/run_phase_relay_witness.py'])
run('A05_contract_optimized',a5,['-O','acceptance/check_witness_and_trace.py'])
run('A05_negative_regressions',a5,['acceptance/test_repaired_gate.py'],timeout=300)
a8=copy('A08')/'Trident_Witness_Acceptance_Review'
run('A08_as_shipped_missing_dependency',a8,['check_witness_and_trace.py'])
legacy=runs/'historical_combined_reconstructed'
shutil.copytree(base/'A05/trident_acceptance_repaired_2026-11-11',legacy)
shutil.copyfile(legacy/'history/unpatched_adapter.py',legacy/'integration/run_phase_relay_witness.py')
for name in ('integrated_receipt.json','integrated_trace.json','integrated_summary.csv'):
 shutil.copyfile(legacy/'history/unpatched_outputs'/name,legacy/'outputs'/name)
binding={'TRIDENT_COMBINED_ROOT':str(legacy)}
run('A08_contract_bound_to_preserved_history',a8,['check_witness_and_trace.py'],binding)
run('A08_optimized_defect_reproduction',a8,['test_optimized_assertion_boundary.py'],binding)
a9=copy('A09')/'corrected_367_figure'
run('A09_render',a9,['source/plot_367.py'])
print('Finished inspected supplied-script execution.',flush=True)
