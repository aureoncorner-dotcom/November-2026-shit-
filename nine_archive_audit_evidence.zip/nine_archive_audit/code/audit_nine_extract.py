"""Safely materialize verified archive copies for inspection and isolated tests."""
import hashlib
import json, os
from pathlib import Path
import stat
from zipfile import ZipFile
base=Path(os.environ.get('NINE_AUDIT_BASE',str(Path(__file__).resolve().parent/'nine_archive_audit')))
inventory=json.loads((base/'inventory.json').read_text(encoding='utf-8'))
allfiles=[]
for r in inventory:
 target=base/r['id']
 if target.exists():raise RuntimeError('Extraction already exists: '+str(target))
 if r['unsafe_paths'] or r['duplicate_member_names']:raise RuntimeError('Ambiguous archive paths')
 source=Path(r['path'])
 if hashlib.sha256(source.read_bytes()).hexdigest()!=r['sha256']:raise RuntimeError('Archive changed')
 target.mkdir()
 with ZipFile(source) as z:
  bad=z.testzip()
  if bad:raise RuntimeError('ZIP CRC failed: '+bad)
  for member in z.infolist():
   if member.is_dir():continue
   if stat.S_ISLNK(member.external_attr>>16):raise RuntimeError('Symbolic link in ZIP')
   path=(target/member.filename).resolve()
   if target.resolve() not in path.parents:raise RuntimeError('Unsafe resolved destination')
   content=z.read(member)
   path.parent.mkdir(parents=True,exist_ok=True)
   path.write_bytes(content)
   allfiles.append({'archive':r['id'],'name':member.filename,'sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content)})
(base/'extracted_files.json').write_text(json.dumps(allfiles,indent=2)+'\n',encoding='utf-8')
codes={}
for f in allfiles:
 if f['name'].endswith('.py'):codes.setdefault(f['sha256'],[]).append(f['archive']+'/'+f['name'])
print(json.dumps({'archive_count':len(inventory),'total_files':len(allfiles),
                  'python_files':sum(len(v) for v in codes.values()),'unique_python_files':len(codes),
                  'duplicate_python_groups':[v for v in codes.values() if len(v)>1]},indent=2))
