"""Independent, bounded checks of the nine-archive audit. No source results are
used as an oracle. Imported relay code is used only for two contract probes.
All writes go into this script's workspace evidence directory.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter, defaultdict
from dataclasses import replace
from zipfile import ZipFile
import ast, csv, hashlib, importlib.util, json, math, os, sys
import xml.etree.ElementTree as ET

BASE=Path(os.environ.get('NINE_AUDIT_BASE',str(Path(__file__).resolve().parent/'nine_archive_audit')))
A1=BASE/'A01/corner_relay'
A2=BASE/'A02/phase_367_audit'
A3=BASE/'A03/prime_lattice_audit'
A4=BASE/'A04/research_run'
A5=BASE/'A05/trident_acceptance_repaired_2026-11-11'
A6=BASE/'A06'
A7=BASE/'A07/trident_v05'
A8=BASE/'A08/Trident_Witness_Acceptance_Review'
A9=BASE/'A09/corrected_367_figure'
checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def jread(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def record(name,condition,**details):
    checks.append({'name':name,'status':'PASS' if condition else 'FAIL',**details})
def equal_rows(name,actual,expected):
    mismatch=[]
    if len(actual)!=len(expected):mismatch.append({'row_count':[len(actual),len(expected)]})
    for i,(a,e) in enumerate(zip(actual,expected),1):
        if a!=e:mismatch.append({'row':i,'actual':a,'expected':e})
    record(name,not mismatch,rows=len(actual),fields=sum(map(len,expected)),mismatches=mismatch[:10],mismatch_count=len(mismatch))

# Euler's linear sieve, independently implemented here.
limit=33000
least=[0]*(limit+1);primes=[]
for n in range(2,limit+1):
    if least[n]==0:least[n]=n;primes.append(n)
    for p in primes:
        if p>least[n] or p*n>limit:break
        least[p*n]=p
prime=lambda n:n>=2 and least[n]==n
stream=''.join(str(p) for p in primes)[:14351]
if len(stream)!=14351:raise RuntimeError('Insufficient prime stream')
hit=lambda n:prime(n) and stream[n-1] in '2357'
hits={n for n in range(1,14352) if hit(n)}
mask=hits & set(range(1,530))
coord=[];repeat=[]
for n in range(1,14352):
    row,col=divmod(n-1,113);copy0,local0=divmod(n-1,529)
    local=local0+1
    if n in hits:
        coord.append(dict(zip(['prime_stream_position','digit','row_127','col_113','mirrored_row_127','row_23_if_within_529','col_23_if_within_529'],map(str,[n,stream[n-1],row+1,col+1,127-row,(n-1)//23+1 if n<=529 else '',(n-1)%23+1 if n<=529 else '']))))
    char='#' if local in mask else 'o' if local==437 else '.'
    repeat.append(dict(zip(['absolute_position','copy_number','position_in_copy','copy_character','original_prime_stream_digit','prime_numbered_position','prime_digit_2_3_5_7','copied_hash','true_double_key','copied_hash_and_true_double_key','row_127','column_113'],map(str,[n,copy0+1,local,char,stream[n-1],int(prime(n)),int(stream[n-1] in '2357'),int(local in mask),int(n in hits),int(local in mask and n in hits),row+1,col+1]))))
equal_rows('Original coordinate CSV, every field',rows(A3/'inputs/prime_double_key_coordinates.csv'),coord)
equal_rows('Original repeat CSV, every field',rows(A3/'inputs/global_prime_repeat_positions.csv'),repeat)
copied={n for n in range(1,14352) if (n-1)%529+1 in mask}
post=hits-set(range(1,530))
phase_counts=[sum(((n-1-s)%529+1) in mask for n in post) for s in range(529)]
prime_summary={'definition':'1-based prime stream position is prime and its digit is one of 2,3,5,7',
    'counts':{str(n):sum(p<=n for p in hits) for n in (529,913,14351)},
    'copied':len(copied),'overlap':len(hits&copied),'construction_overlap':len(mask),
    'later_overlap':len(post&copied),'marker_occurrences':sum(r['copy_character']=='o' for r in repeat),
    'even_copy_overlaps':sorted(n for n in hits&copied if ((n-1)//529+1)%2==0),
    'all_529_shifts_descriptive':{'minimum':min(phase_counts),'maximum':max(phase_counts),
        'mean_exact':str(F(sum(phase_counts),529)),'at_least_observed':sum(x>=len(post&copied) for x in phase_counts),
        'not_a_new_holdout_or_significance_test':True}}
record('Prime counts and overlaps',prime_summary['counts']=={'529':43,'913':74,'14351':732} and len(copied)==1169 and len(hits&copied)==104,**prime_summary)

# Compare original workbook cells through OOXML, no office application needed.
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with ZipFile(A3/'inputs/prime_grid_73x37(3).xlsx') as z:
    sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    cells={c.attrib['r']:int(c.find('s:v',NS).text) for c in sheet.findall('.//s:sheetData/s:row/s:c',NS) if c.find('s:v',NS) is not None}
    formulas=sheet.findall('.//s:f',NS)
def colname(n):
    label=''
    while n:
        n,k=divmod(n-1,26);label=chr(65+k)+label
    return label
expected_cells={f'{colname(c)}{r}':primes[(r-1)*73+c-1] for r in range(1,38) for c in range(1,74)}
record('All original XLSX numeric cells',cells==expected_cells and not formulas,cells=len(cells),center_AK19=cells.get('AK19'),formula_count=len(formulas),generated_23x23_center=primes[264])

# Text extraction provenance can now be checked against the original binaries.
tables=jread(A4/'inputs/source_tables.json')
for table,filename in zip(tables,['prime_double_key_coordinates.csv','global_prime_repeat_positions.csv']):
    with (A3/'inputs'/filename).open(encoding='utf-8-sig',newline='') as f:actual=list(csv.reader(f))
    record('Research extracted table matches original: '+filename,actual==[table['header'],*table['rows']],rows=len(actual)-1)
for extracted,original in [('geometry_master_text_extract.md','Geometry_Master_2.10_maximum_improved(6).md'),('prior_witness_report.txt','geometry_quantum_witness_execution_report(6).txt')]:
    a=(A4/'inputs'/extracted).read_text(encoding='utf-8').strip()
    b=(A3/'inputs'/original).read_text(encoding='utf-8').strip()
    record('Research text matches original after newline/outer whitespace normalization: '+extracted,a==b)

# Independently rotated declared shapes; strict orientation test, then line
# coefficients for intersection coordinates. This does not import source geometry.
H=[(-1.35,-.95),(-.68,1.2),(1.02,.22),(1.42,-.49),(1.11,-.83)]
Q=[(-.61,-.9),(.99,-.9),(.99,.7),(-.61,.7),(-.61,-.9)]
def rotate(points,angle):
    t=math.radians(float(angle%360));c=math.cos(t);s=math.sin(t)
    return [(x*c-y*s,x*s+y*c) for x,y in points]
def orient(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
min_abs_orientation=float('inf')
def crossings(h,q):
    global min_abs_orientation
    pts=[]
    for a,b in zip(h,h[1:]):
        for c,d in zip(q,q[1:]):
            v=(orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b))
            min_abs_orientation=min(min_abs_orientation,*(abs(t) for t in v))
            if v[0]*v[1]<0 and v[2]*v[3]<0:
                # ax+by+c=0 for each supporting line.
                la=(a[1]-b[1],b[0]-a[0],a[0]*b[1]-b[0]*a[1])
                lb=(c[1]-d[1],d[0]-c[0],c[0]*d[1]-d[0]*c[1])
                det=la[0]*lb[1]-lb[0]*la[1]
                pt=((la[1]*lb[2]-lb[1]*la[2])/det,(la[2]*lb[0]-lb[2]*la[0])/det)
                if not any(math.dist(pt,x)<1e-8 for x in pts):pts.append(pt)
    return pts
geometry={};expected=[]
for B in (360,367):
    for n in range(925):
        ah=F(-B*n,231)%360;aq=F(B*n,132)%360;delta=F(B*n,84)%360
        hh=rotate(H,ah);qq=rotate(Q,aq);xx=crossings(hh,qq)
        geometry[B,n]={'h':hh,'q':qq,'crossings':xx,'count':len(xx),'delta':delta}
        expected.append(dict(zip(['base_degrees','step','hook_orientation_exact','square_orientation_exact','relative_phase_exact','segment_intersections'],map(str,[B,n,ah,aq,delta,len(xx)]))))
equal_rows('Phase audit all 1850 output rows',rows(A2/'outputs/recomputed_steps.csv'),expected)
equal_rows('Corrected plot input all 1850 rows',rows(A9/'inputs/recomputed_steps.csv'),expected)
counts={str(B):dict(sorted(Counter(geometry[B,n]['count'] for n in range(925)).items())) for B in (360,367)}
record('Geometry crossing totals and nondegeneracy',counts=={'360':{2:408,4:517},'367':{0:4,2:435,4:479,6:7}} and min_abs_orientation>1e-8,
       histogram=counts,minimum_absolute_orientation=min_abs_orientation,endpoint_counts=[geometry[367,0]['count'],geometry[367,924]['count']])
periods={}
for B in (360,367):
    periods[str(B)]={'relative':F(B,84*360).denominator,
        'both_orientations':math.lcm(F(B,231*360).denominator,F(B,132*360).denominator),
        'five_declared_rates_conditional':math.lcm(*(F(B,p*360).denominator for p in (231,132,913,1109,4723)))}
record('Exact integer-step orientation periods',periods['360']['relative']==84 and periods['367']['relative']==30240 and periods['360']['both_orientations']==924 and periods['367']['both_orientations']==332640,periods=periods)
expected_plot=[]
for n in range(925):
    expected_plot.append(dict(zip(['step','relative_phase_degrees','intersection_count',*(f'CW_angle_{p}_degrees' for p in (231,132,913,1109,4723))],map(str,[n,geometry[367,n]['delta'],geometry[367,n]['count'],*(F(s*367*n,p) for p,s in [(231,1),(132,-1),(913,1),(1109,-1),(4723,1)])]))))
equal_rows('Corrected plot exported exact values',rows(A9/'plotted_values.csv'),expected_plot)
checkpoints=[]
for k in range(11):
    n=84*k;p=n+1
    checkpoints.append(dict(zip(['checkpoint_k','step_n','stream_position','row_1_based','column_1_based','digit','double_key','relative_phase_367'],map(str,[k,n,p,(p-1)//83+1,(p-1)%83+1,stream[p-1],hit(p),F(367*n,84)%360]))))
equal_rows('Checkpoint diagonal and actual prime hits',rows(A2/'outputs/checkpoints.csv'),checkpoints)
equal_rows('Corrected plot checkpoint inputs',rows(A9/'inputs/checkpoints.csv'),checkpoints)
record('All 84-step geometric checkpoints have two crossings',all(geometry[367,n]['count']==2 for n in range(0,925,84)),samples=12,phase_at_924=str(geometry[367,924]['delta']))

render_record=jread(A6/'coordinates_and_checks.json');g=geometry[367,924]
max_error=max(math.dist(a,b) for key,arr in [('hook_rotated',g['h']),('square_rotated',g['q'])] for a,b in zip(render_record[key],arr))
intersection_error=max(min(math.dist(a,b) for b in g['crossings']) for a in render_record['crossings'])
record('Array render numerical coordinate receipt',max_error<1e-11 and len(render_record['crossings'])==len(g['crossings']) and intersection_error<1e-11,maximum_rotation_error=max_error,maximum_crossing_error=intersection_error,crossings=g['crossings'])
aj=[0,-.025,.048,-.035,.04,.012,-.035,.055,-.03,.045,-.05,.03,.01]
rj=[.015,.055,-.012,.06,-.05,.01,.04,-.02,.06,-.03,-.06,.015,-.02]
max_chamber_error=0
for i,r in enumerate(render_record['chambers']):
    t=math.pi/2-i*2*math.pi/13+aj[i]
    pos=(30.4*(1+rj[i])*math.cos(t),24*(1+rj[i])*math.sin(t))
    max_chamber_error=max(max_chamber_error,math.dist((r['x'],r['y']),pos))
record('Thirteen declared chamber coordinates',len(render_record['chambers'])==13 and max_chamber_error<1e-11,maximum_error=max_chamber_error,interpretation='Declared design parameters, not a discovery or a physical prediction')

# Read constant declarations without executing the Matplotlib renderers.
def assignments(path):
    result={}
    for node in ast.parse(path.read_text(encoding='utf-8')).body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):result[node.targets[0].id]=node.value
    return result
aa=assignments(A6/'render_trident.py');bb=assignments(A7/'build.py')
array_literal=lambda node:ast.literal_eval(node.args[0])
same_design=all(array_literal(aa[k])==array_literal(bb[k]) for k in ('aj','rj')) and ast.literal_eval(aa['names'])==ast.literal_eval(bb['names']) and ast.literal_eval(aa['handles'])==ast.literal_eval(bb['handles'])
record('Array/concept design declaration linkage',same_design and array_literal(aa['H'])==array_literal(bb['hook']),method='AST literal comparison without executing drawing code')

lineage=[]
def same(name,left,right):
    entry={'relationship':name,'left':str(left.relative_to(BASE)),'right':str(right.relative_to(BASE)) if right.is_relative_to(BASE) else str(right),'same_bytes':sha(left)==sha(right),'sha256_left':sha(left),'sha256_right':sha(right)}
    lineage.append(entry);record(name,entry['same_bytes'])
same('Concept archive exactly matches nested original input',A3/'inputs/trident_engine_irregular_return_v05_concept(1).zip',Path(jread(BASE/'inventory.json')[6]['path']))
same('Relay source duplicated unchanged in repaired package',A1/'corner_relay.py',A5/'sources/corner_relay/corner_relay.py')
same('Witness source duplicated unchanged in repaired package',A4/'source/geometry_quantum_witness.py',A5/'sources/geometry_quantum_witness.py')
same('Addendum checker preserved in repaired history',A8/'check_witness_and_trace.py',A5/'history/unpatched_contract_checker.py')
same('Addendum defect test preserved in repaired history',A8/'test_optimized_assertion_boundary.py',A5/'history/unpatched_optimized_assertion_boundary.py')
for source,dest in [(A3,A5/'sources/prime_lattice_audit'),(A2,A5/'sources/phase_367_audit')]:
    diffs=[p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file() and (not (dest/p.relative_to(source)).is_file() or sha(p)!=sha(dest/p.relative_to(source)))]
    record('All original files copied unchanged into repaired package: '+source.name,not diffs,differences=diffs)
for source,fresh in [(A5/'outputs/integrated_trace.json',BASE/'runs/A05/trident_acceptance_repaired_2026-11-11/outputs/integrated_trace.json'),(A9/'367_phase_prime_corrected.svg',BASE/'runs/A09/corrected_367_figure/367_phase_prime_corrected.svg'),(A9/'plotted_values.csv',BASE/'runs/A09/corrected_367_figure/plotted_values.csv')]:
    same('Fresh output byte reproduction: '+str(source.relative_to(BASE)),source,fresh)
for rel in ['A01/corner_relay/reference_trace.json','A01/corner_relay/two_return_results/two_return_trace.json']:
    source=BASE/rel;fresh=BASE/'runs'/rel
    a=source.read_bytes();b=fresh.read_bytes()
    record('Fresh relay trace values: '+rel,jread(source)==jread(fresh),
           identical_file_bytes=a==b,original_file_sha256=sha(source),fresh_file_sha256=sha(fresh),
           identical_after_newline_normalization=a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n'),
           observation='Source files use LF; Windows writes CRLF. Trace values reproduce but the serialized file hashes differ.')

# Bounded input-contract probes, no network or production system involved.
spec=importlib.util.spec_from_file_location('nine_audit_relay',A1/'corner_relay.py')
relay=importlib.util.module_from_spec(spec);sys.modules[spec.name]=relay;spec.loader.exec_module(relay)
probes=[]
for label,changes in [('unsupported_schema',{'schema':'unrecognized/event/v999'}),('empty_transition_id',{'transition_id':''})]:
    event=relay.Event.build(transition_id='contract-probe',kind=relay.EventKind.SEND,actor=relay.Actor.O,target=relay.Actor.S,payload=b'local audit fixture')
    event=replace(event,**changes)
    canonical=json.dumps(event.body_dict(),sort_keys=True,separators=(',',':'),ensure_ascii=False)
    event=replace(event,event_id='evt:'+hashlib.sha256(canonical.encode('utf-8')).hexdigest())
    endpoint=relay.Endpoint(relay.Actor.S)
    try:
        witness=endpoint.receive(event);accepted=witness.accepted;result=witness.result
    except relay.TransitionRejected as e:
        accepted=False;result=str(e)
    probes.append({'probe':label,'event_integrity_errors':list(event.integrity_errors()),'receiver_accepted':accepted,'result':result,
                   'boundary':'Direct Event objects with internally consistent hashes; Event.build itself always creates the fixed schema and rejects an empty transition identifier.'})
endpoint=relay.Endpoint(relay.Actor.S)
first=relay.Event.build(transition_id='same-peer-transition',kind=relay.EventKind.SEND,actor=relay.Actor.O,target=relay.Actor.S,payload=b'first')
second=relay.Event.build(transition_id='same-peer-transition',kind=relay.EventKind.SEND,actor=relay.Actor.O,target=relay.Actor.S,payload=b'second')
first_receipt=endpoint.receive(first)
try:
    second_receipt=endpoint.receive(second)
    accepted=second_receipt.accepted;applied=second_receipt.effect_applied;result=second_receipt.result
except relay.TransitionRejected as e:
    accepted=applied=False;result=str(e)
probes.append({'probe':'different_payload_same_peer_transition_id','first_accepted':first_receipt.accepted,
               'second_accepted':accepted,'second_effect_applied':applied,'received_send_count':len(endpoint.view().received_send_ids),'result':result,
               'boundary':'Two distinct Event.build calls delivered directly to receive. Normal Endpoint.send rejects conflicting reuse locally; receive deduplicates event IDs rather than peer transition IDs.'})

# PNG equality is an observation, not a mathematical criterion.
image_comparison={}
try:
    from PIL import Image,ImageChops
    old=Image.open(A9/'367_phase_prime_corrected.png').convert('RGB')
    new=Image.open(BASE/'runs/A09/corrected_367_figure/367_phase_prime_corrected.png').convert('RGB')
    image_comparison={'size_original':old.size,'size_fresh':new.size,'same_bytes':sha(A9/'367_phase_prime_corrected.png')==sha(BASE/'runs/A09/corrected_367_figure/367_phase_prime_corrected.png'),'identical_pixels':old.size==new.size and ImageChops.difference(old,new).getbbox() is None}
    preview=BASE/'previews';preview.mkdir(exist_ok=True)
    for source,name in [(A3/'inputs/02-caelior_367_phase_and_prime_audit-1-3-.png','original_phase.png'),(A9/'367_phase_prime_corrected.png','corrected_phase.png')]:
        im=Image.open(source);im.thumbnail((1200,850));im.save(preview/name)
except ImportError: image_comparison={'status':'Pillow unavailable'}

out={'scope':'Finite source replays and independent mathematical checks; no new prime holdout test',
     'overall_assessment':'MIXED: finite consistency checks reproduce; three direct relay input-contract probes expose validation gaps; two drawing programs were not executed.',
     'checks':checks,'pass_count':sum(x['status']=='PASS' for x in checks),'fail_count':sum(x['status']=='FAIL' for x in checks),
     'lineage':lineage,'relay_contract_probes':probes,'relay_contract_unexpected_acceptances':len(probes),'corrected_png_comparison':image_comparison,
     'rendering_limitations':{'A06':'Full renderer not executed: Matplotlib unavailable; pip could find no distribution. Numerical coordinate receipt and declared design independently checked.',
                              'A07':'Full renderer not executed: Matplotlib unavailable and original output directory is hard-coded to /mnt/data/trident_v05. Declared geometry independently checked.'}}
(BASE/'independent_checks.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'pass':out['pass_count'],'fail':out['fail_count'],'failures':[c for c in checks if c['status']=='FAIL'],'relay_probes':probes,'png':image_comparison},ensure_ascii=True,indent=2))
if out['fail_count']:sys.exit(1)
