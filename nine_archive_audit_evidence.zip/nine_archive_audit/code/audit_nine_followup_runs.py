"""Follow-up to distinguish an explicit I/O override from Windows defaults."""
from pathlib import Path
import json, os, subprocess, sys, time

base = Path(os.environ.get('NINE_AUDIT_BASE',str(Path(__file__).resolve().parent/'nine_archive_audit')))
logs = base / 'logs'
env = dict(os.environ, PYTHONUTF8='0', PYTHONDONTWRITEBYTECODE='1',
           TEMP=str(base/'tmp'), TMP=str(base/'tmp'))
env.pop('PYTHONIOENCODING', None)
env.pop('PYTHONPATH', None)
start = time.perf_counter()
args = ['-B', 'source/run_research_audit.py']
p = subprocess.run([sys.executable, *args], cwd=base/'runs/A04/research_run',
                   env=env, capture_output=True, timeout=300)
name = 'A04_research_windows_default_io'
for stream in ('stdout','stderr'):
    (logs/f'{name}.{stream}.txt').write_bytes(getattr(p, stream))
record = {'name':name, 'arguments':args, 'returncode':p.returncode,
          'seconds':round(time.perf_counter()-start,3),
          'environment':{'PYTHONUTF8':'0','PYTHONIOENCODING':'unset'},
          'stdout_log':f'{name}.stdout.txt','stderr_log':f'{name}.stderr.txt'}
(base/'followup_execution_records.json').write_text(json.dumps([record],indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
if p.returncode == 0:
    data=json.loads((base/'runs/A04/research_run/outputs/run_results.json').read_text(encoding='utf-8'))
    print(json.dumps({'pass_count':data['pass_count'],'fail_count':data['fail_count']}))

