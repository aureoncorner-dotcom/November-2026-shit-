"""Replay this audit in a new directory while preserving bundled input ZIPs.

Run from the extracted evidence bundle: python code/reproduce_nine_audit.py
Python 3.10+ is required; Pillow is required for the corrected PNG rendering.
The supplied Matplotlib renderers are not executed by this audit recipe.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,sys

HERE=Path(__file__).resolve().parent
PACKAGE=HERE.parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--inputs',type=Path,default=PACKAGE/'inputs')
p.add_argument('--work',type=Path,default=PACKAGE/'audit_replay')
args=p.parse_args()
root=args.work.resolve();inputs=args.inputs.resolve()
if root.exists():raise SystemExit('Choose a new --work directory; existing work is never overwritten.')
inventory=json.loads((PACKAGE/'evidence/inventory.json').read_text(encoding='utf-8'))
for entry in inventory:
    path=inputs/entry['filename']
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
        raise SystemExit('Missing or changed original input: '+str(path))
root.mkdir(parents=True)
# Windows file-copy APIs can reject the long names inside the preserved input
# tree even when Python's ordinary reads succeed. Use extended absolute paths
# throughout the disposable replay rather than changing any archived names.
tool_root=str(root)
if os.name=='nt' and not tool_root.startswith('\\\\?\\'):
    tool_root=('\\\\?\\UNC\\'+tool_root[2:]) if tool_root.startswith('\\\\') else '\\\\?\\'+tool_root
env=dict(os.environ,NINE_AUDIT_BASE=tool_root,PYTHONDONTWRITEBYTECODE='1')
tasks=[('audit_nine_inventory.py',['--input-dir',str(inputs)]),('audit_nine_extract.py',[]),
       ('audit_nine_manifests.py',[]),('audit_nine_runs.py',[]),('audit_nine_followup_runs.py',[]),
       ('audit_nine_independent.py',[]),('audit_nine_output_differences.py',[])]
results=[]
for script,arguments in tasks:
    proc=subprocess.run([sys.executable,'-B',str(HERE/script),*arguments],env=env,cwd=root,capture_output=True,timeout=600)
    (root/(script+'.stdout.txt')).write_bytes(proc.stdout)
    (root/(script+'.stderr.txt')).write_bytes(proc.stderr)
    result={'script':script,'returncode':proc.returncode};results.append(result)
    print(json.dumps(result),flush=True)
    if proc.returncode:break
result={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'work_directory':str(root),'stages':results,
        'note':'Individual original-program failures are retained in execution_records.json. Successful orchestration is not a claim that all supplied programs passed.'}
(root/'replay_receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
if len(results)!=len(tasks) or any(r['returncode'] for r in results):raise SystemExit(1)
print('Audit replay complete. Inspect independent_checks.json, execution_records.json, and followup_execution_records.json.')
