from pathlib import Path
import hashlib,json,os
base=Path(os.environ.get('NINE_AUDIT_BASE',str(Path(__file__).resolve().parent/'nine_archive_audit')))
out=[]
for rel in ['A01/corner_relay/reference_trace.json','A01/corner_relay/two_return_results/two_return_trace.json']:
    a=(base/rel).read_bytes();b=(base/'runs'/rel).read_bytes()
    out.append({'path':rel,'source_sha256':hashlib.sha256(a).hexdigest(),'fresh_sha256':hashlib.sha256(b).hexdigest(),
        'source_bytes':len(a),'fresh_bytes':len(b),'source_CRLF':a.count(b'\r\n'),'fresh_CRLF':b.count(b'\r\n'),
        'equal_after_CRLF_to_LF':a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n'),
        'equal_parsed_JSON':json.loads(a)==json.loads(b)})
def diff(a,b,path=''):
    if isinstance(a,dict) and isinstance(b,dict):
        return sum((diff(a.get(k),b.get(k),path+'/'+k) for k in a.keys()|b.keys()),[])
    if isinstance(a,list) and isinstance(b,list):
        if len(a)!=len(b):return [{'path':path,'lengths':[len(a),len(b)]}]
        return sum((diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
    return [] if a==b else [{'path':path,'original':a,'fresh':b}]
for rel in ['A02/phase_367_audit/outputs/results.json','A04/research_run/outputs/run_results.json']:
    a=json.loads((base/rel).read_text(encoding='utf-8'));b=json.loads((base/'runs'/rel).read_text(encoding='utf-8'))
    out.append({'path':rel,'parsed_differences':diff(a,b)})
(base/'output_differences.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
