PRIME-RUNE SCRAMBLE TREE — PHONE MODE START HERE

The full book is Prime_Rune_Scramble_PHONE.txt. It is long.

For voice reading, open or paste one file from the chapters folder at a time.
The chapter files follow the ascending odd-prime chapter labels.

The visual map is Prime_Rune_Scramble_TREE.md.
The auditable prime-to-rune lookup is Prime_Rune_Scramble_Map.csv.

The numbers in the spoken rune text are odd prime labels or allowed odd prime-factor composites.
The selection rule uses actual copied-hash and source-digit flags; the Sanskrit and horror effects are newly composed fiction.
The 437 landmark is not a source double-key result.

The scramble is deterministic: bank length 95, start offset 29, stride 37.
