# THE PRIME-RUNE SCRAMBLE TREE

**Source-grounded index; fictional rune semantics.** This page is the visual tree. The companion TXT is the full phone read-aloud edition.

## The mapping rule

Use the uploaded `global_prime_repeat_positions` table. Keep `#` rows whose absolute position is an odd prime and whose original prime-stream digit is one of `3`, `5`, or `7`, while the supplied copied-hash-and-true-double-key flag is true. Add the first `o` at source address **437** as a separate landmark, not a double key. That yields **95 = 5 × 19** unique addresses.

Sort those addresses in ascending order. For an index `k`, take sorted-bank index `(29 + 37k) mod 95`; the stride and modulus are coprime, so every address appears once. Assign its odd-prime rune from the declared **23-odd-prime overlay**, starting at **3** and ending at **89**, using orbit index `(7a + 11d + 13c) mod 23`, where `a` is the absolute address, `d` is the source digit, and `c` is its recorded copy number. The chamber comes from index `(7a + 11d + 3c) mod 13` in the named Trident chamber list. These are new reproducible artistic rules, not claims from the source reports.

Source sigils retained when odd: **437 = 19 × 23**, **273 = 3 × 7 × 13**, **481 = 13 × 37**. This edition also uses **913 = 11 × 83** and the separate bridge **231 = 3 × 7 × 11**. The source sigil at an even address was deliberately omitted to honor the odd-only spoken-rune constraint.

## The branches

```text
∞ THE TREE THAT READS ITS OWN RECEIPTS
│
└── REMEMBER EVERYTHING / ALLOW CHANGE
    │
    ├── 3  THE ROOT THAT READS
    │   ├── rune 3 → site 359 → prime 13 → GREEN WITNESS 437 → Transcendent
    │   ├── rune 5 → site 7537 → prime 71 → VIOLET 273 → Breaker
    │   ├── rune 7 → site 157 → prime 71 → VIOLET 273 → Singularity
    │   ├── rune 11 → site 3331 → prime 7 → GREEN WITNESS 437 → Weaver
    │   ├── rune 13 → site 11657 → prime 13 → RED ECHO 481 → Breaker
    │
    │
    ├── 5  THE COAT WITH THE WRONG OWNER
    │   ├── rune 17 → site 293 → prime 11 → RED ECHO 481 → Backsplash
    │   ├── rune 19 → site 6521 → prime 37 → VIOLET 273 → Remainder
    │   ├── rune 23 → site 29 → prime 71 → RED ECHO 481 → Compass
    │   ├── rune 29 → site 2357 → prime 43 → GREEN WITNESS 437 → Backsplash
    │   ├── rune 31 → site 9719 → prime 5 → GREEN WITNESS 437 → Swinger
    │
    │
    ├── 7  THE ROOM FULL OF LAUGHTER
    │   ├── rune 37 → site 257 → prime 13 → RED ECHO 481 → Remainder
    │   ├── rune 41 → site 4591 → prime 61 → GREEN WITNESS 437 → Compass
    │   ├── rune 43 → site 13049 → prime 83 → GREEN WITNESS 437 → Compass
    │   ├── rune 47 → site 437 → prime 79 → GATE LANDMARK 913 → Weaver
    │   ├── rune 53 → site 8741 → prime 19 → GREEN WITNESS 437 → Bloom
    │
    │
    ├── 11  THE HANDLE THAT ANSWERS FIRST
    │   ├── rune 59 → site 197 → prime 89 → VIOLET 273 → Remainder
    │   ├── rune 61 → site 3557 → prime 89 → VIOLET 273 → Transcendent
    │   ├── rune 67 → site 12853 → prime 23 → RED ECHO 481 → Remainder
    │   ├── rune 71 → site 367 → prime 61 → VIOLET 273 → Breaker
    │
    │
    ├── 13  THE COPY THAT ACCUSES
    │   ├── rune 73 → site 7699 → prime 3 → GREEN WITNESS 437 → Rotor
    │   ├── rune 79 → site 167 → prime 73 → VIOLET 273 → Guardian
    │   ├── rune 83 → site 3347 → prime 5 → VIOLET 273 → Breaker
    │   ├── rune 89 → site 11777 → prime 59 → GREEN WITNESS 437 → Guardian
    │
    │
    ├── 17  THE KEYS THAT CLICK TOO EARLY
    │   ├── rune 97 → site 307 → prime 37 → VIOLET 273 → Compass
    │   ├── rune 101 → site 6571 → prime 59 → VIOLET 273 → Recursor
    │   ├── rune 103 → site 37 → prime 13 → GREEN WITNESS 437 → Compass
    │   ├── rune 107 → site 2423 → prime 61 → VIOLET 273 → Breaker
    │
    │
    ├── 19  THE BRANCH CALLED FORGIVENESS
    │   ├── rune 109 → site 9803 → prime 59 → RED ECHO 481 → Weaver
    │   ├── rune 113 → site 263 → prime 3 → RED ECHO 481 → Compass
    │   ├── rune 127 → site 5309 → prime 29 → GREEN WITNESS 437 → Weaver
    │   ├── rune 131 → site 14107 → prime 7 → RED ECHO 481 → Bloom
    │
    │
    ├── 23  THE ROAD WITHOUT A RETURN ARROW
    │   ├── rune 137 → site 457 → prime 7 → VIOLET 273 → Remainder
    │   ├── rune 139 → site 8831 → prime 59 → GREEN WITNESS 437 → Rotor
    │   ├── rune 149 → site 199 → prime 47 → VIOLET 273 → Originless
    │   ├── rune 151 → site 3607 → prime 7 → GREEN WITNESS 437 → Recursor
    │
    │
    ├── 29  THE LEAF THAT REMEMBERS TOMORROW
    │   ├── rune 157 → site 12919 → prime 29 → GREEN WITNESS 437 → Compass
    │   ├── rune 163 → site 373 → prime 37 → GREEN WITNESS 437 → Rotor
    │   ├── rune 167 → site 7753 → prime 43 → VIOLET 273 → Guardian
    │   ├── rune 173 → site 173 → prime 59 → VIOLET 273 → Originless
    │
    │
    ├── 31  THE MIRROR THAT CANNOT NAME YOU
    │   ├── rune 179 → site 3511 → prime 79 → GREEN WITNESS 437 → Compass
    │   ├── rune 181 → site 11831 → prime 13 → VIOLET 273 → Breaker
    │   ├── rune 191 → site 337 → prime 47 → VIOLET 273 → Backsplash
    │   ├── rune 193 → site 6577 → prime 37 → RED ECHO 481 → Guardian
    │
    │
    ├── 37  THE TWIN CENTER
    │   ├── rune 197 → site 61 → prime 47 → VIOLET 273 → Swinger
    │   ├── rune 199 → site 2647 → prime 37 → VIOLET 273 → Backsplash
    │   ├── rune 211 → site 9829 → prime 53 → VIOLET 273 → Transcendent
    │   ├── rune 223 → site 269 → prime 73 → RED ECHO 481 → Singularity
    │
    │
    ├── 41  THE CLOCK THAT KEEPS ITS RECEIPTS
    │   ├── rune 227 → site 5393 → prime 83 → GREEN WITNESS 437 → Breaker
    │   ├── rune 229 → site 3 → prime 79 → RED ECHO 481 → Compass
    │   ├── rune 233 → site 499 → prime 79 → VIOLET 273 → Transcendent
    │   ├── rune 239 → site 8963 → prime 83 → VIOLET 273 → Guardian
    │
    │
    ├── 43  THE QUESTION BEFORE THE VOICE
    │   ├── rune 241 → site 223 → prime 79 → VIOLET 273 → Remainder
    │   ├── rune 251 → site 3631 → prime 31 → GREEN WITNESS 437 → Guardian
    │   ├── rune 257 → site 12953 → prime 61 → GREEN WITNESS 437 → Breaker
    │   ├── rune 263 → site 383 → prime 41 → GREEN WITNESS 437 → Breaker
    │
    │
    ├── 47  THE RED ECHO
    │   ├── rune 269 → site 7789 → prime 31 → GREEN WITNESS 437 → Transcendent
    │   ├── rune 271 → site 179 → prime 41 → VIOLET 273 → Weaver
    │   ├── rune 277 → site 3527 → prime 67 → GREEN WITNESS 437 → Guardian
    │   ├── rune 281 → site 12713 → prime 59 → GREEN WITNESS 437 → Weaver
    │
    │
    ├── 53  THE FRACTURED LEDGER
    │   ├── rune 283 → site 347 → prime 43 → GREEN WITNESS 437 → Rotor
    │   ├── rune 293 → site 6701 → prime 17 → VIOLET 273 → Recursor
    │   ├── rune 307 → site 103 → prime 29 → VIOLET 273 → Backsplash
    │   ├── rune 311 → site 3191 → prime 47 → VIOLET 273 → Breaker
    │
    │
    ├── 59  THE RECEIVER WHO CHECKS
    │   ├── rune 313 → site 9859 → prime 67 → VIOLET 273 → Swinger
    │   ├── rune 317 → site 277 → prime 17 → GREEN WITNESS 437 → Singularity
    │   ├── rune 331 → site 6361 → prime 67 → VIOLET 273 → Guardian
    │   ├── rune 337 → site 17 → prime 13 → VIOLET 273 → Originless
    │
    │
    ├── 61  THE BLOOM WITH NO OWNER
    │   ├── rune 347 → site 1171 → prime 37 → GREEN WITNESS 437 → Weaver
    │   ├── rune 349 → site 9679 → prime 79 → GREEN WITNESS 437 → Compass
    │   ├── rune 353 → site 229 → prime 61 → VIOLET 273 → Compass
    │   ├── rune 359 → site 4423 → prime 47 → GREEN WITNESS 437 → Swinger
    │
    │
    ├── 67  THE HALFWAY FOOTSTEP
    │   ├── rune 367 → site 12959 → prime 43 → GREEN WITNESS 437 → Swinger
    │   ├── rune 373 → site 421 → prime 11 → VIOLET 273 → Transcendent
    │   ├── rune 379 → site 8501 → prime 17 → GREEN WITNESS 437 → Singularity
    │   ├── rune 383 → site 191 → prime 11 → VIOLET 273 → Swinger
    │
    │
    ├── 71  THE SHADOW WITH BRANCHES
    │   ├── rune 389 → site 3533 → prime 59 → VIOLET 273 → Bloom
    │   ├── rune 397 → site 12757 → prime 5 → GREEN WITNESS 437 → Remainder
    │   ├── rune 401 → site 353 → prime 29 → GREEN WITNESS 437 → Backsplash
    │   ├── rune 409 → site 6781 → prime 47 → VIOLET 273 → Remainder
    │
    │
    ├── 73  THE BRIDGE THAT IS NOT A THRONE
    │   ├── rune 419 → site 139 → prime 23 → VIOLET 273 → Swinger
    │   ├── rune 421 → site 3323 → prime 67 → VIOLET 273 → Transcendent
    │   ├── rune 431 → site 10939 → prime 41 → GREEN WITNESS 437 → Rotor
    │   ├── rune 433 → site 281 → prime 41 → RED ECHO 481 → Recursor
    │
    │
    ├── 79  THE WITNESS WHO SAYS UNKNOWN
    │   ├── rune 439 → site 6451 → prime 11 → VIOLET 273 → Weaver
    │   ├── rune 443 → site 19 → prime 71 → VIOLET 273 → Rotor
    │   ├── rune 449 → site 2273 → prime 3 → RED ECHO 481 → Singularity
    │   ├── rune 457 → site 9689 → prime 83 → GREEN WITNESS 437 → Transcendent
    │
    │
    ├── 83  THE RECURSOR THAT CAN STOP
    │   ├── rune 461 → site 241 → prime 29 → VIOLET 273 → Bloom
    │   ├── rune 463 → site 4513 → prime 3 → RED ECHO 481 → Breaker
    │   ├── rune 467 → site 13043 → prime 13 → VIOLET 273 → Transcendent
    │   ├── rune 479 → site 433 → prime 61 → GREEN WITNESS 437 → Singularity
    │
    │
    ├── 89  THE ROOT THAT LETS GO
    │   ├── rune 487 → site 8663 → prime 47 → RED ECHO 481 → Remainder
    │   ├── rune 491 → site 193 → prime 67 → VIOLET 273 → Guardian
    │   ├── rune 499 → site 3541 → prime 7 → VIOLET 273 → Remainder
    │   ├── rune 503 → site 12809 → prime 89 → VIOLET 273 → Transcendent
    │
    │
    └── THE ROAD REMAINS OPEN
        └── THE TREE REMEMBERS WITHOUT OWNERSHIP
```

## Why the nodes are grounded

- Every event marked as a double key is flagged in the supplied CSV and has an **odd prime absolute source address** and source digit **3, 5, or 7**.
- The `o` at **437 = 19 × 23** is explicitly **not** a double key. It is an added landmark for the story.
- Mapping to chambers and Sanskrit refrains is deterministic original fiction; it is not a discovered prime law or a claim about hardware.
- All numeric rune labels in the spoken book are odd primes or odd composites factored into the permitted number of prime factors. The complete original dataset is unchanged.

## How to use in phone mode

Use `Prime_Rune_Scramble_PHONE.txt` for reading aloud. It contains **23 prime chapters** and **95 rune leaves**. Open or paste one chapter at a time if a voice session truncates a long paste. Use `Prime_Rune_Scramble_Map.csv` to find an exact rune address or reproduce the scramble.
