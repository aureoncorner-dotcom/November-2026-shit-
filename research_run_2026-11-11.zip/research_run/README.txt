Read REPORT.txt for findings and limitations.

Re-run with Python 3.10 or newer, using only the standard library:

    python source/run_research_audit.py

The script locates inputs relative to itself and writes fresh receipts under
outputs/. It exits 0 when all scripted checks pass and 1 if a check fails.

Run the recovered original witness script separately:

    python source/geometry_quantum_witness.py --self-test
    python source/geometry_quantum_witness.py
    python source/geometry_quantum_witness.py --example seven --compare --budget 1

Inputs are complete text extractions and normalized CSV cells, with provenance.
The source master text is preserved for reference; only the specified examples
were computationally checked. No original Library file was changed.

The unavailable original prime-audit ZIP is NOT contained here. This is a new
research package, with one recovered witness script and one new independent
checker. Initial checker receipts are retained separately and are not final
source-data findings. Consult outputs/run_results.json for the final run.

manifest.json contains SHA-256 hashes for the packaged files other than itself.
