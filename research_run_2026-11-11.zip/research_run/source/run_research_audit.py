#!/usr/bin/env python3
"""Reproducible finite research checks; Python standard library only.

The original prime-audit ZIP could not be downloaded. This is a NEW independent
audit of complete text-extracted tables and selected documented examples.
The separately recovered geometry_quantum_witness.py is executed unchanged.
"""
from __future__ import annotations

import csv
import hashlib
import importlib.util
import itertools as it
import json
import math
import platform
import subprocess
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs'
OUT.mkdir(exist_ok=True)
CHECKS = []


def check(name, condition, details=None):
    record = {'check': name, 'status': 'PASS' if condition else 'FAIL'}
    if details is not None:
        record['details'] = details
    CHECKS.append(record)
    if not condition:
        print('FAIL:', name, details, flush=True)
    return condition


def save_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def save_csv(name, rows, fields=None):
    with (OUT / name).open('w', newline='', encoding='utf-8') as f:
        if fields is None:
            fields = list(rows[0]) if rows else ['none']
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def sieve(limit):
    flags = bytearray(b'\x01') * (limit + 1)
    flags[:2] = b'\x00\x00'
    for p in range(2, math.isqrt(limit) + 1):
        if flags[p]:
            flags[p*p:limit+1:p] = b'\x00' * ((limit - p*p)//p + 1)
    return flags


def trial_primes_until(limit):
    primes = []
    for candidate in range(2, limit + 1):
        if all(candidate % p for p in it.takewhile(lambda p: p*p <= candidate, primes)):
            primes.append(candidate)
    return primes


def prime_audit():
    datasets = json.loads((ROOT / 'inputs/source_tables.json').read_text(encoding='utf-8'))
    coords, repeat = datasets
    n = 113 * 127
    flags = sieve(200_000)
    primes = [p for p in range(2, len(flags)) if flags[p]]
    digit_stream = ''.join(map(str, primes))[:n]
    digit_count = 0
    for last_stream_prime in primes:
        digit_count += len(str(last_stream_prime))
        if digit_count >= n:
            break
    oracle_bound = max(primes[2700], last_stream_prime, n)
    trial = trial_primes_until(oracle_bound)
    check('Independent sieve/trial-division agreement',
          trial == [p for p in primes if p <= oracle_bound],
          {'through_integer': oracle_bound, 'prime_count': len(trial)})
    check('Independent prime-digit stream agreement', ''.join(map(str, trial))[:n] == digit_stream)
    true_hits = {p for p in range(1, n+1) if flags[p] and digit_stream[p-1] in '2357'}
    expected_coords = []
    for p in sorted(true_hits):
        row, col = divmod(p-1, 113)
        smallrow, smallcol = divmod(p-1, 23)
        expected_coords.append([str(p), digit_stream[p-1], str(row+1), str(col+1), str(127-row),
                                str(smallrow+1) if p <= 529 else '',
                                str(smallcol+1) if p <= 529 else ''])
    mismatches = []
    for i, (actual, expected) in enumerate(it.zip_longest(coords['rows'], expected_coords), 1):
        if actual != expected:
            mismatches.append({'table': 'double_key', 'row': i,
                               'actual': json.dumps(actual), 'expected': json.dumps(expected)})
    check('All double-key coordinate records', not mismatches,
          {'actual_records': len(coords['rows']), 'expected_records': len(expected_coords),
           'columns': len(coords['header']), 'mismatch_count': len(mismatches)})

    base = {p for p in true_hits if p <= 529}
    copied_hits = {p for p in range(1, n+1) if ((p-1) % 529)+1 in base}
    expected_repeat = []
    for p in range(1, n+1):
        c, offset = divmod(p-1, 529)
        row, col = divmod(p-1, 113)
        copied, true = p in copied_hits, p in true_hits
        # 'o' is a literal source annotation at template position 437, not a prime hit.
        copied_character = '#' if copied else ('o' if offset+1 == 437 else '.')
        expected_repeat.append(list(map(str, [p, c+1, offset+1, copied_character,
                          digit_stream[p-1], int(bool(flags[p])), int(digit_stream[p-1] in '2357'),
                          int(copied), int(true), int(copied and true), row+1, col+1])))
    repeat_errors = []
    for i, (actual, expected) in enumerate(it.zip_longest(repeat['rows'], expected_repeat), 1):
        if actual != expected:
            repeat_errors.append({'table': 'global_repeat', 'row': i,
                                  'actual': json.dumps(actual), 'expected': json.dumps(expected)})
    mismatches.extend(repeat_errors)
    check('All global repeat-position fields', not repeat_errors,
          {'actual_rows': len(repeat['rows']), 'expected_rows': n,
           'columns': len(repeat['header']), 'mismatch_count': len(repeat_errors)})
    save_csv('table_mismatches.csv', mismatches, ['table', 'row', 'actual', 'expected'])

    copy_rows = []
    for c in range(1, math.ceil(n/529)+1):
        domain = set(range((c-1)*529+1, min(c*529,n)+1))
        a, b = copied_hits & domain, true_hits & domain
        copy_rows.append({'copy_number': c, 'start': min(domain), 'end': max(domain),
                          'positions': len(domain), 'copied_hashes': len(a), 'true_double_keys': len(b),
                          'overlap': len(a & b), 'copied_only': len(a-b), 'true_only': len(b-a)})
    save_csv('repeat_copy_summary.csv', copy_rows)
    check('529-step parity obstruction',
          all(r['overlap'] <= 1 for r in copy_rows if r['copy_number'] % 2 == 0),
          'All base hits except position 2 are odd. Even-numbered copies shift them to even composite positions.')
    even_survivors = sorted(p for p in true_hits & copied_hits if ((p-1)//529+1)%2 == 0)
    check('Even-copy overlaps only derive from base position 2',
          all((p-1)%529+1 == 2 for p in even_survivors), even_survivors)

    # This is a descriptive exhaustive cyclic phase comparison, NOT a p-value.
    post_base_true = true_hits - set(range(1,530))
    phases = []
    for shift in range(529):
        all_overlap = sum((((p-1-shift)%529)+1) in base for p in true_hits)
        held_overlap = sum((((p-1-shift)%529)+1) in base for p in post_base_true)
        phases.append({'shift': shift, 'overlap_all_positions': all_overlap,
                       'overlap_after_first_copy': held_overlap})
    save_csv('cyclic_phase_comparison.csv', phases)
    zero = phases[0]['overlap_after_first_copy']
    phase_counts = [x['overlap_after_first_copy'] for x in phases]
    summary = {
        'domain_positions': n, 'coordinate_records': len(expected_coords),
        'coordinate_cells_compared': len(coords['rows'])*len(coords['header']),
        'global_cells_compared': len(repeat['rows'])*len(repeat['header']),
        'double_keys_first_529': len(base), 'double_keys_first_913': sum(p<=913 for p in true_hits),
        'double_keys_first_14351': len(true_hits),
        'center_prime_73_columns_37_rows': primes[(73*37)//2],
        'center_prime_23_columns_23_rows': primes[(23*23)//2],
        'center_prime_status': 'Computed from ascending prime values; original XLSX and SVG were NOT compared.',
        'copied_hashes': len(copied_hits), 'actual_double_keys': len(true_hits),
        'literal_o_annotation': {'base_position': 437, 'occurrences': len(range(437,n+1,529)),
                                'meaning': 'Preserved source marker; no prime or physical meaning assumed.'},
        'overlap': len(copied_hits & true_hits), 'copied_only': len(copied_hits-true_hits),
        'true_only': len(true_hits-copied_hits), 'neither': n-len(copied_hits|true_hits),
        'even_copy_survivor_positions': even_survivors,
        'post_first_copy': {'positions': n-529, 'true_hits': len(post_base_true),
                           'observed_overlap': zero,
                           'all_529_phases_min': min(phase_counts), 'all_529_phases_max': max(phase_counts),
                           'all_529_phases_mean': str(F(sum(phase_counts),529)),
                           'phases_at_least_observed': sum(x>=zero for x in phase_counts),
                           'scope': 'Descriptive phase rank; not independent confirmation or a statistical significance claim.'},
        'mismatch_count': len(mismatches)
    }
    check('Stated prime-lattice counts', summary['double_keys_first_529']==43 and
          summary['double_keys_first_913']==74 and summary['double_keys_first_14351']==732)
    check('Prime-value centers', summary['center_prime_73_columns_37_rows']==11159 and
          summary['center_prime_23_columns_23_rows']==1697)
    save_json('prime_results.json', summary)
    print('Prime audit:', json.dumps(summary, ensure_ascii=False), flush=True)
    return summary


def witness_cli_and_oracle():
    script = ROOT/'source/geometry_quantum_witness.py'
    runs = [('self_test', ['--self-test']), ('two_state', []),
            ('seven_state', ['--example','seven','--compare','--budget','1'])]
    logs = []
    for label, args in runs:
        proc = subprocess.run([sys.executable,'-X','utf8',str(script),*args],
                              capture_output=True, text=True, encoding='utf-8', cwd=ROOT)
        (OUT/f'witness_{label}.log').write_text(proc.stdout+proc.stderr,encoding='utf-8')
        check('Recovered witness CLI: '+label, proc.returncode==0, {'exit_code':proc.returncode})
        logs.append(proc.stdout.strip())
    recreated = ('GEOMETRY QUANTUM WITNESS — EXECUTION REPORT\n\n'
                 '== Built-in self tests ==\n'+logs[0]+'\n\n'
                 '== Default (two-state) example ==\n'+logs[1]+'\n\n'
                 '== Seven-state example, budget 1, all measurement options ==\n'+logs[2]+'\n')
    old = (ROOT/'inputs/prior_witness_report.txt').read_text(encoding='utf-8')
    check('Witness report text reproduced', recreated.strip()==old.strip(),
          'LF normalization and outer whitespace ignored; all displayed report contents compared.')
    (OUT/'witness_execution_report.txt').write_text(recreated, encoding='utf-8')
    spec=importlib.util.spec_from_file_location('research_witness',script)
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    save_json('witness_two_state.json',module.run(module.example('two')))
    save_json('witness_seven_state.json',module.run(module.example('seven'),budget=1))

    # Independent loss oracle: within-fiber pair distances, not a mean computation.
    bloch=[(0,0,1),(0,0,-1),(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,0)]
    probabilities=[tuple(F(1+x,2) for x in v) for v in bloch]
    axis_names='XYZ'
    costs={'X':2,'Y':1,'Z':3}
    def axes(mask):
        return [axis_names[j] for j in range(3) if mask>>j&1]
    def loss(ids,retained_mask,target_mask):
        groups=defaultdict(list)
        for i in ids:
            groups[tuple(probabilities[i][j] for j in range(3) if retained_mask>>j&1)].append(i)
        return sum((sum((sum((probabilities[a][j]-probabilities[b][j])**2
                              for j in range(3) if target_mask>>j&1)
                         for a,b in it.combinations(group,2)),F(0))/(len(ids)*len(group))
                    for group in groups.values()),F(0))
    failures=[]
    cases=0
    for state_mask in range(1,128):
        ids=[i for i in range(7) if state_mask>>i&1]
        for retained_mask in range(8):
            for target_mask in range(1,8):
                cases+=1
                data={'states':[{'id':str(i),'bloch':list(bloch[i])} for i in ids],
                      'retained':axes(retained_mask),'target':axes(target_mask),
                      'available':{a:costs[a] for a in axes(7^retained_mask)}}
                got=module.run(data,budget=1)
                expected_loss=loss(ids,retained_mask,target_mask)
                options=[]
                for added in range(8):
                    if added&retained_mask:
                        continue
                    options.append((sum(costs[a] for a in axes(added)),
                                    loss(ids,retained_mask|added,target_mask),tuple(axes(added))))
                full=min((cost,len(ax),ax) for cost,l,ax in options if l==0)
                best=min((l,cost,len(ax),ax) for cost,l,ax in options if cost<=1)
                frontier={(c,l) for c,l,ax in options
                          if not any(c2<=c and l2<=l and (c2,l2)!=(c,l) for c2,l2,ax2 in options)}
                package_frontier={(F(o['cost']),F(o['native_squared_loss_after'])) for o in got['cost_loss_frontier']}
                repair=got['min_cost_fixed_batch']; budget=got['best_within_budget']
                correct=(F(got['native_squared_loss_before'])==expected_loss
                         and got['non_descent']==(expected_loss>0)
                         and (F(repair['cost']),len(repair['axes']),tuple(repair['axes']))==full
                         and (F(budget['native_squared_loss_after']),F(budget['cost']),
                              len(budget['axes']),tuple(budget['axes']))==best
                         and package_frontier==frontier)
                if not correct:
                    failures.append({'state_mask':state_mask,'retained_mask':retained_mask,'target_mask':target_mask})
    check('Independent finite witness oracle',not failures,{'cases':cases,'failure_count':len(failures),
          'domain':'All 127 nonempty subsets of seven named states, 8 retained-axis subsets, 7 nonempty target subsets.',
          'checks':'Pairwise loss identity, descent, minimum-cost full repair, budget-1 choice, nondominated frontier.',
          'costs':costs})
    save_json('witness_oracle_failures.json',failures)
    print('Witness oracle:',cases,'cases;',len(failures),'failures',flush=True)
    return {'cases':cases,'failures':len(failures),'source_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
            'extracted_source_bytes':script.stat().st_size,'library_metadata_source_bytes':18458}


def finite_math_audit():
    def floor_alpha(n):
        return 0 if n==0 else (3*n-math.isqrt(5*n*n)-1)//2
    nmax=500_000
    f39=[floor_alpha(39*n) for n in range(nmax+1)]
    slips=[15-f39[n+1]+f39[n] for n in range(nmax)]
    locations=[n for n,s in enumerate(slips) if s]
    gaps=Counter(b-a for a,b in zip(locations,locations[1:]))
    check('Exact golden-phase departures',set(slips)=={0,1} and set(gaps)<={9,10},
          {'departures':nmax,'slips':sum(slips),'complete_gap_counts':dict(gaps),
           'method':'Exact integer-square-root floors in Q(sqrt(5)); no floating phase arithmetic.'})
    check('Published exact slip counts',[sum(slips[:n]) for n in [39,507,10000]]==[5,53,1034])
    b=lambda n:floor_alpha(39*n)-39*floor_alpha(n)
    check('All screen transitions over 500000 departures',
          all((b(n+1)-b(n))%39==15-slips[n] and
              b(n+1)%3==(b(n)%3-slips[n])%3 for n in range(nmax)))
    collision={'n1':[b(1)%3,slips[1]],'n8':[b(8)%3,slips[8]],
               'next_slips':[slips[2],slips[9]]}
    check('Documented phase-state collision',collision=={'n1':[2,0],'n8':[2,0],'next_slips':[0,1]},collision)
    flags=sieve(118)
    marked=[z for z in range(1,119) if slips[z-1]]
    prime_marked=[z for z in marked if flags[z]]
    check('118-label phase example',len(marked)==13 and prime_marked==[59,97,107],
          {'marked_labels':marked,'prime_marked_labels':prime_marked,
           'scope':'Formal numeric labels; no chemical prediction tested.'})
    monomials=[(p,r) for p in range(25) for r in range(25-p)]
    check('Degree-24 monomial symmetry conditions',len(monomials)==325 and
          all(((p+r)%2==0 and (p-r)%3==0)==((p-r)%6==0) for p,r in monomials),{'monomials':len(monomials)})
    group=set(it.product(range(6),range(4)))
    unseen=set(group);orbits=[]
    while unseen:
        a,b0=min(unseen)
        orbit={((a+k)%6,(b0+k)%4) for k in range(12)}
        orbits.append(sorted(orbit));unseen-=orbit
    chi=lambda u:(u[0]-u[1])%2
    driven_ok=all(chi(((u[0]+1+r[0])%6,(u[1]+1+r[1])%4))==(chi(u)+chi(r))%2
                  for u in group for r in group)
    check('C6 x C4 finite orbits and driven quotient',len(orbits)==2 and
          all(len(o)==12 and len({chi(u) for u in o})==1 for o in orbits) and driven_ok,
          {'orbit_lengths':[len(o) for o in orbits],'state_deviation_pairs':576})
    order=lambda a,m:m//math.gcd(a,m)
    periods=Counter(math.lcm(order(a,12),order(b0,2),order(c,3))
                    for a,b0,c in it.product(range(12),range(2),range(3)))
    check('72-state register translation periods',sum(periods.values())==72 and max(periods)==12 and
          all(12%p==0 for p in periods),dict(periods))
    def ec_add(p,q):
        x,y=p;u,v=q
        slope=((v-y)*pow(u-x,-1,13))%13
        nx=(slope*slope-x-u)%13
        return nx,(slope*(x-nx)-y)%13
    p,q=(2,1),(3,3)
    plus,minus=ec_add(p,q),ec_add(p,(q[0],-q[1]%13))
    check('Elliptic-curve sign-loss example',all((y*y-x*x*x-2*x-2)%13==0 for x,y in [p,q])
          and plus[0]==12 and minus[0]==11,{'P_plus_Q':plus,'P_minus_Q':minus})
    prime=sieve(50)
    record=lambda n:(bool(prime[n]),bool(prime[n] and prime[2*n+1]))
    check('Prime predictive-label counterexample',record(3)==record(5)==(True,True) and
          record(7)!=(record(11)),{'r3':record(3),'r5':record(5),'r7':record(7),'r11':record(11)})
    # The prose claims "Any function of R recovers W"; a constant map disproves it.
    doc=(ROOT/'inputs/geometry_master_text_extract.md').read_text(encoding='utf-8')
    erratum={'source':'Geometry Master 2.10, miniature example, line 131',
             'quoted_statement':'Any function of R recovers W',
             'status':'COUNTEREXAMPLE',
             'counterexample':'g(R)=0 is constant and fails on state b, where W(b)=1.',
             'replacement':'W is a function of R (the second-coordinate projection recovers W).',
             'scope':'Local prose correction; no source file was edited.'}
    readable_doc = doc.replace('\\(', '').replace('\\)', '')
    matching_lines = [i for i,line in enumerate(readable_doc.splitlines(),1)
                      if erratum['quoted_statement'] in line]
    erratum['source_line'] = matching_lines[0] if matching_lines else None
    erratum['source'] = 'Geometry Master 2.10, miniature example'
    check('Located refinement prose erratum',bool(matching_lines))
    save_json('documentation_erratum.json',erratum)
    save_json('finite_math_results.json',{'phase_departures':nmax,'slip_count':sum(slips),
              'gap_counts':dict(gaps),'collision':collision,'marked_labels':marked,
              'orbits':orbits,'register_period_counts':dict(periods),'elliptic_sum':plus,'elliptic_difference':minus})
    print('Finite documented examples completed.',flush=True)
    return {'phase_departures':nmax,'slip_count':sum(slips),'register_period_counts':dict(periods),
            'documentation_erratum':erratum}


def weighted_loss_audit():
    # Explicit new fixture; source's original test program/fixtures were unavailable.
    partitions=sorted({tuple(next(j for j in range(4) if labels[j]==labels[i]) for i in range(4))
                       for labels in it.product(range(4),repeat=4)})
    values=list(map(F,[0,1,2,4]))
    weight_vectors=[[F(1,4)]*4,[F(x,10) for x in [1,2,3,4]],[F(x,10) for x in [7,1,1,1]]]
    candidates=list(map(F,[-1,0,1,2,4]))
    evaluations=refinements=0;errors=0
    for weights in weight_vectors:
        minima={}
        for partition in partitions:
            labels=sorted(set(partition))
            masses={q:sum(weights[i] for i in range(4) if partition[i]==q) for q in labels}
            means={q:sum(weights[i]*values[i] for i in range(4) if partition[i]==q)/masses[q] for q in labels}
            floor=sum(weights[i]*(values[i]-means[partition[i]])**2 for i in range(4))
            minima[partition]=floor
            for raw in it.product(candidates,repeat=len(labels)):
                g=dict(zip(labels,raw));evaluations+=1
                risk=sum(weights[i]*(values[i]-g[partition[i]])**2 for i in range(4))
                decomposition=floor+sum(masses[q]*(g[q]-means[q])**2 for q in labels)
                errors+=risk!=decomposition
        for fine,coarse in it.product(partitions,repeat=2):
            if all(fine[i]!=fine[j] or coarse[i]==coarse[j] for i,j in it.product(range(4),repeat=2)):
                refinements+=1;errors+=minima[fine]>minima[coarse]
    result={'partitions':len(partitions),'decomposition_evaluations':evaluations,
            'refinement_comparisons':refinements,'failures':errors,
            'target_values':list(map(str,values)),'weights':[[str(x) for x in w] for w in weight_vectors],
            'candidate_rule_values':list(map(str,candidates)),
            'scope':'Fresh explicitly declared fixture; not a source-hash replay of the historical 4665/180 test.'}
    check('Weighted finite loss decomposition and refinement',errors==0 and
          len(partitions)==15 and evaluations==4665 and refinements==180,result)
    save_json('weighted_loss_results.json',result)
    return result


def main():
    start=time.perf_counter()
    prime=prime_audit()
    witness=witness_cli_and_oracle()
    finite=finite_math_audit()
    weighted=weighted_loss_audit()
    result={'run_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,
            'platform':platform.platform(),'elapsed_seconds':round(time.perf_counter()-start,3),
            'pass_count':sum(c['status']=='PASS' for c in CHECKS),
            'fail_count':sum(c['status']=='FAIL' for c in CHECKS),'checks':CHECKS,
            'prime':prime,'witness':witness,'finite_math':finite,'weighted_loss':weighted,
            'not_run':['Original prime_lattice_independent_python_audit(2).zip scripts',
                       'Original workbook/SVG byte or cell comparisons','Trident v0.5 archive scripts',
                       'Toroidal sampler replay or physical experiments'],
            'source_method':'Complete text reads, recorded as extracted working inputs; original ZIP unavailable.'}
    save_json('run_results.json',result)
    print('FINAL:',result['pass_count'],'checks passed;',result['fail_count'],'failed;',result['elapsed_seconds'],'seconds',flush=True)
    return 1 if result['fail_count'] else 0


if __name__=='__main__':
    raise SystemExit(main())
