"""Package this run with a hash manifest; no network access."""
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root=Path(__file__).resolve().parents[1]
items=sorted(p for p in root.rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and p.name!='manifest.json')
manifest=[{'path':p.relative_to(root).as_posix(),'size_bytes':p.stat().st_size,
           'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in items]
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
archive=root.parent/'research_run_2026-11-11.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for p in items+[root/'manifest.json']:
        z.write(p,arcname='research_run/'+p.relative_to(root).as_posix())
with ZipFile(archive) as z:
    if z.testzip() is not None:
        raise RuntimeError('Archive integrity check failed')
    for item in manifest:
        if hashlib.sha256(z.read('research_run/'+item['path'])).hexdigest()!=item['sha256']:
            raise RuntimeError('Archive member hash mismatch')
print(json.dumps({'archive':str(archive),'size_bytes':archive.stat().st_size,
                  'files':len(manifest)+1,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
